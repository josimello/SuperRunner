package com.example.superrunner

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

private class Spec(val bpm: Int, val root: Float, val prog: IntArray, val q: IntArray, val lead: IntArray,
                   val minor: Boolean, val drums: Boolean, val amb: Float)

/** Audio 100% procedural: efectos, música y ambiente sintetizados por código (sin archivos). */
class Audio {
    private val SR = 22050
    @Volatile var sfxOn = true
    @Volatile var musicOn = true
    private val sfxData = arrayOfNulls<ShortArray>(19)
    private val sfxTrack = arrayOfNulls<AudioTrack>(19)
    private val lastPlay = LongArray(19)
    private val tracks = arrayOfNulls<ShortArray>(5)
    private var cur = -1
    private var want = -1
    private var mt: AudioTrack? = null
    private var vol = 1f

    init {
        sfxData[0] = tone(280f, 620f, 0.16f, 1, 0.35f, 0f, 4f)
        sfxData[1] = tone(420f, 900f, 0.14f, 3, 0.35f, 0f, 4f)
        sfxData[2] = tone(900f, 200f, 0.18f, 0, 0.25f, 0.8f, 4f)
        sfxData[3] = cat(tone(988f, 988f, 0.06f, 3, 0.35f, 0f, 2f), tone(1319f, 1319f, 0.14f, 3, 0.35f, 0f, 4f))
        sfxData[4] = tone(220f, 60f, 0.25f, 1, 0.5f, 0.4f, 4f)
        sfxData[5] = cat(tone(300f, 100f, 0.12f, 0, 0.5f, 0.2f, 5f), tone(600f, 900f, 0.08f, 3, 0.25f, 0f, 3f))
        sfxData[6] = tone(200f, 1000f, 0.25f, 3, 0.4f, 0f, 3f)
        sfxData[7] = tone(900f, 150f, 0.2f, 1, 0.3f, 0.3f, 4f)
        sfxData[8] = cat(tone(523f, 523f, 0.07f, 3, 0.35f, 0f, 2f), tone(659f, 659f, 0.07f, 3, 0.35f, 0f, 2f),
            tone(784f, 784f, 0.07f, 3, 0.35f, 0f, 2f), tone(1047f, 1047f, 0.2f, 3, 0.35f, 0f, 4f))
        sfxData[9] = tone(700f, 500f, 0.05f, 3, 0.3f, 0f, 3f)
        sfxData[10] = cat(tone(1047f, 1047f, 0.07f, 3, 0.35f, 0f, 2f), tone(1568f, 1568f, 0.25f, 3, 0.35f, 0f, 4f))
        sfxData[11] = cat(tone(200f, 200f, 0.1f, 1, 0.35f, 0f, 2f), tone(150f, 150f, 0.16f, 1, 0.35f, 0f, 4f))
        sfxData[12] = cat(tone(523f, 523f, 0.1f, 3, 0.4f, 0f, 2f), tone(659f, 659f, 0.1f, 3, 0.4f, 0f, 2f), tone(784f, 784f, 0.1f, 3, 0.4f, 0f, 2f),
            tone(1047f, 1047f, 0.2f, 3, 0.4f, 0f, 2f), tone(784f, 784f, 0.1f, 3, 0.4f, 0f, 2f), tone(1047f, 1047f, 0.45f, 3, 0.4f, 0f, 3f))
        sfxData[13] = cat(tone(392f, 392f, 0.18f, 3, 0.4f, 0f, 2f), tone(330f, 330f, 0.18f, 3, 0.4f, 0f, 2f), tone(262f, 262f, 0.4f, 3, 0.4f, 0f, 3f))
        sfxData[14] = cat(tone(660f, 660f, 0.08f, 3, 0.3f, 0f, 2f), tone(880f, 880f, 0.16f, 3, 0.3f, 0f, 4f))
        sfxData[15] = tone(120f, 60f, 0.08f, 0, 0.3f, 0.4f, 6f)
        sfxData[16] = tone(180f, 120f, 0.04f, 0, 0.12f, 0.8f, 6f)
        sfxData[17] = cat(tone(150f, 50f, 0.3f, 1, 0.5f, 0.5f, 3f), tone(300f, 120f, 0.2f, 2, 0.3f, 0.2f, 4f))
        sfxData[18] = tone(120f, 70f, 0.6f, 2, 0.45f, 0.5f, 1.5f)
        val th = Thread { for (i in 0 until 5) { tracks[i] = genTrack(i); refresh() } }
        th.isDaemon = true
        th.start()
    }

    // ---------- síntesis ----------
    private fun w(x: Float, k: Int): Float {
        val f = x - floor(x)
        return when (k) { 0 -> sin(6.2831855f * f); 1 -> if (f < 0.5f) 0.6f else -0.6f; 2 -> 2f * f - 1f; else -> 1f - 4f * abs(f - 0.5f) }
    }

    private fun tone(f0: Float, f1: Float, dur: Float, k: Int, vol: Float, noise: Float, decay: Float): ShortArray {
        val n = (SR * dur).toInt()
        val o = ShortArray(n)
        val r = Random(5)
        var ph = 0f
        for (i in 0 until n) {
            val t = i / n.toFloat()
            ph += (f0 + (f1 - f0) * t) / SR
            val v = w(ph, k) * (1f - noise) + (r.nextFloat() * 2f - 1f) * noise
            val env = exp(-decay * t) * min(1f, i / 60f) * min(1f, (n - i) / 80f)
            o[i] = (v * env * vol * 32000f).toInt().toShort()
        }
        return o
    }

    private fun cat(vararg a: ShortArray): ShortArray {
        var n = 0
        for (x in a) n += x.size
        val o = ShortArray(n)
        var p = 0
        for (x in a) { System.arraycopy(x, 0, o, p, x.size); p += x.size }
        return o
    }

    private fun note(m: FloatArray, at: Int, len: Int, f: Float, k: Int, v: Float, dec: Float) {
        for (i in 0 until len) {
            val j = at + i
            if (j >= m.size) break
            val t = i / len.toFloat()
            m[j] += w(f * i / SR, k) * v * exp(-dec * t) * min(1f, i / 40f) * min(1f, (len - i) / 120f)
        }
    }

    private fun kick(m: FloatArray, at: Int, v: Float) {
        val n = (SR * 0.18f).toInt()
        var ph = 0f
        for (i in 0 until n) {
            val j = at + i
            if (j >= m.size) break
            val t = i / n.toFloat()
            ph += (45f + 120f * exp(-t * 9f)) / SR
            m[j] += sin(6.2831855f * ph) * v * (1f - t)
        }
    }

    private fun noise(m: FloatArray, at: Int, n: Int, v: Float, dec: Float, r: Random) {
        for (i in 0 until n) {
            val j = at + i
            if (j >= m.size) break
            m[j] += (r.nextFloat() * 2f - 1f) * v * exp(-dec * i / n.toFloat())
        }
    }

    private fun genTrack(id: Int): ShortArray {
        val sp = when (id) {
            0 -> Spec(92, 110f, intArrayOf(0, 8, 3, 10), intArrayOf(1, 0, 0, 0),
                intArrayOf(4, -1, -1, 2, -1, 4, -1, 5, 4, -1, -1, 2, 0, -1, -1, -1, 2, -1, -1, 4, -1, 2, -1, 0, -1, -1, 2, -1, 1, -1, -1, -1), true, false, 0.55f)
            1 -> Spec(126, 82.41f, intArrayOf(0, 3, 8, 10), intArrayOf(1, 0, 0, 0),
                intArrayOf(7, -1, 4, -1, 7, -1, 9, 7, 4, -1, 2, -1, 4, 5, 4, -1, 7, -1, 4, -1, 9, -1, 7, -1, 5, -1, 4, 2, 4, -1, -1, -1), true, true, 0.4f)
            2 -> Spec(104, 73.42f, intArrayOf(0, 1, 0, 10), intArrayOf(1, 0, 1, 0),
                intArrayOf(4, 5, 4, -1, 2, -1, 1, 2, 4, -1, -1, 5, 4, 2, 1, -1, 4, 5, 4, -1, 7, -1, 5, 4, 2, -1, 1, 2, 0, -1, -1, -1), true, true, 0.9f)
            3 -> Spec(96, 87.31f, intArrayOf(0, 5, 7, 5), intArrayOf(0, 0, 0, 0),
                intArrayOf(4, -1, -1, 2, 4, -1, 7, -1, 5, -1, -1, 4, 2, -1, -1, -1, 4, -1, 5, -1, 7, -1, 9, -1, 7, -1, 5, 4, 2, -1, -1, -1), false, true, 0.9f)
            else -> Spec(148, 65.41f, intArrayOf(0, 0, 8, 7), intArrayOf(1, 1, 0, 0),
                intArrayOf(7, 7, -1, 7, 8, -1, 7, -1, 5, 5, -1, 5, 4, -1, 2, -1, 7, 7, -1, 7, 9, -1, 8, -1, 7, 5, 4, 2, 0, -1, -1, -1), true, true, 0.4f)
        }
        val step = (SR * 60f / sp.bpm / 4f).toInt()
        val bars = sp.prog.size * 2
        val total = step * 16 * bars
        val m = FloatArray(total)
        val r = Random(id * 17L + 3)
        val scale = if (sp.minor) intArrayOf(0, 2, 3, 5, 7, 8, 10) else intArrayOf(0, 2, 4, 5, 7, 9, 11)
        fun hz(semi: Int) = sp.root * 2f.pow(semi / 12f)
        for (b in 0 until bars) {
            val cr = sp.prog[b % sp.prog.size]
            val chord = intArrayOf(cr, cr + (if (sp.q[b % sp.prog.size] == 1) 3 else 4), cr + 7)
            for (ct in chord) note(m, b * 16 * step, 16 * step, hz(ct + 12), 3, 0.045f, 0.4f)
            for (s in 0 until 16) {
                val at = (b * 16 + s) * step
                if (s % 2 == 0) note(m, at, step * 2, hz(cr - 12), 2, 0.2f, 5f)
                note(m, at, step, hz(chord[s % 3] + 12 * (1 + s / 8)), 1, 0.07f, 8f)
                val li = sp.lead[(b * 16 + s) % sp.lead.size]
                if (li >= 0) note(m, at, step * 2, hz(scale[li % 7] + 12 * (li / 7) + 12), 1, 0.11f, 3f)
                if (sp.drums) {
                    if (s % 4 == 0) kick(m, at, 0.5f)
                    if (s == 4 || s == 12) noise(m, at, step * 2, 0.2f, 6f, r)
                    if (s % 2 == 1) noise(m, at, step / 2, 0.05f, 9f, r)
                }
            }
        }
        var y = 0f
        for (i in 0 until total) {
            y += ((r.nextFloat() * 2f - 1f) - y) * 0.03f
            m[i] += y * sp.amb * (0.7f + 0.3f * sin(6.2831855f * 3f * i / total))
        }
        return ShortArray(total) { (tanh(m[it] * 1.1f) * 29000f).toInt().toShort() }
    }

    // ---------- reproducción ----------
    private fun mk(d: ShortArray): AudioTrack {
        val data = if (d.size < 2048) d.copyOf(2048) else d
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(data.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(data, 0, data.size)
        return t
    }

    fun play(id: Int) {
        if (!sfxOn) return
        val now = System.currentTimeMillis()
        if (now - lastPlay[id] < 45) return
        lastPlay[id] = now
        try {
            var t = sfxTrack[id]
            if (t == null) { t = mk(sfxData[id] ?: return); sfxTrack[id] = t }
            t.stop(); t.reloadStaticData(); t.play()
        } catch (e: Exception) { }
    }

    @Synchronized private fun stopCur() {
        try { mt?.stop(); mt?.release() } catch (e: Exception) { }
        mt = null; cur = -1
    }

    @Synchronized private fun startMusic() {
        if (!musicOn || want < 0) { stopCur(); return }
        val d = tracks[want] ?: return
        if (cur == want && mt != null) return
        stopCur()
        try {
            val t = mk(d)
            t.setLoopPoints(0, d.size, -1)
            t.setVolume(0.55f * vol)
            t.play()
            mt = t; cur = want
        } catch (e: Exception) { mt = null; cur = -1 }
    }

    @Synchronized fun refresh() { startMusic() }
    @Synchronized fun music(id: Int) { if (id == want) return; want = id; startMusic() }
    @Synchronized fun setMusicOn(b: Boolean) { musicOn = b; startMusic() }
    @Synchronized fun setVol(v: Float) {
        if (v == vol) return
        vol = v
        try { mt?.setVolume(0.55f * v) } catch (e: Exception) { }
    }
    @Synchronized fun pause() { try { mt?.pause() } catch (e: Exception) { } }
    @Synchronized fun resume() {
        if (!musicOn) return
        if (mt == null) startMusic() else try { mt?.play() } catch (e: Exception) { }
    }
}
