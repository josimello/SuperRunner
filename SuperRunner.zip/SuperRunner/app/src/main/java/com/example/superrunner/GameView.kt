package com.example.superrunner

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.os.Build
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.util.Random
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.*

private open class Body(var x: Float, var y: Float, val w: Float, val h: Float) {
    var vx = 0f; var vy = 0f
    var ground = false; var wall = false
}
/** kind: 0 caminante, 1 pinchudo, 2 murciélago volador, 3 torreta */
private class Enemy(x: Float, y: Float, val kind: Int) : Body(x, y, 0.8f, 0.8f) {
    var dead = false; var t = 0f; var cd = 1.5f; val y0 = y
    val spiky: Boolean get() = kind == 1
    init { vx = when (kind) { 1 -> -2.2f; 2 -> -1.8f; 3 -> 0f; else -> -1.5f } }
}
private val BOSS_W = floatArrayOf(1.8f, 2.4f, 2.4f, 2.6f, 2.4f, 1.8f)
private val BOSS_H = floatArrayOf(1.8f, 1.4f, 2.4f, 1.5f, 2.0f, 1.8f)
private val BOSS_N = arrayOf("CENTINELA", "ESCORPIÓN DE ARENA", "GOLEM DE HIELO", "DRAGÓN DE LAVA", "HIDRA TÓXICA", "NÚCLEO CÓSMICO")
private val BOSS_HINT = arrayOf(
    "Salta la carga y usa DASH para atravesar sus disparos. ¡Písalo cuando se aturda!",
    "Huye de la marca roja del suelo y salta las ondas de arena. ¡Písalo cuando salga!",
    "Rompe sus placas con DASH y esquiva los carámbanos. Luego písalo.",
    "Sube a las plataformas para evitar el vuelo rasante. ¡Písalo cuando aterrice!",
    "El DASH destruye los orbes teledirigidos. ¡Písala cuando baje la cabeza!",
    "Atraviesa los láseres con DASH y písalo tras cada ataque."
)
private class Boss(x: Float, y: Float, var hp: Int, val type: Int) : Body(x, y, BOSS_W[type], BOSS_H[type]) {
    var state = 0; var tm = 2f; var t2 = 0f; var inv = 0f; var dir = -1
    var armor = 0; var hidden = false; var fly = false; var warn = false; var tx = 0f; val maxHp = hp
}
private class Plat(val kind: Int, val x0: Float, val y0: Float, val w: Float, val amp: Float, val per: Float, val ph: Float) {
    var x = x0; var y = y0; var dx = 0f; var dy = 0f
    var solid = true; var warn = false; var stepped = false; var t = 0f; var fall = 0f
}
private class Bullet(var x: Float, var y: Float, var vx: Float, var vy: Float = 0f, val kind: Int = 0) { var life = 4f; var tm = 0f; var w = 0.45f; var h = 0.3f }
private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val col: Int)
private class Ring(val x: Float, val y: Float, val col: Int) { var life = 0.4f }
private class Txt(var x: Float, var y: Float, val s: String, val col: Int) { var life = 0.9f }
private class Btn(val r: RectF, val label: String, val sub: String, val act: () -> Unit)

/** NEON DASH. Pantallas: 0 título, 1 menú, 2 niveles, 3 tienda, 4 ajustes, 5 juego. */
class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {
    private val H = 12
    private var W = 100
    private var map = Array(H) { CharArray(W) { '.' } }
    private val enemies = ArrayList<Enemy>()
    private val parts = ArrayList<Part>()
    private val btns = ArrayList<Btn>()
    private val taps = ConcurrentLinkedQueue<PointF>()
    private val p = Body(2f, 8f, 0.8f, 0.95f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rnd = Random()
    private var bL = RectF(); private var bR = RectF(); private var bJ = RectF(); private var bD = RectF()
    @Volatile private var goL = false
    @Volatile private var goR = false
    @Volatile private var goJ = false
    @Volatile private var goD = false
    @Volatile private var running = false
    private var thread: Thread? = null

    private var scr = 0; private var paused = false; private var res = 0
    private var lv = 0; private var hp = 3; private var gems = 0; private var gemTotal = 0; private var lastStars = 0
    private var cpX = 2f; private var cpY = 8f
    private var jumps = 0; private var jPrev = false; private var dPrev = false; private var spr = false
    private var dashT = 0f; private var dashCd = 0f; private var inv = 0f; private var shake = 0f; private var intro = 0f
    private var face = 1; private var time = 0f
    private var confirm = false; private var msg = ""; private var msgT = 0f

    private val sp = ctx.getSharedPreferences("neondash", Context.MODE_PRIVATE)
    private var coins = sp.getInt("coins", 0)
    private var unlocked = sp.getInt("unl", 1)
    private var owned = sp.getInt("own", 1)
    private var skin = sp.getInt("skin", 0)
    private var snd = sp.getBoolean("snd", true)
    private var hap = sp.getBoolean("hap", true)
    private var ctl = sp.getInt("ctl", 1)
    private var dif = sp.getInt("dif", 1)
    private val stars = IntArray(36) { sp.getInt("s$it", 0) }
    private var upHp = sp.getInt("uhp", 0)
    private var upDash = sp.getInt("uda", 0)
    private var upMag = sp.getInt("umg", 0)
    private var lastDay = sp.getLong("day", 0L)
    private var streak = sp.getInt("streak", 0)
    private var lastGift = sp.getInt("glast", 25)
    private var giftState = if (sp.getLong("day", 0L) == System.currentTimeMillis() / 86400000L) sp.getInt("gst", 1) else 0
    private var shopTab = 0
    private var shield = false
    private var wasGround = false
    private var bossMax = 1
    private var boss: Boss? = null
    private val bullets = ArrayList<Bullet>()
    private val HZ = longArrayOf(0xAAFF2BD6, 0xFFFF5722, 0xAA4FC3F7, 0xFFFF3D00, 0xAA00E5A0, 0xAA818CF8)
    private val AMB = longArrayOf(0x66FF2BD6, 0x99FFD27A, 0xCCFFFFFF, 0xCCFF9E40, 0x9969F0AE, 0x77BBDEFB)
    private val audio = Audio()
    private var mus = sp.getBoolean("mus", true)
    private var camX = 0f; private var fade = 0f; private var lastScr = 0; private var lastStep = 0f
    private var rx = 0f; private var ry = 0f; private var rT = 0f
    private val ghosts = ArrayList<FloatArray>()
    private val rings = ArrayList<Ring>()
    private val pops = ArrayList<Txt>()
    private var flash = 0f; private var hitStop = 0f; private var squashT = 0f; private var skinPage = 0
    private val DAILY = intArrayOf(25, 40, 60, 80, 110, 150, 250)
    private val plats = ArrayList<Plat>()
    private val lasers = ArrayList<FloatArray>()
    private val traps = ArrayList<FloatArray>()
    private var ride: Plat? = null
    private var wPage = 0; private var zoom = 0f
    private val BHP = intArrayOf(4, 6, 8, 10, 12, 15)
    private val STY = intArrayOf(0, 1, 2, 2, 1, 0)
    private val rf = RectF(); private val pr = RectF()
    private val gp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val filters = HashMap<Int, ColorFilter>()
    private var glow: Bitmap? = null
    private val tiles = arrayOfNulls<Bitmap>(3)
    private var tileKey = -1; private var skyKey = -1
    private var skySh: Shader? = null; private var sunGlowSh: Shader? = null; private var sunSh: Shader? = null
    private var vigSh: Shader? = null; private var fogSh: Shader? = null; private var shaftSh: Shader? = null
    private val layerSh = arrayOfNulls<Shader>(3)
    private val PRIMARY = setOf("JUGAR", "CONTINUAR", "SIGUIENTE", "¡RECLAMAR!")

    private val SK_N = arrayOf("CIAN", "FUEGO", "BOSQUE", "ORO", "FANTASMA", "ARCOÍRIS", "CYBERPUNK", "ROJO NEÓN", "AZUL ELÉCTRICO", "SAKURA", "TÓXICO", "OBSIDIANA")
    private val SK_P = intArrayOf(0, 60, 120, 220, 350, 500, 150, 180, 250, 300, 400, 800)
    private val SK_C = longArrayOf(0xFF00BCD4, 0xFFFF5722, 0xFF43A047, 0xFFFFC107, 0xB3E0E0FF, 0xFFFFFFFF, 0xFF2A1646, 0xFFD50000, 0xFF2962FF, 0xFFFF80AB, 0xFF76FF03, 0xFF212121)
    private val SK_V = longArrayOf(0xFF7DF9FF, 0xFFFFEB3B, 0xFFCCFF90, 0xFF18FFFF, 0xFFB388FF, 0xFFFFFFFF, 0xFFFF2BD6, 0xFFFF1744, 0xFF40C4FF, 0xFFFF4081, 0xFF1B5E20, 0xFFFFD740)
    private val SK_A = longArrayOf(0xFF7DF9FF, 0xFFFFEB3B, 0xFFB9F6CA, 0xFFFFF176, 0xFFB388FF, 0xFFFF80AB, 0xFFFFEA00, 0xFFFF5252, 0xFF40C4FF, 0xFFFFFFFF, 0xFFEEFF41, 0xFFFFD740)
    private val WN = arrayOf("NEÓN", "DESIERTO", "HIELO", "VOLCÁN", "JUNGLA", "ESTACIÓN")
    private val TH = arrayOf(
        longArrayOf(0xFF0B0426, 0xFF3A0F6E, 0xFFFF5BA7, 0xFFFFE08A, 0xFF1E0F4A, 0xFF2B1466, 0xFF3C1B80, 0xFF2A1A52, 0xFF150B30, 0xFF00F0FF, 0xFFFF2BD6),
        longArrayOf(0xFF2B1055, 0xFFE0577F, 0xFFFFB347, 0xFFFFF1B5, 0xFF8E3B5A, 0xFFB5503F, 0xFF7A3328, 0xFFC97B3C, 0xFF8A4A22, 0xFFFFE29A, 0xFFFF7043),
        longArrayOf(0xFF04112B, 0xFF0B3C5D, 0xFF2EC4B6, 0xFFE6FBFF, 0xFF1B4F72, 0xFF2A7FA8, 0xFF8EC5E8, 0xFF5BA3D0, 0xFF2D6A9A, 0xFFEFFBFF, 0xFF7DF9FF),
        longArrayOf(0xFF1A0505, 0xFF6A1B09, 0xFFFF6D00, 0xFFFFE082, 0xFF3A0F0A, 0xFF4E1A10, 0xFF2A0A06, 0xFF3E2723, 0xFF1B0F0C, 0xFFFF6D00, 0xFFFF3D00),
        longArrayOf(0xFF021A14, 0xFF064E3B, 0xFF1DE9B6, 0xFFB9F6CA, 0xFF0B3D2E, 0xFF0F5A43, 0xFF083226, 0xFF1B4332, 0xFF0B2218, 0xFF69F0AE, 0xFF00E5A0),
        longArrayOf(0xFF020617, 0xFF1E1B4B, 0xFF4C1D95, 0xFFBBDEFB, 0xFF172554, 0xFF1E3A8A, 0xFF312E81, 0xFF334155, 0xFF0F172A, 0xFF38BDF8, 0xFF818CF8)
    )
    private var tg: ToneGenerator? = null

    // ---------- Anuncios recompensados (AdMob). ID de PRUEBA: cámbialo por el tuyo para cobrar ----------
    private val AD_UNIT = "ca-app-pub-3940256099942544/5224354917"
    @Volatile private var rewarded: RewardedAd? = null
    @Volatile private var adLoading = false
    @Volatile private var adReward = false
    @Volatile private var adDone = false
    private var adMode = 0; private var adT = 0f
    private var lvCoins = 0; private var doubled = false
    private var safeX = 2f; private var safeY = 8f

    init {
        holder.addCallback(this)
        paint.typeface = Typeface.DEFAULT_BOLD
        MobileAds.initialize(ctx) { }
        audio.sfxOn = snd; audio.musicOn = mus
        lv = (unlocked - 1).coerceIn(0, 35)
    }

    private fun k(v: Long) = v.toInt()
    private fun maxHp() = (when (dif) { 0 -> 5; 1 -> 3; else -> 2 }) + upHp
    private fun em() = when (dif) { 0 -> 0.8f; 1 -> 1f; else -> 1.25f }
    private fun cm() = when (dif) { 0 -> 0.75f; 1 -> 1f; else -> 1.5f }
    private fun bsp() = when (dif) { 0 -> 0.85f; 1 -> 1f; else -> 1.18f }
    private fun brate() = when (dif) { 0 -> 0.8f; 1 -> 1f; else -> 1.3f }
    private fun invT() = when (dif) { 0 -> 2f; 1 -> 1.4f; else -> 1f }
    private fun upLevel(j: Int) = when (j) { 0 -> upHp; 1 -> upDash; else -> upMag }
    private fun stars3(n: Int) = "★".repeat(n) + "☆".repeat(3 - n)
    private fun skinCol(i: Int): Int =
        if (i == 5) Color.HSVToColor(floatArrayOf((time * 120f) % 360f, 0.8f, 1f)) else k(SK_C[i])

    private fun save() {
        val e = sp.edit()
        e.putInt("coins", coins).putInt("unl", unlocked).putInt("own", owned).putInt("skin", skin)
        e.putBoolean("snd", snd).putBoolean("hap", hap).putInt("ctl", ctl).putInt("dif", dif)
        e.putInt("uhp", upHp).putInt("uda", upDash).putInt("umg", upMag).putLong("day", lastDay).putInt("streak", streak).putInt("gst", giftState).putInt("glast", lastGift).putBoolean("mus", mus)
        for (i in 0 until 36) e.putInt("s$i", stars[i])
        e.apply()
    }

    private fun sfx(id: Int) { audio.play(id) }

    private fun beep(t: Int) {
        sfx(when (t) {
            ToneGenerator.TONE_DTMF_1 -> 0
            ToneGenerator.TONE_DTMF_3 -> 1
            ToneGenerator.TONE_DTMF_9 -> 2
            ToneGenerator.TONE_PROP_BEEP -> 3
            ToneGenerator.TONE_PROP_NACK -> 4
            ToneGenerator.TONE_DTMF_5 -> 6
            ToneGenerator.TONE_DTMF_7 -> 7
            ToneGenerator.TONE_PROP_ACK -> 8
            else -> 9
        })
    }

    private fun ring(x: Float, y: Float, col: Long) { rings.add(Ring(x, y, k(col))) }
    private fun pop(t: String, x: Float, y: Float, col: Long) { pops.add(Txt(x, y, t, k(col))) }
    private fun acc(): Long = SK_A[skin]
    private fun nextDay(): Int {
        val today = System.currentTimeMillis() / 86400000L
        return if (giftState != 0) streak else if (lastDay == today - 1) (streak + 1) % 7 else 0
    }

    private fun earn(n: Int) { val g = max(1, (n * cm()).toInt()); coins += g; lvCoins += g }

    private fun loadAd() {
        if (rewarded != null || adLoading) return
        adLoading = true
        post {
            RewardedAd.load(context, AD_UNIT, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewarded = ad; adLoading = false }
                override fun onAdFailedToLoad(error: LoadAdError) { rewarded = null; adLoading = false }
            })
        }
    }

    /** mode 1 = revivir en el sitio, mode 2 = duplicar monedas del nivel, mode 3 = duplicar regalo diario */
    private fun showAd(mode: Int) {
        val ad = rewarded
        if (ad == null) { msg = "Anuncio no disponible aún, prueba en unos segundos"; msgT = 2.5f; adT = 0f; return }
        adMode = mode; adReward = false; adDone = false
        rewarded = null
        post {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() { adDone = true }
                override fun onAdFailedToShowFullScreenContent(error: AdError) { adReward = false; adDone = true }
            }
            ad.show(context as Activity) { adReward = true }
        }
    }

    private fun grant(mode: Int) {
        if (mode == 1 && res == 2) {
            res = 0; hp = maxHp(); p.x = safeX; p.y = safeY - 0.05f; p.vx = 0f; p.vy = 0f; inv = 3f
            sfx(8)
        } else if (mode == 3 && giftState == 1) {
            coins += lastGift; giftState = 2; msg = "¡+$lastGift monedas extra!"; msgT = 2.5f
            sfx(8); save()
        } else if (mode == 2 && res == 1 && !doubled) {
            doubled = true; coins += lvCoins; msg = "¡+$lvCoins monedas!"; msgT = 2f
            sfx(8); save()
        }
    }

    private fun buzz() { if (hap) post { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) } }

    private fun burst(x: Float, y: Float, col: Long, n: Int) {
        repeat(n) { parts.add(Part(x, y, (rnd.nextFloat() - 0.5f) * 6f, (rnd.nextFloat() - 0.8f) * 5f, 0.5f, k(col))) }
    }

    // ---------- Niveles (generados por semilla, cada uno distinto y más difícil) ----------
    private fun put(c: Char, x1: Int, x2: Int, y1: Int, y2: Int) {
        for (y in y1..y2) for (x in x1..x2) if (x in 0 until W && y in 0 until H) map[y][x] = c
    }

    private fun load(l: Int) {
        lv = l
        val r = Random(l * 7919L + 13L)
        val isBoss = l % 6 == 5
        val wi = l / 6
        W = if (isBoss) 110 + wi * 8 else 150 + l * 8
        map = Array(H) { CharArray(W) { '.' } }
        enemies.clear(); parts.clear(); bullets.clear(); boss = null
        plats.clear(); lasers.clear(); traps.clear(); ride = null
        put('#', 0, W - 1, 10, 11)
        var x = 8
        val lim = if (isBoss) W - 36 else W - 16
        val step = lim / (when (dif) { 0 -> 6; 1 -> 5; else -> 3 })
        var nextCp = step
        while (x < lim - 14) {
            if (x >= nextCp) { map[9][x] = 'C'; nextCp += step; x += 4; continue }
            var seg = r.nextInt(17)
            if (l < 2 && seg >= 12) seg = r.nextInt(10)
            if (dif == 0 && (seg == 2 || seg == 3 || seg == 8 || seg == 15 || seg == 16) && r.nextInt(4) == 0) seg = 6
            if (dif == 2 && seg == 6 && r.nextInt(2) == 0) seg = 3
            when (seg) {
                0 -> { val g = 2 + r.nextInt(1 + min(2, l / 3)); put('.', x, x + g - 1, 10, 11); put('o', x - 1, x + g, 7, 7); x += g + 4 }
                1 -> { put('P', x + 2, x + 4, 7, 7); put('o', x + 2, x + 4, 6, 6); x += 8 }
                2 -> { val n = 1 + r.nextInt(2); put('^', x, x + n - 1, 9, 9); put('o', x, x + n - 1, 7, 7); x += n + 4 }
                3 -> { enemies.add(Enemy(x.toFloat(), 9.2f, if (l >= 2 && r.nextInt(3) == 0) 1 else 0)); x += 6 }
                4 -> { val hh = 2 + r.nextInt(2); put('#', x, x + 1, 10 - hh, 9); x += 5 }
                5 -> { map[9][x] = '='; put('P', x + 3, x + 6, 4, 4); put('o', x + 3, x + 6, 3, 3); x += 9 }
                6 -> { put('o', x, x + 3, 8, 8); x += 5 }
                7 -> { enemies.add(if (l >= 1) Enemy(x.toFloat(), 7f, 2) else Enemy(x.toFloat(), 9.2f, 0)); x += 7 }
                8 -> { if (l >= 2) enemies.add(Enemy(x.toFloat(), 9.2f, 3)) else put('o', x, x + 3, 8, 8); x += 7 }
                10 -> { val g = 7 + r.nextInt(3); put('.', x, x + g - 1, 10, 11); plats.add(Plat(0, x + g / 2f - 1.5f, 10f, 3f, g / 2f - 1.2f, 4.5f, r.nextFloat())); put('o', x + 1, x + g - 2, 7, 7); x += g + 4 }
                11 -> { val g = 6 + r.nextInt(3); put('.', x, x + g - 1, 10, 11); for (i in 0 until g / 2) plats.add(Plat(2, x + 0.2f + i * 2.1f, 10f, 1.7f, 0f, 1f, 0f)); put('o', x + 1, x + g - 2, 8, 8); x += g + 4 }
                12 -> { plats.add(Plat(1, x.toFloat(), 7.5f, 2.2f, 2.4f, 5f, 0f)); put('P', x + 3, x + 7, 4, 4); put('o', x + 3, x + 7, 3, 3); x += 11 }
                13 -> { put('.', x, x + 7, 10, 11); for (i in 0..3) plats.add(Plat(3, x + 0.5f + i * 2f, 10f - (i % 2) * 1.2f, 1.8f, 0f, 2.4f, i * 0.25f)); put('o', x + 1, x + 6, 7, 7); x += 12 }
                14 -> { put('.', x, x + 9, 10, 11); plats.add(Plat(4, x + 0.3f, 10f, 3f, 6.7f, 2.6f, 0f)); put('o', x + 2, x + 7, 6, 6); x += 14 }
                15 -> { put('x', x, x + 2, 9, 9); put('o', x, x + 2, 8, 8); x += 8 }
                16 -> { lasers.add(floatArrayOf(x.toFloat(), 2.4f, 0f)); lasers.add(floatArrayOf(x + 4f, 2.4f, 0.5f)); put('o', x + 1, x + 3, 8, 8); x += 9 }
                else -> { put('P', x, x + 3, 7, 7); put('o', x + 1, x + 2, 6, 6); x += 6 }
            }
            if (dif == 2 && r.nextInt(7) == 0) enemies.add(Enemy(x - 3f, 7f, 2))
            if (r.nextInt(when (dif) { 0 -> 8; 1 -> 12; else -> 18 }) == 0) map[8][x] = if (dif == 2 && r.nextInt(3) != 0) 'S' else if (r.nextBoolean()) 'S' else 'H'
        }
        if (isBoss) {
            val bt = l / 6
            put('#', lim + 4, W - 1, 10, 11); put('.', lim + 4, W - 4, 0, 9)
            map[9][lim + 6] = 'C'
            put('#', W - 3, W - 1, 2, 9)
            put('P', W - 27, W - 24, 7, 7); put('P', W - 18, W - 15, 7, 7)
            bossMax = max(3, (BHP[bt] * (when (dif) { 0 -> 0.7f; 1 -> 1f; else -> 1.5f })).toInt())
            val bo = Boss(W - 16f, 10f - BOSS_H[bt], bossMax, bt)
            if (bt == 2) bo.armor = 2
            boss = bo
        }
        for (e in enemies) e.vx *= em()
        put('G', W - 6, W - 6, 6, 9)
        var n = 0
        for (row in map) for (ch in row) if (ch == 'o') n++
        gemTotal = n
        cpX = 2f; cpY = 8f
    }

    private fun startLevel(i: Int) {
        load(i)
        hp = maxHp(); gems = 0; lvCoins = 0; doubled = false; shield = false; wasGround = false; dashCd = 0f; camX = 0f; res = 0; paused = false; intro = if (i % 6 == 5) 3.8f else 2.2f; dashT = 0f; scr = 5
        respawn(); inv = 0f
    }

    private fun respawn() { p.x = cpX; p.y = cpY; p.vx = 0f; p.vy = 0f; inv = 1.5f; safeX = cpX; safeY = cpY }

    private fun hurt() {
        if (inv > 0f || res != 0) return
        if (shield) { shield = false; inv = 1.2f; shake = 0.2f; burst(p.x + 0.4f, p.y + 0.5f, 0xFF4DF3FF, 14); beep(ToneGenerator.TONE_PROP_NACK); return }
        hp--; inv = invT(); shake = 0.35f; flash = 0.35f; hitStop = 0.08f; buzz(); beep(ToneGenerator.TONE_PROP_NACK)
        burst(p.x + 0.4f, p.y + 0.5f, 0xFFFF3D00, 12)
        if (hp <= 0) { res = 2; sfx(13); save() } else { p.vy = -9f; p.vx = -face * 5f }
    }

    private fun win() {
        if (res != 0) return
        res = 1
        val st = if (gems >= gemTotal) 3 else if (gems * 10 >= gemTotal * 6) 2 else 1
        if (st > stars[lv]) stars[lv] = st
        lastStars = st
        earn(st * 5)
        unlocked = max(unlocked, min(36, lv + 2))
        sfx(12); save()
    }

    private fun collectGem(tx: Int, ty: Int) {
        map[ty][tx] = '.'; gems++; earn(1)
        burst(tx + 0.5f, ty + 0.5f, 0xFF4DF3FF, 8); beep(ToneGenerator.TONE_PROP_BEEP); ring(tx + 0.5f, ty + 0.5f, 0xFF4DF3FF); pop("+1", tx + 0.5f, ty.toFloat(), 0xFF7DF9FF)
    }

    private fun upgrade(j: Int) {
        val lvl = upLevel(j)
        val cost = 150 * (lvl + 1)
        if (lvl >= 3) { msg = "Mejora al máximo"; msgT = 2f }
        else if (coins >= cost) {
            coins -= cost
            when (j) { 0 -> upHp++; 1 -> upDash++; else -> upMag++ }
            sfx(10)
        } else { sfx(11); msg = "Te faltan ${cost - coins} monedas"; msgT = 2f }
        save()
    }

    private fun gift() {
        val today = System.currentTimeMillis() / 86400000L
        if (giftState == 0) {
            streak = if (lastDay == today - 1) (streak + 1) % 7 else 0
            lastGift = DAILY[streak]
            coins += lastGift; lastDay = today; giftState = 1
            msg = "¡+$lastGift monedas! Racha: ${streak + 1} día(s)"; msgT = 2.5f
            beep(ToneGenerator.TONE_PROP_ACK); save()
        } else if (giftState == 1) showAd(3)
    }

    private fun buy(j: Int) {
        if ((owned and (1 shl j)) != 0) { skin = j; sfx(9) }
        else if (coins >= SK_P[j]) { coins -= SK_P[j]; owned = owned or (1 shl j); skin = j; sfx(10) }
        else { sfx(11); msg = "Te faltan ${SK_P[j] - coins} monedas"; msgT = 2f }
        save()
    }

    // ---------- Física ----------
    private fun hit(b: Body): Boolean {
        for (ty in floor(b.y).toInt()..floor(b.y + b.h - 0.0001f).toInt())
            for (tx in floor(b.x).toInt()..floor(b.x + b.w - 0.0001f).toInt()) {
                if (tx < 0 || tx >= W) return true
                if (ty in 0 until H && map[ty][tx] == '#') return true
            }
        return false
    }

    private fun move(b: Body, dt: Float) {
        b.vy = min(b.vy + 40f * dt, 20f)
        b.x += b.vx * dt
        b.wall = false
        if (hit(b)) { b.wall = true; b.x = if (b.vx > 0) floor(b.x + b.w - 0.0001f) - b.w else floor(b.x) + 1f }
        val before = b.y + b.h
        b.y += b.vy * dt
        b.ground = false
        if (hit(b)) {
            if (b.vy > 0) { b.y = floor(b.y + b.h - 0.0001f) - b.h; b.ground = true } else b.y = floor(b.y) + 1f
            b.vy = 0f
        } else if (b.vy > 0f) {
            val ty = floor(b.y + b.h).toInt()
            if (ty in 0 until H && before <= ty + 0.05f) {
                for (tx in floor(b.x).toInt()..floor(b.x + b.w - 0.0001f).toInt())
                    if (tx in 0 until W && map[ty][tx] == 'P') { b.y = ty - b.h; b.ground = true; b.vy = 0f; break }
            }
        }
    }

    private fun overlap(a: Body, b: Body) = a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y

    private fun bossStun(t: Int) = when (t) { 4 -> 2; 5 -> 4; else -> 3 }
    private fun bossVuln(bs: Boss) = !bs.hidden && bs.state == bossStun(bs.type) && !(bs.type == 2 && bs.armor > 0)

    private fun shot(kind: Int, x: Float, y: Float, vx: Float, vy: Float, tm: Float) {
        val b = Bullet(x, y, vx * bsp(), vy * bsp(), kind)
        b.tm = tm
        when (kind) {
            1 -> { b.w = 0.6f; b.h = 0.6f }
            2 -> { b.w = 1.0f; b.h = 0.6f; b.life = 3f }
            3 -> { b.w = 0.5f; b.h = 1.1f; b.life = 6f }
            4 -> { b.w = 0.5f; b.h = 0.5f; b.life = 6f }
            5 -> { b.w = 0.9f; b.h = 8f; b.life = 5f }
        }
        bullets.add(b)
    }

    private fun updateBoss(bs: Boss, dt: Float) {
        val rate = brate()
        bs.inv -= dt; bs.tm -= dt * rate; bs.t2 -= dt * rate
        val ph2 = bs.hp * 2 <= bs.maxHp
        val ax0 = W - 31f; val ax1 = W - 6f - bs.w
        val toP = if (p.x + 0.4f < bs.x + bs.w / 2) -1f else 1f
        val cx = bs.x + bs.w / 2
        bs.warn = false
        when (bs.type) {
            0 -> { when (bs.state) {
                0 -> { bs.vx = toP * 2f; if (bs.tm <= 0f) { for (i in (if (ph2) -2..2 else -1..1)) shot(0, cx, bs.y + 0.7f, toP * 5f, i * 1.5f, 0f); sfx(7); bs.state = 1; bs.tm = 0.8f; bs.vx = 0f; sfx(18) } }
                1 -> { bs.warn = true; bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 2; bs.tm = 1.1f; bs.dir = toP.toInt(); bs.vy = -13f } }
                2 -> { bs.vx = bs.dir * 9f; if (bs.tm <= 0f || bs.wall) { bs.state = 3; bs.tm = 1.8f; bs.vx = 0f; shake = 0.25f } }
                else -> { bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 0; bs.tm = 2.2f } }
            } }
            1 -> { when (bs.state) {
                0 -> { bs.vx = toP * 2.4f; if (bs.tm <= 0f) { shot(2, if (toP > 0f) bs.x + bs.w else bs.x - 1f, 9.4f, toP * 5.5f, 0f, 0f); sfx(7); bs.state = 1; bs.tm = 1.1f; bs.vx = 0f; bs.hidden = true; bs.tx = p.x + 0.4f } }
                1 -> {
                    bs.hidden = true; bs.warn = true; bs.vx = 0f
                    if (rnd.nextFloat() < 0.3f) burst(bs.tx, 9.9f, 0xFFD7A86E, 1)
                    if (bs.tm <= 0f) {
                        bs.x = bs.tx - bs.w / 2; bs.y = 10f - bs.h; bs.vy = -9f; bs.hidden = false
                        shot(2, bs.x + bs.w, 9.4f, 5f, 0f, 0f); shot(2, bs.x - 1f, 9.4f, -5f, 0f, 0f)
                        shake = 0.3f; sfx(18); burst(bs.tx, 9.8f, 0xFFD7A86E, 16)
                        if (abs(p.x + 0.4f - bs.tx) < bs.w / 2 + 0.4f && p.y + p.h > 8.4f) hurt()
                        bs.state = 3; bs.tm = 1.8f
                    }
                }
                else -> { bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 0; bs.tm = 1.8f } }
            } }
            2 -> { when (bs.state) {
                0 -> { bs.vx = 0f; if (bs.tm <= 0f) { for (i in 0..(if (ph2) 3 else 2)) shot(3, (p.x + (i - 1) * 3.3f + rnd.nextFloat() * 1.5f).coerceIn(ax0, ax1 + bs.w), 2f, 0f, 0f, 0.9f + i * 0.35f); bs.state = 1; bs.tm = 2.2f } }
                1 -> { bs.warn = true; bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 2; bs.tm = 0.5f; bs.vy = -12f } }
                2 -> { bs.vx = toP * 1.5f; if (bs.tm <= 0f && bs.ground) { shot(2, bs.x + bs.w, 9.4f, 4.5f, 0f, 0f); shot(2, bs.x - 1f, 9.4f, -4.5f, 0f, 0f); shake = 0.35f; sfx(18); burst(cx, 9.9f, 0xFF9BE7FF, 14); bs.state = 3; bs.tm = 2f; bs.vx = 0f } }
                else -> { bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 0; bs.tm = 1.2f } }
            } }
            3 -> { when (bs.state) {
                0 -> {
                    bs.fly = true; bs.vx = 0f; bs.vy = 0f
                    val tx2 = (p.x - bs.w / 2 + sin(time * 0.9f) * 3f).coerceIn(ax0, ax1)
                    bs.x += (tx2 - bs.x) * min(1f, 2f * dt); bs.y += ((4.2f + sin(time * 2f) * 0.5f) - bs.y) * min(1f, 3f * dt)
                    if (bs.t2 <= 0f) { bs.t2 = if (ph2) 0.8f else 1.2f; shot(1, cx, bs.y + 1f, ((p.x - cx) * 0.55f).coerceIn(-4f, 4f), -3f, 0f); sfx(7) }
                    if (bs.tm <= 0f) { bs.state = 1; bs.tm = 0.9f }
                }
                1 -> {
                    bs.warn = true; bs.fly = true
                    val sx = if (p.x > (ax0 + ax1) / 2) ax0 else ax1
                    bs.x += (sx - bs.x) * min(1f, 5f * dt); bs.y += (4f - bs.y) * min(1f, 5f * dt)
                    if (bs.tm <= 0f) { bs.state = 2; bs.tm = 2.2f; bs.dir = if (bs.x < (ax0 + ax1) / 2) 1 else -1; sfx(18) }
                }
                2 -> {
                    bs.fly = true; bs.y += (8.3f - bs.y) * min(1f, 8f * dt); bs.x += bs.dir * 9f * dt
                    if (bs.t2 <= 0f) { bs.t2 = 0.18f; burst(bs.x + bs.w / 2, bs.y + 1f, 0xFFFF6D00, 3) }
                    if (bs.x <= ax0 || bs.x >= ax1 || bs.tm <= 0f) { bs.state = 3; bs.tm = 2.2f; bs.fly = false; bs.vy = 0f; shake = 0.3f }
                }
                else -> { bs.fly = false; bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 0; bs.tm = 5f; bs.fly = true } }
            } }
            4 -> { when (bs.state) {
                0 -> {
                    bs.fly = true
                    bs.x += (((ax0 + ax1) / 2 + sin(time * 0.8f) * 5f) - bs.x) * min(1f, 2f * dt); bs.y += ((6f + sin(time * 1.7f) * 0.4f) - bs.y) * min(1f, 3f * dt)
                    if (bs.t2 <= 0f) { bs.t2 = 1.5f; for (i in 0..(if (ph2) 2 else 1)) shot(4, cx + (i - 0.5f) * 1.2f, bs.y + 0.5f, (i - 0.5f) * 2f, -1f, 0f); sfx(7) }
                    if (bs.tm <= 0f) { bs.state = 1; bs.tm = 0.8f }
                }
                1 -> {
                    bs.warn = true; bs.fly = true
                    if (bs.tm <= 0f) { if (enemies.size < 4) { enemies.add(Enemy(ax0 + 1f, 9.2f, 0)); enemies.add(Enemy(ax1 + bs.w - 1f, 9.2f, 0)) }; bs.state = 2; bs.tm = 2f; sfx(18) }
                }
                else -> { bs.fly = true; bs.y += (7.9f - bs.y) * min(1f, 5f * dt); if (bs.tm <= 0f) { bs.state = 0; bs.tm = 4.5f } }
            } }
            else -> { when (bs.state) {
                0 -> {
                    bs.fly = true; bs.hidden = false; bs.y += ((5f + sin(time * 2f) * 0.3f) - bs.y) * min(1f, 3f * dt)
                    if (bs.tm <= 0f) { bs.state = 1; bs.tm = 0.5f; bs.hidden = true; bs.tx = rnd.nextFloat() * (ax1 - ax0) + ax0 }
                }
                1 -> {
                    bs.hidden = true; bs.warn = true
                    if (bs.tm <= 0f) {
                        bs.x = bs.tx; bs.y = 4.5f; bs.hidden = false
                        val n = if (ph2) 12 else 8
                        for (i in 0 until n) { val a = i * 6.2831855f / n; shot(0, bs.x + bs.w / 2, bs.y + 0.9f, cos(a) * 4f, sin(a) * 4f, 0f) }
                        if (ph2) shot(4, bs.x + bs.w / 2, bs.y + 0.9f, 0f, 1f, 0f)
                        sfx(7); sfx(18); bs.state = 2; bs.tm = 0.9f
                    }
                }
                2 -> { bs.fly = true; if (bs.tm <= 0f) { for (i in -1..1) shot(5, p.x + 0.4f + i * 3.2f - 0.45f, 2f, 0f, 0f, 0.95f); bs.state = 3; bs.tm = 1.8f; sfx(18) } }
                3 -> { bs.fly = true; if (bs.tm <= 0f) { bs.state = 4; bs.tm = 2f } }
                else -> { bs.fly = true; bs.y += (8.1f - bs.y) * min(1f, 5f * dt); if (bs.tm <= 0f) { bs.state = 0; bs.tm = 1.4f } }
            } }
        }
        if (!bs.fly) move(bs, dt)
        bs.x = bs.x.coerceIn(ax0, ax1)
        if (bs.hidden || res != 0 || !overlap(p, bs)) return
        val stomp = p.vy > 0f && p.y + p.h < bs.y + 0.7f
        val vul = bossVuln(bs)
        if (stomp || dashT > 0f) {
            if (bs.inv <= 0f) {
                if (bs.type == 2 && bs.armor > 0 && dashT > 0f) {
                    bs.armor--; bs.inv = 0.5f; sfx(17); ring(cx, bs.y + bs.h / 2, 0xFF9BE7FF); hitStop = 0.08f; burst(cx, bs.y + 1f, 0xFF9BE7FF, 14); shake = max(shake, 0.2f)
                } else if (vul) {
                    bs.hp--; bs.inv = 1.2f; bs.state = bossStun(bs.type); bs.tm = 1.8f; bs.vx = 0f
                    bs.fly = bs.type == 4 || bs.type == 5
                    if (bs.type == 2) bs.armor = 2
                    p.vy = -12f; jumps = 1; spr = true; shake = 0.3f; buzz(); hitStop = 0.1f; zoom = 0.05f
                    burst(cx, bs.y + bs.h / 2, 0xFFFFD740, 20); sfx(17); ring(cx, bs.y + bs.h / 2, 0xFFFFD740)
                    if (bs.hp <= 0) { boss = null; bullets.clear(); earn(25 + 10 * bs.type); burst(cx, bs.y + bs.h / 2, 0xFFFF5C8A, 30); sfx(8); zoom = 0.08f; hitStop = 0.25f; pop("¡JEFE VENCIDO!", cx, bs.y, 0xFFFFE066) }
                } else if (stomp) { p.vy = -11f; jumps = 1; spr = true; bs.inv = 0.3f; sfx(17); ring(cx, bs.y, 0xFFFFFFFF) }
            }
        } else if (!vul) hurt()
    }

    private fun updatePlats(dt: Float) {
        for (q in plats) {
            val ox = q.x; val oy = q.y
            when (q.kind) {
                0 -> q.x = q.x0 + sin(time * 6.2831855f / q.per + q.ph * 6.28f) * q.amp
                1 -> q.y = q.y0 + sin(time * 6.2831855f / q.per + q.ph * 6.28f) * q.amp
                2 -> {
                    if (q.stepped) q.t += dt
                    if (q.t > 0.45f) { q.solid = false; q.fall += dt * 18f; q.y += q.fall * dt }
                    if (q.t > 3.2f) { q.t = 0f; q.stepped = false; q.solid = true; q.fall = 0f; q.y = q.y0 }
                }
                3 -> { val c0 = (time / q.per + q.ph) % 1f; q.solid = c0 < 0.6f; q.warn = c0 > 0.45f && c0 < 0.6f }
                else -> { val cy = time / q.per + q.ph; q.x = if (floor(cy).toInt() % 2 == 0) q.x0 else q.x0 + q.amp; q.warn = (cy - floor(cy)) > 0.75f }
            }
            q.dx = q.x - ox; q.dy = q.y - oy
        }
    }

    private fun updateTraps(dt: Float) {
        val px = p.x + p.w / 2
        for (tx in max(0, floor(px - 2f).toInt())..min(W - 1, floor(px + 2f).toInt()))
            if (map[9][tx] == 'x' && abs(tx + 0.5f - px) < 1.7f && p.y + p.h > 8.2f) {
                map[9][tx] = 'y'; traps.add(floatArrayOf(tx.toFloat(), 9f, 0.4f)); burst(tx + 0.5f, 9.9f, 0xFFB0BEC5, 5); sfx(9)
            }
        for (t in traps) {
            t[2] -= dt
            if (t[2] <= 0f) { map[t[1].toInt()][t[0].toInt()] = '^'; burst(t[0] + 0.5f, 9.6f, 0xFFFFFFFF, 6); sfx(15) }
        }
        traps.removeAll { it[2] <= 0f }
        for (lz in lasers) {
            val ph = (time / lz[1] + lz[2]) % 1f
            if (ph > 0.6f && res == 0 && dashT <= 0f && abs(px - (lz[0] + 0.5f)) < 0.4f) hurt()
        }
    }

    private fun update(dt0: Float) {
        if (hitStop > 0f) hitStop -= dt0
        val dt = if (hitStop > 0f) dt0 * 0.2f else dt0
        time += dt
        while (true) { val t = taps.poll() ?: break; tap(t.x, t.y) }
        layout()
        if (adDone) { adDone = false; if (adReward) grant(adMode); adMode = 0; adReward = false }
        adT -= dt
        if (adT <= 0f) { adT = 15f; loadAd() }
        for (q in parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 12f * dt; q.life -= dt }
        parts.removeAll { it.life <= 0f }
        for (r in rings) r.life -= dt
        rings.removeAll { it.life <= 0f }
        for (t in pops) { t.life -= dt; t.y -= dt * 1.2f }
        pops.removeAll { it.life <= 0f }
        if (flash > 0f) flash -= dt
        if (squashT > 0f) squashT -= dt
        if (zoom > 0f) zoom -= dt * 0.35f
        if (shake > 0f) shake -= dt
        if (msgT > 0f) msgT -= dt
        if (scr != lastScr) { fade = 1f; lastScr = scr }
        if (fade > 0f) fade -= dt * 3f
        if (rT > 0f) rT -= dt * 2.5f
        for (g in ghosts) g[2] -= dt
        ghosts.removeAll { it[2] <= 0f }
        audio.music(if (scr != 5) 0 else if (boss != null && p.x > W - 40f) 7 else 1 + lv / 6)
        audio.setVol(if (scr == 5 && !paused && res == 0) 1f else 0.45f)
        if (scr != 5 || paused || res != 0) return

        intro -= dt; inv -= dt; dashCd -= dt
        updatePlats(dt); updateTraps(dt)
        val vw = width / (height / H.toFloat())
        camX += ((p.x + face * 1.5f - vw * 0.4f).coerceIn(0f, W - vw) - camX) * min(1f, 6f * dt)
        val dir = (if (goR) 1 else 0) - (if (goL) 1 else 0)
        if (dir != 0) face = dir
        if (dashT > 0f) {
            dashT -= dt; p.vx = face * 14f; p.vy = 0f
            burst(p.x + p.w / 2, p.y + p.h / 2, acc(), 2); ghosts.add(floatArrayOf(p.x, p.y, 0.25f))
        } else p.vx += (dir * 6.2f - p.vx) * min(1f, 12f * dt)
        if (goJ && !jPrev) {
            if (p.ground) { p.vy = -16f; jumps = 1; beep(ToneGenerator.TONE_DTMF_1); ring(p.x + 0.4f, p.y + p.h, acc()); burst(p.x + 0.4f, p.y + p.h, acc(), 7) }
            else if (jumps < 2) { p.vy = -14f; jumps = 2; beep(ToneGenerator.TONE_DTMF_3); burst(p.x + p.w / 2, p.y + p.h, 0xFFFFFFFF, 8); ring(p.x + p.w / 2, p.y + p.h, 0xFFFF2BD6) }
        }
        jPrev = goJ
        if (p.vy >= 0f) spr = false
        if (!goJ && !spr && p.vy < -5f && dashT <= 0f) p.vy = -5f
        if (goD && !dPrev && dashCd <= 0f && dashT <= 0f) { dashT = 0.18f; dashCd = 0.9f - 0.15f * upDash; beep(ToneGenerator.TONE_DTMF_9); buzz(); ring(p.x + 0.4f, p.y + 0.5f, acc()); shake = max(shake, 0.1f); zoom = 0.05f }
        dPrev = goD
        ride?.let { rp -> if (rp.solid) { p.x += rp.dx; p.y += rp.dy } }
        val bfr = p.y + p.h
        val vyB = p.vy
        move(p, dt)
        ride = null
        if (!p.ground && p.vy >= 0f) for (q in plats) {
            if (!q.solid) continue
            if (p.x + p.w > q.x + 0.08f && p.x < q.x + q.w - 0.08f && bfr <= q.y + 0.15f && p.y + p.h >= q.y - 0.02f) {
                p.y = q.y - p.h; p.vy = 0f; p.ground = true; ride = q
                if (q.kind == 2) q.stepped = true
                break
            }
        }
        if (p.ground) { jumps = 0; safeX = p.x; safeY = p.y }
        if (p.ground && !wasGround) { burst(p.x + 0.4f, p.y + p.h, 0x88FFFFFF, 5); sfx(15); if (vyB > 9f) { squashT = 0.14f; ring(p.x + 0.4f, p.y + p.h, 0xFFFFFFFF); shake = max(shake, min(0.2f, (vyB - 9f) * 0.02f)) } }
        if (p.ground && abs(p.vx) > 3f && time - lastStep > 0.27f) { lastStep = time; sfx(16) }
        if (p.ground && abs(p.vx) > 4f && rnd.nextFloat() < 0.25f) burst(p.x + 0.4f, p.y + p.h, acc(), 1)
        wasGround = p.ground
        if (upMag > 0) {
            val rr = 1.2f + upMag
            for (ty in max(0, floor(p.y - rr).toInt())..min(H - 1, floor(p.y + rr).toInt()))
                for (tx in max(0, floor(p.x - rr).toInt())..min(W - 1, floor(p.x + rr).toInt()))
                    if (map[ty][tx] == 'o' && hypot(tx + 0.5f - p.x - 0.4f, ty + 0.5f - p.y - 0.5f) < rr) collectGem(tx, ty)
        }

        for (ty in floor(p.y).toInt()..floor(p.y + p.h - 0.0001f).toInt())
            for (tx in floor(p.x).toInt()..floor(p.x + p.w - 0.0001f).toInt()) {
                if (tx !in 0 until W || ty !in 0 until H) continue
                when (map[ty][tx]) {
                    'o' -> collectGem(tx, ty)
                    'S' -> { map[ty][tx] = '.'; shield = true; burst(tx + 0.5f, ty + 0.5f, 0xFF4DF3FF, 10); beep(ToneGenerator.TONE_PROP_ACK) }
                    'H' -> if (hp < maxHp()) { map[ty][tx] = '.'; hp++; burst(tx + 0.5f, ty + 0.5f, 0xFFFF5252, 10); beep(ToneGenerator.TONE_PROP_ACK) }
                    'C' -> if (cpX != tx.toFloat()) { cpX = tx.toFloat(); cpY = 8f; sfx(14) }
                    'G' -> if (boss == null) win() else { msg = "¡Derrota al jefe primero!"; msgT = 1.5f }
                    '=' -> if (p.vy >= 0f) { p.vy = -23f; jumps = 1; spr = true; beep(ToneGenerator.TONE_DTMF_5); ring(p.x + 0.4f, p.y + p.h, 0xFFFFC107); burst(p.x + 0.4f, p.y + p.h, 0xFFFFC107, 10); shake = max(shake, 0.12f) }
                    '^' -> if (p.y + p.h > ty + 0.5f) hurt()
                }
            }

        for (e in enemies) {
            if (e.dead) { e.t += dt; continue }
            if (abs(e.x - p.x) > 18f) continue
            when (e.kind) {
                2 -> {
                    if (abs(e.x - p.x) < 10f) e.vx = sign(p.x - e.x) * 1.8f * em()
                    e.x += e.vx * dt; e.y = e.y0 + sin(time * 3f + e.x) * 1.2f
                }
                3 -> {
                    e.cd -= dt
                    if (e.cd <= 0f && e.x > p.x && e.x - p.x < 14f) { e.cd = 2.2f / em(); bullets.add(Bullet(e.x, e.y + 0.25f, -6f * bsp())); beep(ToneGenerator.TONE_DTMF_7) }
                }
                else -> { move(e, dt); if (e.wall) e.vx = -e.vx }
            }
            if (e.y > 14f) { e.dead = true; e.t = 9f; continue }
            if (res == 0 && overlap(p, e)) {
                if (dashT > 0f || (p.vy > 0f && !e.spiky && p.y + p.h < e.y + 0.6f)) {
                    e.dead = true; earn(2)
                    burst(e.x + 0.4f, e.y + 0.4f, 0xFFFF5C8A, 12); sfx(5); ring(e.x + 0.4f, e.y + 0.4f, 0xFFFF5C8A); pop("+2", e.x + 0.4f, e.y, 0xFFFFE066); hitStop = 0.06f; shake = max(shake, 0.12f)
                    if (dashT <= 0f) { p.vy = -10f; jumps = 1; spr = true }
                } else hurt()
            }
        }
        enemies.removeAll { it.dead && it.t > 0.4f }
        for (b in bullets) {
            if (b.tm > 0f) { b.tm -= dt; if (b.tm <= 0f && b.kind == 5) { b.life = 0.5f; sfx(7) }; continue }
            b.life -= dt
            when (b.kind) {
                1 -> { b.vy += 18f * dt; b.x += b.vx * dt; b.y += b.vy * dt; if (b.y > 9.4f) { b.life = 0f; burst(b.x, 9.8f, 0xFFFF9100, 8) } }
                2 -> b.x += b.vx * dt
                3 -> { b.vy += 22f * dt; b.y += b.vy * dt; if (b.y > 8.9f) { b.life = 0f; burst(b.x, 9.8f, 0xFF9BE7FF, 8) } }
                4 -> {
                    val ddx = p.x + 0.4f - b.x; val ddy = p.y + 0.5f - b.y; val dd = max(0.1f, hypot(ddx, ddy))
                    b.vx += ddx / dd * 5f * dt; b.vy += ddy / dd * 5f * dt
                    val spd = hypot(b.vx, b.vy); val mx = 3.2f * bsp()
                    if (spd > mx) { b.vx *= mx / spd; b.vy *= mx / spd }
                    b.x += b.vx * dt; b.y += b.vy * dt
                }
                5 -> { }
                else -> { b.x += b.vx * dt; b.y += b.vy * dt }
            }
            if (b.x < -2f || b.x > W + 2f) b.life = 0f
            val bx = floor(b.x).toInt(); val by = floor(b.y).toInt()
            if (b.kind == 0 && bx in 0 until W && by in 0 until H && map[by][bx] == '#') b.life = 0f
            else if (res == 0 && b.x < p.x + p.w && b.x + b.w > p.x && b.y < p.y + p.h && b.y + b.h > p.y) {
                if (dashT > 0f) { if (b.kind == 0 || b.kind == 1 || b.kind == 4) { b.life = 0f; burst(b.x, b.y, 0xFFFFAB40, 8) } }
                else { if (b.kind != 5) b.life = 0f; hurt() }
            }
        }
        bullets.removeAll { it.life <= 0f }
        boss?.let { bs -> updateBoss(bs, dt) }
        if (res == 0 && p.y > 13f) {
            hp--; buzz(); shake = 0.4f; flash = 0.35f
            if (hp <= 0) { res = 2; sfx(13); save() } else respawn()
        }
    }

    // ---------- Interfaz ----------
    private fun addBtn(cx: Float, cy: Float, w: Float, h: Float, label: String, sub: String = "", act: () -> Unit) {
        btns.add(Btn(RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), label, sub, act))
    }

    private fun controls() {
        val w = width.toFloat(); val h = height.toFloat()
        val s = h * (0.2f + 0.04f * ctl); val m = h * 0.04f
        bL = RectF(m, h - m - s, m + s, h - m)
        bR = RectF(m * 2 + s, h - m - s, m * 2 + s * 2, h - m)
        bJ = RectF(w - m - s * 1.2f, h - m - s * 1.2f, w - m, h - m)
        bD = RectF(w - m * 2 - s * 2.1f, h - m - s * 0.9f, w - m * 2 - s * 1.2f, h - m)
    }

    private fun layout() {
        btns.clear()
        val w = width.toFloat(); val h = height.toFloat()
        val bw = h * 1.1f; val bh = h * 0.12f
        val back = { addBtn(w * 0.14f, h * 0.9f, h * 0.45f, h * 0.11f, "ATRÁS") { scr = 1; confirm = false } }
        when (scr) {
            1 -> {
                val b2 = h * 0.1f
                addBtn(w / 2, h * 0.32f, bw, h * 0.115f, "REGALO DIARIO", when (giftState) { 0 -> "¡RECLAMAR!"; 1 -> "DUPLICAR: VER ANUNCIO"; else -> "VUELVE MAÑANA" }) { scr = 6 }
                addBtn(w / 2, h * 0.46f, bw, b2, "JUGAR") { wPage = lv / 6; scr = 2 }
                addBtn(w / 2, h * 0.59f, bw, b2, "TIENDA") { scr = 3 }
                addBtn(w / 2, h * 0.72f, bw, b2, "AJUSTES") { scr = 4 }
                addBtn(w / 2, h * 0.85f, bw, b2, "SALIR") { post { (context as Activity).finish() } }
            }
            2 -> {
                for (i in 0 until 6) {
                    val li = wPage * 6 + i
                    val cx = w / 2 + (i % 3 - 1) * h * 0.42f
                    val cy = h * 0.46f + (i / 3) * h * 0.27f
                    addBtn(cx, cy, h * 0.37f, h * 0.24f, "${li + 1}", if (li < unlocked) stars3(stars[li]) else "BLOQ.") { if (li < unlocked) startLevel(li) }
                }
                if (wPage > 0) addBtn(w * 0.1f, h * 0.58f, h * 0.16f, h * 0.16f, "<") { wPage-- }
                if (wPage < 5) addBtn(w * 0.9f, h * 0.58f, h * 0.16f, h * 0.16f, ">") { wPage++ }
                back()
            }
            3 -> {
                val gap = min(h * 0.7f, w * 0.31f); val cw = min(h * 0.66f, w * 0.29f)
                if (shopTab == 0) for (j in 0 until 6) {
                    val cx = w / 2 + (j % 3 - 1) * gap
                    val cy = h * 0.30f + (j / 3) * h * 0.36f
                    addBtn(cx, cy, cw, h * 0.33f, "") { buy(skinPage * 6 + j) }
                } else for (j in 0 until 3) addBtn(w / 2 + (j - 1) * gap, h * 0.5f, cw, h * 0.5f, "") { upgrade(j) }
                back()
                addBtn(w * 0.84f, h * 0.9f, h * 0.55f, h * 0.11f, if (shopTab == 0) "MEJORAS" else "SKINS") { shopTab = 1 - shopTab }
                if (shopTab == 0) addBtn(w * 0.5f, h * 0.9f, h * 0.5f, h * 0.11f, "PÁGINA ${skinPage + 1}/2") { skinPage = 1 - skinPage }
            }
            4 -> {
                val sw = h * 1.4f; val sh = h * 0.09f
                addBtn(w / 2, h * 0.2f, sw, sh, "SONIDO: " + (if (snd) "SÍ" else "NO")) { snd = !snd; audio.sfxOn = snd; save() }
                addBtn(w / 2, h * 0.31f, sw, sh, "MÚSICA: " + (if (mus) "SÍ" else "NO")) { mus = !mus; audio.enableMusic(mus); save() }
                addBtn(w / 2, h * 0.42f, sw, sh, "VIBRACIÓN: " + (if (hap) "SÍ" else "NO")) { hap = !hap; save() }
                addBtn(w / 2, h * 0.53f, sw, sh, "CONTROLES: " + arrayOf("PEQUEÑOS", "MEDIANOS", "GRANDES")[ctl]) { ctl = (ctl + 1) % 3; save(); controls() }
                addBtn(w / 2, h * 0.64f, sw, sh, "DIFICULTAD: " + arrayOf("FÁCIL", "NORMAL", "DIFÍCIL")[dif]) { dif = (dif + 1) % 3; save(); msg = arrayOf("Fácil: 5 vidas, enemigos lentos, jefes -30% y más checkpoints", "Normal: 3 vidas, experiencia equilibrada", "Difícil: 2 vidas, enemigos +25%, jefes +50%, más trampas. ¡Monedas x1.5!")[dif]; msgT = 3.5f }
                addBtn(w / 2, h * 0.75f, sw, sh, if (confirm) "¿SEGURO? TOCA OTRA VEZ" else "BORRAR PROGRESO") {
                    if (confirm) { coins = 0; unlocked = 1; owned = 1; skin = 0; stars.fill(0); upHp = 0; upDash = 0; upMag = 0; confirm = false; save() } else confirm = true
                }
                back()
            }
            6 -> {
                addBtn(w / 2, h * 0.76f, bw, h * 0.14f, when (giftState) { 0 -> "¡RECLAMAR!"; 1 -> "DUPLICAR HOY"; else -> "VUELVE MAÑANA" },
                    when (giftState) { 0 -> "+${DAILY[nextDay()]} MONEDAS"; 1 -> "VER ANUNCIO  (+$lastGift)"; else -> "" }) { gift() }
                back()
            }
            5 -> {
                if (res == 0 && !paused) addBtn(w - h * 0.08f, h * 0.09f, h * 0.1f, h * 0.1f, "II") { paused = true }
                else if (res == 0) {
                    addBtn(w / 2, h * 0.45f, bw, bh, "CONTINUAR") { paused = false }
                    addBtn(w / 2, h * 0.60f, bw, bh, "REINICIAR") { startLevel(lv) }
                    addBtn(w / 2, h * 0.75f, bw, bh, "NIVELES") { wPage = lv / 6; scr = 2; save() }
                } else if (res == 1) {
                    if (!doubled) addBtn(w / 2, h * 0.47f, bw, h * 0.14f, "DUPLICAR MONEDAS", "VER ANUNCIO  (+$lvCoins)") { showAd(2) }
                    var y = 0.61f
                    if (lv < 35) { addBtn(w / 2, h * y, bw, bh, "SIGUIENTE") { startLevel(lv + 1) }; y += 0.14f }
                    addBtn(w / 2, h * y, bw, bh, "REINTENTAR") { startLevel(lv) }
                    addBtn(w / 2, h * (y + 0.14f), bw, bh, "NIVELES") { wPage = lv / 6; scr = 2 }
                } else {
                    addBtn(w / 2, h * 0.50f, bw, h * 0.15f, "REVIVIR AQUÍ", "VER ANUNCIO") { showAd(1) }
                    addBtn(w / 2, h * 0.68f, bw, bh, "REINTENTAR") { startLevel(lv) }
                    addBtn(w / 2, h * 0.83f, bw, bh, "NIVELES") { wPage = lv / 6; scr = 2 }
                }
            }
        }
    }

    private fun tap(x: Float, y: Float) {
        if (scr == 0) { scr = 1; sfx(9); rx = x; ry = y; rT = 1f; return }
        rx = x; ry = y; rT = 1f
        for (b in btns) if (b.r.contains(x, y)) { sfx(9); b.act(); buzz(); return }
    }

    // ---------- Bucle y ciclo de vida ----------
    override fun surfaceCreated(sh: SurfaceHolder) { running = true; audio.resume(); thread = Thread(this).also { it.start() } }
    override fun surfaceChanged(sh: SurfaceHolder, f: Int, w: Int, h: Int) {}
    override fun surfaceDestroyed(sh: SurfaceHolder) {
        running = false; thread?.join(); thread = null
        audio.pause()
        if (scr == 5 && res == 0) paused = true
        save()
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min((now - last) / 1e9f, 0.033f)
            last = now
            update(dt)
            val c = (try { if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas() } catch (e: Exception) { holder.lockCanvas() }) ?: continue
            try { render(c) } finally { holder.unlockCanvasAndPost(c) }
            val spent = (System.nanoTime() - now) / 1_000_000
            if (spent < 16) Thread.sleep(16 - spent)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); controls() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) taps.add(PointF(e.getX(e.actionIndex), e.getY(e.actionIndex)))
        goL = false; goR = false; goJ = false; goD = false
        if (a == MotionEvent.ACTION_CANCEL) return true
        val up = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP
        for (i in 0 until e.pointerCount) {
            if (up && i == e.actionIndex) continue
            val x = e.getX(i); val y = e.getY(i)
            if (bL.contains(x, y)) goL = true
            if (bR.contains(x, y)) goR = true
            if (bJ.contains(x, y)) goJ = true
            if (bD.contains(x, y)) goD = true
        }
        return true
    }

    // ---------- Dibujo ----------
    private fun ca(col: Int, a: Float) = (col and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    private fun lerpCol(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Long, al: Paint.Align = Paint.Align.CENTER) {
        paint.style = Paint.Style.FILL; paint.shader = null; paint.textSize = size; paint.textAlign = al
        paint.color = k(0x99000000); c.drawText(s, x + size * 0.04f, y + size * 0.06f, paint)
        paint.color = k(col); c.drawText(s, x, y, paint)
    }

    private fun title(c: Canvas, s: String, x: Float, y: Float, size: Float) {
        glowAt(c, x, y - size * 0.3f, size * 3.2f, k(0xFFFF2BD6), 0.22f)
        paint.style = Paint.Style.FILL; paint.shader = null; paint.textSize = size; paint.textAlign = Paint.Align.CENTER
        paint.color = k(0xFF0B0F1A); c.drawText(s, x + size * 0.06f, y + size * 0.08f, paint)
        paint.color = k(0xFFFF2BD6); c.drawText(s, x + size * 0.03f, y + size * 0.04f, paint)
        paint.shader = LinearGradient(0f, y - size * 0.8f, 0f, y, k(0xFFFFFFFF), k(0xFF7DF9FF), Shader.TileMode.CLAMP)
        c.drawText(s, x, y, paint); paint.shader = null
    }

    private fun glowAt(c: Canvas, cx: Float, cy: Float, r: Float, col: Int, a: Float) {
        val g = glow ?: return
        gp.colorFilter = filters.getOrPut(col) { PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN) }
        gp.alpha = (a * 255f).toInt().coerceIn(0, 255)
        rf.set(cx - r, cy - r, cx + r, cy + r)
        c.drawBitmap(g, null, rf, gp)
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float, col: Int) {
        path.reset()
        path.moveTo(cx, cy + s * 0.9f)
        path.cubicTo(cx - s * 1.3f, cy + s * 0.1f, cx - s * 0.8f, cy - s * 0.9f, cx, cy - s * 0.35f)
        path.cubicTo(cx + s * 0.8f, cy - s * 0.9f, cx + s * 1.3f, cy + s * 0.1f, cx, cy + s * 0.9f)
        path.close()
        paint.style = Paint.Style.FILL; paint.shader = null; paint.color = col; c.drawPath(path, paint)
        paint.color = k(0x55FFFFFF); c.drawCircle(cx - s * 0.4f, cy - s * 0.15f, s * 0.16f, paint)
    }

    private fun star(c: Canvas, cx: Float, cy: Float, r: Float, col: Int) {
        path.reset()
        for (i in 0 until 10) {
            val a = (-90 + i * 36) * 0.0174533f
            val rr = if (i % 2 == 0) r else r * 0.45f
            val px = cx + cos(a) * rr; val py = cy + sin(a) * rr
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close(); paint.style = Paint.Style.FILL; paint.shader = null; paint.color = col; c.drawPath(path, paint)
    }

    private fun gem(c: Canvas, cx: Float, cy: Float, s: Float, ws: Float) {
        val ww = s * 0.8f * ws
        paint.style = Paint.Style.FILL; paint.shader = null
        path.reset(); path.moveTo(cx, cy - s); path.lineTo(cx - ww, cy - s * 0.15f); path.lineTo(cx, cy + s); path.close()
        paint.color = k(0xFF7DF9FF); c.drawPath(path, paint)
        path.reset(); path.moveTo(cx, cy - s); path.lineTo(cx + ww, cy - s * 0.15f); path.lineTo(cx, cy + s); path.close()
        paint.color = k(0xFF00B8D4); c.drawPath(path, paint)
        paint.color = k(0xAAFFFFFF); c.drawCircle(cx - ww * 0.25f, cy - s * 0.35f, s * 0.12f, paint)
    }

    private fun bolt(c: Canvas, cx: Float, cy: Float, q: Float, col: Int) {
        path.reset()
        path.moveTo(cx + q * 0.2f, cy - q * 1.1f); path.lineTo(cx - q * 0.7f, cy + q * 0.15f); path.lineTo(cx - q * 0.05f, cy + q * 0.15f)
        path.lineTo(cx - q * 0.3f, cy + q * 1.1f); path.lineTo(cx + q * 0.7f, cy - q * 0.2f); path.lineTo(cx + q * 0.05f, cy - q * 0.2f)
        path.close(); paint.style = Paint.Style.FILL; paint.shader = null; paint.color = col; c.drawPath(path, paint)
    }

    private fun coinIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(cx, cy - r, cx, cy + r, k(0xFFFFE57F), k(0xFFFFA000), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint); paint.shader = null
        paint.color = k(0xFFFFCA28); c.drawCircle(cx, cy, r * 0.68f, paint)
        paint.color = k(0xFFFFE082); c.drawRect(cx - r * 0.12f, cy - r * 0.4f, cx + r * 0.12f, cy + r * 0.4f, paint)
    }

    private fun glass(c: Canvas, r: RectF, accent: Int, hi: Boolean) {
        val rad = r.height() * 0.14f
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(0x66000000); c.drawRoundRect(r.left, r.top + r.height() * 0.04f, r.right, r.bottom + r.height() * 0.04f, rad, rad, paint)
        paint.shader = LinearGradient(0f, r.top, 0f, r.bottom, k(0xDD2A1658), k(0xDD150A33), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, paint); paint.shader = null
        paint.style = Paint.Style.STROKE; paint.strokeWidth = max(2f, r.height() * 0.015f)
        paint.color = if (hi) accent else k(0x44FFFFFF)
        c.drawRoundRect(r, rad, rad, paint); paint.style = Paint.Style.FILL
    }

    private fun chip(c: Canvas, cx: Float, cy: Float, hgt: Float, col: Int, text: String) {
        paint.style = Paint.Style.FILL; paint.shader = null; paint.textSize = hgt * 0.6f; paint.textAlign = Paint.Align.CENTER
        val tw = paint.measureText(text)
        rf.set(cx - tw / 2 - hgt * 0.5f, cy - hgt / 2, cx + tw / 2 + hgt * 0.5f, cy + hgt / 2)
        paint.color = col; c.drawRoundRect(rf, hgt / 2, hgt / 2, paint)
        paint.color = k(0x33FFFFFF); c.drawRoundRect(rf.left, rf.top, rf.right, rf.centerY(), hgt / 2, hgt / 2, paint)
        txt(c, text, cx, cy + hgt * 0.21f, hgt * 0.6f, 0xFFFFFFFF)
    }

    /** Cuerpo redondeado con contorno, sombreado inferior y brillo. */
    private fun blob(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, base: Int) {
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(0xFF0B0F1A); c.drawRoundRect(l - rad * 0.12f, t - rad * 0.12f, r + rad * 0.12f, b + rad * 0.12f, rad, rad, paint)
        paint.color = base; c.drawRoundRect(l, t, r, b, rad, rad, paint)
        c.save(); c.clipRect(l - 2f, t + (b - t) * 0.55f, r + 2f, b + 2f)
        paint.color = k(0x38000000); c.drawRoundRect(l, t, r, b, rad, rad, paint)
        c.restore()
        paint.color = k(0x44FFFFFF); c.drawOval(l + (r - l) * 0.14f, t + (b - t) * 0.1f, l + (r - l) * 0.5f, t + (b - t) * 0.32f, paint)
    }

    private fun prop(c: Canvas, th: Int, x: Float, y: Float, sc: Float, v: Int) {
        paint.style = Paint.Style.FILL; paint.shader = null
        when (th) {
            0 -> {
                paint.color = k(0xFF1A1033); c.drawRect(x - sc * 0.05f, y - sc * 1.7f, x + sc * 0.05f, y, paint)
                c.drawRect(x - sc * 0.05f, y - sc * 1.7f, x + sc * 0.5f, y - sc * 1.6f, paint)
                glowAt(c, x + sc * 0.45f, y - sc * 1.55f, sc * 0.9f, k(if (v % 2 == 0) 0xFFFF2BD6 else 0xFF00F0FF), 0.8f)
                paint.color = Color.WHITE; c.drawCircle(x + sc * 0.45f, y - sc * 1.55f, sc * 0.07f, paint)
            }
            3 -> {
                path.reset(); path.moveTo(x - sc * 0.5f, y); path.lineTo(x - sc * 0.1f, y - sc * 1.5f); path.lineTo(x + sc * 0.5f, y); path.close()
                paint.color = k(0xFF2A1410); c.drawPath(path, paint)
                paint.color = k(0xFFFF6D00); c.drawRect(x - sc * 0.04f, y - sc * 1.0f, x + sc * 0.04f, y - sc * 0.2f, paint)
                glowAt(c, x, y - sc * 0.6f, sc * 1.1f, k(0xFFFF6D00), 0.45f)
            }
            4 -> {
                paint.color = k(0xFFB2DFDB); c.drawRoundRect(x - sc * 0.08f, y - sc * 0.8f, x + sc * 0.08f, y, sc * 0.06f, sc * 0.06f, paint)
                glowAt(c, x, y - sc * 0.9f, sc * 1.3f, k(if (v % 2 == 0) 0xFF00E5A0 else 0xFFE040FB), 0.55f)
                paint.color = k(if (v % 2 == 0) 0xFF1DE9B6 else 0xFFD500F9); c.drawArc(x - sc * 0.5f, y - sc * 1.4f, x + sc * 0.5f, y - sc * 0.4f, 180f, 180f, true, paint)
            }
            5 -> {
                paint.color = k(0xFF475569); c.drawRect(x - sc * 0.06f, y - sc * 1.8f, x + sc * 0.06f, y, paint)
                c.drawRect(x - sc * 0.35f, y - sc * 1.3f, x + sc * 0.35f, y - sc * 1.2f, paint)
                val on = (time * 2f + v).toInt() % 2 == 0
                glowAt(c, x, y - sc * 1.85f, sc * 0.8f, k(0xFF38BDF8), if (on) 0.9f else 0.2f)
                paint.color = if (on) k(0xFF7DD3FC) else k(0xFF334155); c.drawCircle(x, y - sc * 1.85f, sc * 0.08f, paint)
            }
            1 -> {
                paint.color = k(0xFF2E7D32)
                c.drawRoundRect(x - sc * 0.14f, y - sc * 1.2f, x + sc * 0.14f, y, sc * 0.14f, sc * 0.14f, paint)
                c.drawRoundRect(x - sc * 0.5f, y - sc * 0.9f, x - sc * 0.22f, y - sc * 0.45f, sc * 0.12f, sc * 0.12f, paint)
                c.drawRoundRect(x + sc * 0.22f, y - sc * 0.8f, x + sc * 0.5f, y - sc * 0.4f, sc * 0.12f, sc * 0.12f, paint)
                c.drawRect(x - sc * 0.5f, y - sc * 0.55f, x + sc * 0.5f, y - sc * 0.4f, paint)
                paint.color = k(0x33FFFFFF); c.drawRect(x - sc * 0.08f, y - sc * 1.15f, x - sc * 0.02f, y - sc * 0.05f, paint)
            }
            2 -> {
                paint.color = k(0xFF3E2723); c.drawRect(x - sc * 0.07f, y - sc * 0.35f, x + sc * 0.07f, y, paint)
                for (i in 0..2) {
                    path.reset()
                    path.moveTo(x - sc * (0.55f - i * 0.12f), y - sc * (0.3f + i * 0.45f)); path.lineTo(x, y - sc * (1.0f + i * 0.45f))
                    path.lineTo(x + sc * (0.55f - i * 0.12f), y - sc * (0.3f + i * 0.45f)); path.close()
                    paint.color = k(0xFF1B5E4F); c.drawPath(path, paint)
                    paint.color = k(0xFFEFFBFF); c.drawRect(x - sc * 0.12f, y - sc * (0.95f + i * 0.45f), x + sc * 0.12f, y - sc * (0.8f + i * 0.45f), paint)
                }
            }
        }
    }

    private fun mkTiles(th: Int, s: Int) {
        val T = TH[th]; val fs = s.toFloat(); val rr = Random(th * 31L + 7)
        val p2 = Paint(Paint.ANTI_ALIAS_FLAG)
        for (n in 0..2) {
            val h2 = if (n == 2) max(8, (s * 0.42f).toInt()) else s
            val b = Bitmap.createBitmap(s, h2, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b); val hf = h2.toFloat()
            val rad = if (n == 2) hf * 0.3f else 0f
            p2.shader = LinearGradient(0f, 0f, 0f, hf, k(T[7]), k(T[8]), Shader.TileMode.CLAMP)
            cv.drawRoundRect(0f, 0f, fs, hf, rad, rad, p2)
            p2.shader = null
            if (n != 2) for (i in 0 until s / 4) {
                p2.color = if (rr.nextBoolean()) 0x22FFFFFF else 0x22000000
                cv.drawCircle(rr.nextFloat() * fs, rr.nextFloat() * fs, fs * (0.02f + rr.nextFloat() * 0.04f), p2)
            }
            p2.color = 0x33FFFFFF; cv.drawRect(0f, 0f, fs, hf * 0.05f, p2)
            p2.color = 0x44000000; cv.drawRect(0f, hf * 0.94f, fs, hf, p2); cv.drawRect(fs * 0.96f, 0f, fs, hf, p2)
            if (n >= 1) {
                val cap = if (n == 2) hf * 0.38f else fs * (if (th == 0 || th == 3 || th == 5) 0.1f else 0.2f)
                p2.color = k(T[9]); cv.drawRect(0f, 0f, fs, cap, p2)
                if (th == 0 || th == 3 || th == 5) {
                    p2.shader = LinearGradient(0f, cap, 0f, cap + fs * 0.3f, ca(k(T[9]), 0.45f), ca(k(T[9]), 0f), Shader.TileMode.CLAMP)
                    cv.drawRect(0f, cap, fs, cap + fs * 0.3f, p2); p2.shader = null
                } else for (i in 0..3) { p2.color = k(T[9]); cv.drawCircle(fs * (0.12f + i * 0.25f), cap, fs * (0.08f + 0.04f * (i % 2)), p2) }
            }
            tiles[n] = b
        }
    }

    private fun prepare(w: Float, h: Float, th: Int) {
        if (glow == null) {
            val b = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
            val p2 = Paint(Paint.ANTI_ALIAS_FLAG)
            p2.shader = RadialGradient(32f, 32f, 32f, intArrayOf(Color.WHITE, 0x66FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
            Canvas(b).drawCircle(32f, 32f, 32f, p2)
            glow = b
        }
        val s = max(16, (h / H).toInt())
        if (tileKey != th * 10000 + s) { mkTiles(th, s); tileKey = th * 10000 + s }
        val key = th * 100000 + (w + h).toInt()
        if (skyKey != key) {
            val T = TH[th]
            val gy = (10f - 2.4f) * (h / H)
            skySh = LinearGradient(0f, 0f, 0f, h * 0.8f, intArrayOf(k(T[0]), k(T[1]), k(T[2])), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            sunGlowSh = RadialGradient(w * 0.74f, h * 0.3f, h * 0.55f, intArrayOf(ca(k(T[3]), 0.55f), ca(k(T[3]), 0f)), null, Shader.TileMode.CLAMP)
            sunSh = LinearGradient(0f, h * 0.18f, 0f, h * 0.42f, k(T[3]), k(T[10]), Shader.TileMode.CLAMP)
            vigSh = RadialGradient(w / 2, h / 2, h * 1.15f, intArrayOf(0x00000000, 0x00000000, 0xAA000000.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            fogSh = LinearGradient(0f, gy - h * 0.2f, 0f, gy, ca(k(T[2]), 0f), ca(k(T[2]), 0.55f), Shader.TileMode.CLAMP)
            shaftSh = LinearGradient(0f, h * 0.25f, 0f, h * 0.9f, ca(k(T[3]), 0.16f), ca(k(T[3]), 0f), Shader.TileMode.CLAMP)
            for (i in 0..2) layerSh[i] = LinearGradient(0f, gy - h * (0.5f - i * 0.12f), 0f, gy, k(T[4 + i]), lerpCol(k(T[4 + i]), k(T[2]), 0.55f), Shader.TileMode.CLAMP)
            skyKey = key
        }
    }

    private fun renderWorld(c: Canvas, w: Float, h: Float, th: Int, cam: Float, sc: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = skySh; c.drawRect(0f, 0f, w, h, paint); paint.shader = null
        if (th != 1 && th != 3) for (i in 0 until 50) {
            val sx = ((i * 7919) % 1000) / 1000f * w; val sy = ((i * 104729) % 1000) / 1000f * h * 0.5f
            paint.color = ca(Color.WHITE, 0.3f + 0.5f * (0.5f + 0.5f * sin(time * 2f + i)))
            c.drawCircle(sx, sy, h * (0.002f + (i % 3) * 0.0015f), paint)
        }
        paint.shader = sunGlowSh; c.drawCircle(w * 0.74f, h * 0.3f, h * 0.55f, paint)
        paint.shader = sunSh; c.drawCircle(w * 0.74f, h * 0.3f, h * 0.12f, paint)
        paint.shader = shaftSh
        for (i in 0..2) {
            val sway = sin(time * 0.3f + i * 2f) * w * 0.03f
            val bx0 = w * 0.74f + (i - 1) * w * 0.05f
            path.reset(); path.moveTo(bx0, h * 0.3f); path.lineTo(bx0 + (i - 1) * w * 0.38f + sway - w * 0.08f, h); path.lineTo(bx0 + (i - 1) * w * 0.38f + sway + w * 0.08f, h); path.close()
            c.drawPath(path, paint)
        }
        paint.shader = null
        if (th == 2 || th == 4) for (b in 0..1) {
            path.reset(); path.moveTo(0f, h * 0.3f)
            var x = 0f
            while (x <= w + 30f) { path.lineTo(x, h * (0.16f + 0.05f * b) + sin(x / 170f + time * 0.5f + b * 2f) * h * 0.05f); x += 30f }
            x = w
            while (x >= -30f) { path.lineTo(x, h * (0.30f + 0.05f * b) + sin(x / 170f + time * 0.5f + b * 2f) * h * 0.05f); x -= 30f }
            path.close()
            paint.color = ca(k(if (b == 0) 0xFF2EC4B6 else 0xFF7C4DFF), 0.22f); c.drawPath(path, paint)
        }
        val gy = (10f - 2.4f) * sc
        for (i in 0..2) {
            val off = cam * sc * (0.12f + i * 0.14f)
            val amp = h * (0.30f - i * 0.07f)
            paint.shader = layerSh[i]
            path.reset(); path.moveTo(0f, gy + sc * 3f)
            var x = 0f
            while (x <= w + 24f) {
                val wx = (x + off) / sc
                val y = when (STY[th]) {
                    0 -> { val bwid = 1.8f + i * 0.7f; val bi = floor(wx / bwid).toInt(); gy - amp * (0.3f + 0.12f * ((bi * 37 + i * 11) % 7)) }
                    1 -> gy - amp * 0.45f - amp * 0.3f * sin(wx / (4f + i * 2f) + i * 1.7f) - amp * 0.15f * sin(wx / (1.7f + i) + i)
                    else -> gy - amp * 0.4f - amp * 0.45f * abs(sin(wx / (3.5f + i * 1.5f) + i * 2.1f))
                }
                path.lineTo(x, y); x += if (STY[th] == 0) 6f else 18f
            }
            path.lineTo(w, gy + sc * 3f); path.close()
            c.drawPath(path, paint)
        }
        paint.shader = null
        if (STY[th] == 0) {
            val i = 2; val bwid = 1.8f + i * 0.7f; val off = cam * sc * (0.12f + i * 0.14f); val amp = h * (0.30f - i * 0.07f)
            val b0 = floor(off / sc / bwid).toInt()
            for (bi in b0..b0 + (w / sc / bwid).toInt() + 2) {
                val bx = bi * bwid * sc - off
                val top = gy - amp * (0.3f + 0.12f * ((bi * 37 + i * 11) % 7))
                for (r in 0..4) for (cc in 0..3) if ((bi * 7 + r * 5 + cc * 3) % 4 == 0) {
                    paint.color = ca(k(if ((bi + r + cc) % 2 == 0) 0xFFFFE08A else 0xFF7DF9FF), 0.75f)
                    val wx = bx + sc * (0.35f + cc * 0.7f); val wy = top + sc * (0.45f + r * 0.6f)
                    if (wy < gy - sc * 0.2f) c.drawRect(wx, wy, wx + sc * 0.26f, wy + sc * 0.34f, paint)
                }
            }
        }
        paint.shader = fogSh; c.drawRect(0f, gy - h * 0.2f, w, gy + 1f, paint); paint.shader = null
    }

    private fun drawHero(c: Canvas, l: Float, t: Float, w: Float, h: Float, fc: Int, sk: Int, run: Boolean, air: Boolean) {
        fun fx(x: Float) = if (fc > 0) l + x * w else l + (1f - x) * w
        fun rr(x1: Float, y1: Float, x2: Float, y2: Float, rad: Float, col: Int) {
            val xa = fx(x1); val xb = fx(x2)
            paint.color = col
            c.drawRoundRect(min(xa, xb), t + y1 * h, max(xa, xb), t + y2 * h, rad * w, rad * w, paint)
        }
        paint.style = Paint.Style.FILL; paint.shader = null
        val body = skinCol(sk)
        val s = if (run) sin(time * 22f) * 0.1f else 0f
        val lift = if (air) 0.12f else 0f
        rr(0.2f + s, 0.78f - lift, 0.42f + s, 1f - lift, 0.1f, k(0xFF1B2433))
        rr(0.58f - s, 0.78f - lift, 0.8f - s, 1f - lift, 0.1f, k(0xFF1B2433))
        rr(0.18f + s, 0.92f - lift, 0.45f + s, 1f - lift, 0.1f, k(0xFFECEFF1))
        rr(0.55f - s, 0.92f - lift, 0.82f - s, 1f - lift, 0.1f, k(0xFFECEFF1))
        rr(0.47f, 0f, 0.53f, 0.17f, 0.02f, k(0xFF0B0F1A))
        rr(0.05f, 0.14f, 0.95f, 0.86f, 0.3f, k(0xFF0B0F1A))
        rr(0.08f, 0.17f, 0.92f, 0.83f, 0.28f, body)
        c.save(); c.clipRect(l - 2f, t + 0.55f * h, l + w + 2f, t + h + 2f)
        rr(0.08f, 0.17f, 0.92f, 0.83f, 0.28f, k(0x40000000))
        c.restore()
        rr(0.14f, 0.7f, 0.86f, 0.75f, 0.02f, ca(k(SK_A[sk]), 0.9f))
        rr(0.14f, 0.21f, 0.5f, 0.33f, 0.06f, k(0x55FFFFFF))
        rr(0.34f, 0.3f, 0.9f, 0.62f, 0.14f, k(0xFF10131F))
        val eh = if ((time % 3.3f) < 0.12f) 0.03f else 0.11f
        rr(0.5f, 0.46f - eh, 0.6f, 0.46f + eh, 0.04f, k(SK_V[sk]))
        rr(0.7f, 0.46f - eh, 0.8f, 0.46f + eh, 0.04f, k(SK_V[sk]))
        rr(0.38f, 0.33f, 0.88f, 0.37f, 0.02f, k(0x33FFFFFF))
        paint.color = k(SK_A[sk]); c.drawCircle(fx(0.5f), t + 0.02f * h, 0.08f * w, paint)
    }

    private fun drawEnemy(c: Canvas, e: Enemy, l: Float, tp: Float, sc: Float) {
        paint.style = Paint.Style.FILL; paint.shader = null
        if (e.kind != 2) { paint.color = k(0x33000000); c.drawOval(l, tp + sc * 0.74f, l + sc * 0.8f, tp + sc * 0.9f, paint) }
        when (e.kind) {
            2 -> {
                val fl = sin(time * 14f) * 0.3f * sc
                glowAt(c, l + sc * 0.4f, tp + sc * 0.4f, sc * 1.2f, k(0xFFB388FF), 0.35f)
                paint.color = k(0xFF4A2C82)
                path.reset(); path.moveTo(l + sc * 0.4f, tp + sc * 0.4f); path.lineTo(l - sc * 0.45f, tp + sc * 0.05f + fl); path.lineTo(l - sc * 0.1f, tp + sc * 0.7f); path.close(); c.drawPath(path, paint)
                path.reset(); path.moveTo(l + sc * 0.4f, tp + sc * 0.4f); path.lineTo(l + sc * 1.25f, tp + sc * 0.05f + fl); path.lineTo(l + sc * 0.9f, tp + sc * 0.7f); path.close(); c.drawPath(path, paint)
                blob(c, l + sc * 0.08f, tp + sc * 0.1f, l + sc * 0.72f, tp + sc * 0.72f, sc * 0.3f, k(0xFF8E5CD9))
                paint.color = k(0xFFFFEB3B); c.drawCircle(l + sc * 0.28f, tp + sc * 0.38f, sc * 0.07f, paint); c.drawCircle(l + sc * 0.52f, tp + sc * 0.38f, sc * 0.07f, paint)
                path.reset()
                path.moveTo(l + sc * 0.12f, tp + sc * 0.18f); path.lineTo(l + sc * 0.2f, tp - sc * 0.08f); path.lineTo(l + sc * 0.3f, tp + sc * 0.14f); path.close()
                path.moveTo(l + sc * 0.5f, tp + sc * 0.14f); path.lineTo(l + sc * 0.6f, tp - sc * 0.08f); path.lineTo(l + sc * 0.68f, tp + sc * 0.18f); path.close()
                paint.color = k(0xFF8E5CD9); c.drawPath(path, paint)
            }
            3 -> {
                if (e.cd < 0.45f) glowAt(c, l, tp + sc * 0.45f, sc * 0.9f, k(0xFFFF1744), 0.8f)
                paint.color = k(0xFF37474F); c.drawRoundRect(l - sc * 0.4f, tp + sc * 0.34f, l + sc * 0.3f, tp + sc * 0.56f, sc * 0.08f, sc * 0.08f, paint)
                blob(c, l, tp + sc * 0.15f, l + sc * 0.8f, tp + sc * 0.8f, sc * 0.18f, k(0xFF78909C))
                paint.color = k(0xFF1B2433); c.drawRect(l + sc * 0.1f, tp + sc * 0.72f, l + sc * 0.7f, tp + sc * 0.8f, paint)
                paint.color = k(0xFFFF1744); c.drawCircle(l + sc * 0.4f, tp + sc * 0.42f, sc * 0.12f, paint)
            }
            else -> {
                val base = k(if (e.spiky) 0xFFE53935 else 0xFFFF9100)
                val s2 = sin(time * 10f + e.x) * 0.08f * sc
                paint.color = k(0xFF0B0F1A)
                c.drawOval(l + sc * 0.05f + s2, tp + sc * 0.68f, l + sc * 0.38f + s2, tp + sc * 0.84f, paint)
                c.drawOval(l + sc * 0.42f - s2, tp + sc * 0.68f, l + sc * 0.75f - s2, tp + sc * 0.84f, paint)
                if (e.spiky) for (i in 0..3) {
                    path.reset()
                    path.moveTo(l + sc * (0.02f + i * 0.2f), tp + sc * 0.2f); path.lineTo(l + sc * (0.12f + i * 0.2f), tp - sc * 0.15f)
                    path.lineTo(l + sc * (0.22f + i * 0.2f), tp + sc * 0.2f); path.close()
                    paint.color = k(0xFFFFD54F); c.drawPath(path, paint)
                }
                blob(c, l, tp + sc * 0.1f, l + sc * 0.8f, tp + sc * 0.74f, sc * 0.3f, base)
                val dx = sign(e.vx) * sc * 0.04f
                paint.color = Color.WHITE; c.drawCircle(l + sc * 0.27f, tp + sc * 0.37f, sc * 0.13f, paint); c.drawCircle(l + sc * 0.53f, tp + sc * 0.37f, sc * 0.13f, paint)
                paint.color = Color.BLACK; c.drawCircle(l + sc * 0.27f + dx, tp + sc * 0.39f, sc * 0.06f, paint); c.drawCircle(l + sc * 0.53f + dx, tp + sc * 0.39f, sc * 0.06f, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.06f; paint.color = k(0xFF0B0F1A)
                c.drawLine(l + sc * 0.14f, tp + sc * 0.2f, l + sc * 0.34f, tp + sc * 0.28f, paint)
                c.drawLine(l + sc * 0.66f, tp + sc * 0.2f, l + sc * 0.46f, tp + sc * 0.28f, paint)
                paint.style = Paint.Style.FILL
            }
        }
    }

    private fun drawBtn(c: Canvas, b: Btn) {
        val r = b.r; val rad = r.height() * 0.42f
        paint.style = Paint.Style.FILL; paint.shader = null
        if (b.label == "II") {
            paint.color = k(0x66000000); c.drawCircle(r.centerX(), r.centerY() + 3f, r.width() / 2, paint)
            paint.color = k(0x55FFFFFF); c.drawCircle(r.centerX(), r.centerY(), r.width() / 2, paint)
            paint.color = Color.WHITE
            c.drawRoundRect(r.centerX() - r.width() * 0.2f, r.centerY() - r.height() * 0.22f, r.centerX() - r.width() * 0.06f, r.centerY() + r.height() * 0.22f, 4f, 4f, paint)
            c.drawRoundRect(r.centerX() + r.width() * 0.06f, r.centerY() - r.height() * 0.22f, r.centerX() + r.width() * 0.2f, r.centerY() + r.height() * 0.22f, 4f, 4f, paint)
            return
        }
        if (b.label == "<" || b.label == ">") {
            val cx = r.centerX(); val cy = r.centerY(); val rr2 = r.width() / 2
            paint.color = k(0x66000000); c.drawCircle(cx, cy + 3f, rr2, paint)
            paint.color = k(0x66FFFFFF); c.drawCircle(cx, cy, rr2, paint)
            val d = if (b.label == "<") -1f else 1f; val q = rr2 * 0.4f
            path.reset(); path.moveTo(cx + d * q, cy); path.lineTo(cx - d * q * 0.7f, cy - q); path.lineTo(cx - d * q * 0.7f, cy + q); path.close()
            paint.color = Color.WHITE; c.drawPath(path, paint)
            return
        }
        val ad = b.sub.contains("ANUNCIO")
        val prim = b.label in PRIMARY
        val c1 = if (ad) k(0xFFFFE082) else if (prim) k(0xFF4DF3FF) else k(0xEE2E1A5E)
        val c2 = if (ad) k(0xFFFF8F00) else if (prim) k(0xFF2962FF) else k(0xEE180B3A)
        paint.color = k(0x77000000); c.drawRoundRect(r.left, r.top + r.height() * 0.07f, r.right, r.bottom + r.height() * 0.07f, rad, rad, paint)
        paint.shader = LinearGradient(0f, r.top, 0f, r.bottom, c1, c2, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, paint); paint.shader = null
        paint.color = k(0x26FFFFFF); c.drawRoundRect(r.left + r.height() * 0.06f, r.top + r.height() * 0.05f, r.right - r.height() * 0.06f, r.top + r.height() * 0.5f, rad, rad, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = max(2f, r.height() * 0.03f)
        paint.color = if (ad || prim) k(0x88FFFFFF) else k(0x55A58CFF); c.drawRoundRect(r, rad, rad, paint)
        paint.style = Paint.Style.FILL
        if (scr == 4 && b.label.contains(": ")) {
            val parts = b.label.split(": ")
            txt(c, parts[0], r.left + r.height() * 0.5f, r.centerY() + r.height() * 0.14f, r.height() * 0.38f, 0xFFFFFFFF, Paint.Align.LEFT)
            val v = parts[1]
            if (v == "SÍ" || v == "NO") {
                val on = v == "SÍ"; val pw = r.height() * 1.1f; val ph = r.height() * 0.5f
                rf.set(r.right - r.height() * 0.5f - pw, r.centerY() - ph / 2, r.right - r.height() * 0.5f, r.centerY() + ph / 2)
                paint.color = if (on) k(0xFF00E676) else k(0xFF546E7A); c.drawRoundRect(rf, ph / 2, ph / 2, paint)
                paint.color = Color.WHITE; c.drawCircle(if (on) rf.right - ph / 2 else rf.left + ph / 2, rf.centerY(), ph * 0.38f, paint)
            } else txt(c, v, r.right - r.height() * 0.5f, r.centerY() + r.height() * 0.14f, r.height() * 0.38f, 0xFF7DF9FF, Paint.Align.RIGHT)
            return
        }
        val tc = if (ad) 0xFF3E2723 else 0xFFFFFFFF
        if (ad) {
            val px = r.left + r.height() * 0.55f; val q = r.height() * 0.2f
            path.reset(); path.moveTo(px - q * 0.5f, r.centerY() - q); path.lineTo(px + q, r.centerY()); path.lineTo(px - q * 0.5f, r.centerY() + q); path.close()
            paint.color = k(0xFF3E2723); c.drawPath(path, paint)
        }
        if (b.sub.isEmpty()) txt(c, b.label, r.centerX(), r.centerY() + r.height() * 0.14f, r.height() * 0.4f, tc)
        else {
            txt(c, b.label, r.centerX(), r.centerY() - r.height() * 0.04f, r.height() * 0.3f, tc)
            txt(c, b.sub, r.centerX(), r.centerY() + r.height() * 0.3f, r.height() * 0.2f, if (ad) 0xFF5D4037 else 0xFFFFE066)
        }
    }

    private fun padBtn(c: Canvas, r: RectF, label: String, on: Boolean) {
        val cx = r.centerX(); val cy = r.centerY()
        val rad = min(r.width(), r.height()) / 2 * (if (on) 0.94f else 1f)
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(0x44000000); c.drawCircle(cx, cy + rad * 0.06f, rad, paint)
        paint.color = if (on) k(0x66FFFFFF) else k(0x30FFFFFF); c.drawCircle(cx, cy, rad, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = max(2f, rad * 0.05f); paint.color = k(0x88FFFFFF); c.drawCircle(cx, cy, rad, paint)
        if (label == "DASH" && dashCd > 0f) {
            paint.strokeWidth = rad * 0.1f; paint.color = k(0xCC4DF3FF); rf.set(cx - rad, cy - rad, cx + rad, cy + rad)
            c.drawArc(rf, -90f, 360f * (1f - dashCd / (0.9f - 0.15f * upDash)).coerceIn(0f, 1f), false, paint)
        }
        paint.style = Paint.Style.FILL
        val q = rad * 0.38f
        when (label) {
            "<" -> { path.reset(); path.moveTo(cx - q, cy); path.lineTo(cx + q * 0.7f, cy - q); path.lineTo(cx + q * 0.7f, cy + q); path.close(); paint.color = Color.WHITE; c.drawPath(path, paint) }
            ">" -> { path.reset(); path.moveTo(cx + q, cy); path.lineTo(cx - q * 0.7f, cy - q); path.lineTo(cx - q * 0.7f, cy + q); path.close(); paint.color = Color.WHITE; c.drawPath(path, paint) }
            "SALTO" -> {
                path.reset(); path.moveTo(cx, cy - q * 1.1f); path.lineTo(cx + q, cy + q * 0.1f); path.lineTo(cx - q, cy + q * 0.1f); path.close(); paint.color = Color.WHITE; c.drawPath(path, paint)
                txt(c, "SALTO", cx, cy + rad * 0.68f, rad * 0.2f, 0xCCFFFFFF)
            }
            else -> { bolt(c, cx, cy - rad * 0.08f, q * 0.9f, Color.WHITE); txt(c, "DASH", cx, cy + rad * 0.72f, rad * 0.2f, 0xCCFFFFFF) }
        }
    }

    private fun drawLevelCard(c: Canvas, r: RectF, i: Int) {
        val T = TH[i / 6]; val open = i < unlocked; val hgt = r.height(); val rad = hgt * 0.22f
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(0x66000000); c.drawRoundRect(r.left, r.top + hgt * 0.06f, r.right, r.bottom + hgt * 0.06f, rad, rad, paint)
        paint.shader = LinearGradient(0f, r.top, 0f, r.bottom, if (open) k(T[10]) else k(0xFF37474F),
            if (open) lerpCol(k(T[10]), k(0xFF000000), 0.55f) else k(0xFF1C2630), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, paint); paint.shader = null
        paint.color = k(0x33FFFFFF); c.drawRoundRect(r.left, r.top, r.right, r.top + hgt * 0.45f, rad, rad, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = hgt * 0.03f; paint.color = k(0x66FFFFFF); c.drawRoundRect(r, rad, rad, paint)
        paint.style = Paint.Style.FILL
        if (open) {
            txt(c, "${i + 1}", r.centerX(), r.centerY() - hgt * 0.02f, hgt * 0.38f, 0xFFFFFFFF)
            for (s in 0..2) star(c, r.centerX() + (s - 1) * r.width() * 0.26f, r.bottom - hgt * 0.22f, hgt * 0.13f, if (s < stars[i]) k(0xFFFFD54F) else k(0x66000000))
            if (i % 6 == 5) txt(c, "JEFE", r.centerX(), r.top + hgt * 0.19f, hgt * 0.14f, 0xFFFFE57F)
        } else {
            val cx = r.centerX(); val cy = r.centerY(); val bw = hgt * 0.3f
            paint.color = k(0xFFB0BEC5); c.drawRoundRect(cx - bw / 2, cy, cx + bw / 2, cy + bw * 0.8f, bw * 0.12f, bw * 0.12f, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = bw * 0.14f
            rf.set(cx - bw * 0.3f, cy - bw * 0.6f, cx + bw * 0.3f, cy + bw * 0.2f); c.drawArc(rf, 180f, 180f, false, paint)
            paint.style = Paint.Style.FILL
        }
    }

    private fun drawShopCard(c: Canvas, r: RectF, j: Int) {
        val hgt = r.height()
        if (shopTab == 0) {
            val sj = skinPage * 6 + j
            val own = (owned and (1 shl sj)) != 0
            glass(c, r, k(SK_A[sj]), own && skin == sj)
            glowAt(c, r.centerX(), r.top + hgt * 0.34f, hgt * 0.5f, k(SK_A[sj]), 0.4f)
            val hs = hgt * 0.42f
            drawHero(c, r.centerX() - hs / 2, r.top + hgt * 0.1f, hs, hs, 1, sj, true, false)
            txt(c, SK_N[sj], r.centerX(), r.top + hgt * 0.68f, hgt * 0.11f * (if (SK_N[sj].length > 9) 0.8f else 1f), 0xFFFFFFFF)
            if (own) chip(c, r.centerX(), r.top + hgt * 0.86f, hgt * 0.14f, if (skin == sj) k(0xFF00C853) else k(0xFF2979FF), if (skin == sj) "EQUIPADO" else "EQUIPAR")
            else {
                coinIcon(c, r.centerX() - hgt * 0.16f, r.top + hgt * 0.86f, hgt * 0.07f)
                txt(c, "${SK_P[sj]}", r.centerX() - hgt * 0.06f, r.top + hgt * 0.9f, hgt * 0.12f, 0xFFFFE066, Paint.Align.LEFT)
            }
        } else {
            val lvl = upLevel(j)
            glass(c, r, k(0xFF7DF9FF), lvl > 0)
            val cx = r.centerX(); val cy = r.top + hgt * 0.2f
            glowAt(c, cx, cy, hgt * 0.3f, k(if (j == 0) 0xFFFF4D6D else if (j == 1) 0xFFFFEB3B else 0xFF4DF3FF), 0.5f)
            when (j) { 0 -> heart(c, cx, cy, hgt * 0.09f, k(0xFFFF4D6D)); 1 -> bolt(c, cx, cy, hgt * 0.07f, k(0xFFFFEB3B)); else -> gem(c, cx, cy, hgt * 0.1f, 1f) }
            txt(c, arrayOf("CORAZÓN EXTRA", "DASH RÁPIDO", "IMÁN DE GEMAS")[j], cx, r.top + hgt * 0.42f, hgt * 0.085f, 0xFFFFFFFF)
            txt(c, arrayOf("+1 vida máxima", "Recarga más corta", "Atrae las gemas")[j], cx, r.top + hgt * 0.53f, hgt * 0.062f, 0xFF9FA8DA)
            for (i in 0 until 3) {
                rf.set(r.left + r.width() * (0.2f + i * 0.22f), r.top + hgt * 0.62f, r.left + r.width() * (0.38f + i * 0.22f), r.top + hgt * 0.68f)
                paint.color = if (i < lvl) k(0xFF4DF3FF) else k(0x44FFFFFF); c.drawRoundRect(rf, 6f, 6f, paint)
            }
            if (lvl >= 3) chip(c, cx, r.top + hgt * 0.86f, hgt * 0.11f, k(0xFF00C853), "MÁXIMO")
            else {
                coinIcon(c, cx - hgt * 0.18f, r.top + hgt * 0.86f, hgt * 0.065f)
                txt(c, "${150 * (lvl + 1)}", cx - hgt * 0.09f, r.top + hgt * 0.9f, hgt * 0.1f, 0xFFFFE066, Paint.Align.LEFT)
            }
        }
    }

    private fun drawBoss(c: Canvas, bs: Boss, l: Float, tp: Float, sc: Float, cam: Float) {
        val bw = bs.w * sc; val bhh = bs.h * sc
        paint.style = Paint.Style.FILL; paint.shader = null
        if (bs.hidden) {
            if (bs.warn) {
                val mx = (bs.tx - cam + (if (bs.type == 5) bs.w / 2 else 0f)) * sc
                val my = if (bs.type == 5) 5f * sc else 10f * sc
                glowAt(c, mx, my, sc * 2f, k(0xFFFF1744), 0.5f)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.08f; paint.color = ca(k(0xFFFF1744), 0.6f + 0.4f * sin(time * 20f))
                c.drawCircle(mx, my, sc * (0.6f + 0.2f * sin(time * 12f)), paint); paint.style = Paint.Style.FILL
            }
            return
        }
        val base = k(when (bs.type) { 0 -> 0xFF8E24AA; 1 -> 0xFFE65100; 2 -> 0xFF78A5C8; 3 -> 0xFFC62828; 4 -> 0xFF2E7D32; else -> 0xFF5C6BC0 })
        val flashB = bs.inv > 0f && (time * 20f).toInt() % 2 == 0
        val warnB = bs.warn && (time * 16f).toInt() % 2 == 0
        val col = if (flashB) Color.WHITE else if (warnB) k(0xFFFF1744) else if (bossVuln(bs)) lerpCol(base, Color.WHITE, 0.35f) else base
        val fd = if (p.x + 0.4f < bs.x + bs.w / 2) -1f else 1f
        glowAt(c, l + bw / 2, tp + bhh / 2, bw * 1.5f, ca(base, 1f), 0.4f)
        paint.color = k(0x33000000); c.drawOval(l, 10f * sc - sc * 0.1f, l + bw, 10f * sc + sc * 0.14f, paint)
        when (bs.type) {
            0 -> {
                blob(c, l, tp, l + bw, tp + bhh, bw * 0.3f, col)
                paint.color = k(0xFFFFD740)
                for (i in 0..3) {
                    path.reset()
                    path.moveTo(l + (0.1f + i * 0.22f) * bw, tp + 0.02f * bhh); path.lineTo(l + (0.21f + i * 0.22f) * bw, tp - 0.2f * bhh)
                    path.lineTo(l + (0.32f + i * 0.22f) * bw, tp + 0.02f * bhh); path.close(); c.drawPath(path, paint)
                }
                paint.color = Color.WHITE
                c.drawCircle(l + 0.3f * bw, tp + 0.38f * bhh, 0.13f * bw, paint); c.drawCircle(l + 0.7f * bw, tp + 0.38f * bhh, 0.13f * bw, paint)
                paint.color = if (bossVuln(bs)) k(0xFF9E9E9E) else Color.BLACK
                c.drawCircle(l + 0.3f * bw + fd * 0.03f * bw, tp + 0.4f * bhh, 0.06f * bw, paint); c.drawCircle(l + 0.7f * bw + fd * 0.03f * bw, tp + 0.4f * bhh, 0.06f * bw, paint)
                paint.color = Color.BLACK; c.drawRoundRect(l + 0.25f * bw, tp + 0.68f * bhh, l + 0.75f * bw, tp + 0.78f * bhh, 6f, 6f, paint)
            }
            1 -> {
                val tx0 = l + (if (fd > 0f) 0.12f else 0.88f) * bw
                paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND; paint.strokeWidth = bw * 0.1f; paint.color = col
                path.reset(); path.moveTo(tx0, tp + bhh * 0.55f)
                path.cubicTo(tx0 - fd * bw * 0.25f, tp - bhh * 0.3f, tx0 + fd * bw * 0.05f, tp - bhh * 1.1f, tx0 + fd * bw * 0.35f, tp - bhh * 0.7f)
                c.drawPath(path, paint)
                paint.style = Paint.Style.FILL; paint.strokeCap = Paint.Cap.BUTT
                paint.color = k(0xFFFF1744); c.drawCircle(tx0 + fd * bw * 0.35f, tp - bhh * 0.7f, bw * 0.07f, paint)
                blob(c, l, tp + bhh * 0.28f, l + bw, tp + bhh, bw * 0.22f, col)
                val fx0 = if (fd > 0f) l + bw * 0.85f else l - bw * 0.1f
                paint.color = k(0xFFBF360C); c.drawRoundRect(fx0, tp + bhh * 0.5f, fx0 + bw * 0.25f, tp + bhh * 0.85f, bw * 0.08f, bw * 0.08f, paint)
                paint.color = Color.WHITE; c.drawCircle(l + bw * (0.5f + fd * 0.2f), tp + bhh * 0.55f, bw * 0.06f, paint); c.drawCircle(l + bw * (0.5f + fd * 0.35f), tp + bhh * 0.55f, bw * 0.06f, paint)
                paint.color = Color.BLACK; c.drawCircle(l + bw * (0.5f + fd * 0.22f), tp + bhh * 0.56f, bw * 0.03f, paint); c.drawCircle(l + bw * (0.5f + fd * 0.37f), tp + bhh * 0.56f, bw * 0.03f, paint)
            }
            2 -> {
                blob(c, l + bw * 0.1f, tp + bhh * 0.3f, l + bw * 0.9f, tp + bhh, bw * 0.18f, col)
                blob(c, l + bw * 0.22f, tp, l + bw * 0.78f, tp + bhh * 0.38f, bw * 0.14f, col)
                val bob = sin(time * 4f) * bhh * 0.03f
                blob(c, l - bw * 0.12f, tp + bhh * 0.4f + bob, l + bw * 0.14f, tp + bhh * 0.8f + bob, bw * 0.09f, col)
                blob(c, l + bw * 0.86f, tp + bhh * 0.4f - bob, l + bw * 1.12f, tp + bhh * 0.8f - bob, bw * 0.09f, col)
                paint.color = k(0xFF00E5FF)
                c.drawRoundRect(l + bw * 0.33f, tp + bhh * 0.14f, l + bw * 0.45f, tp + bhh * 0.22f, 4f, 4f, paint); c.drawRoundRect(l + bw * 0.55f, tp + bhh * 0.14f, l + bw * 0.67f, tp + bhh * 0.22f, 4f, 4f, paint)
                glowAt(c, l + bw / 2, tp + bhh * 0.18f, bw * 0.5f, k(0xFF00E5FF), 0.4f)
                if (bs.armor >= 1) { paint.color = ca(k(0xFFE3F2FD), 0.9f); c.drawRoundRect(l + bw * 0.14f, tp + bhh * 0.5f, l + bw * 0.86f, tp + bhh * 0.95f, bw * 0.08f, bw * 0.08f, paint) }
                if (bs.armor >= 2) { paint.color = ca(k(0xFFE3F2FD), 0.9f); c.drawRoundRect(l + bw * 0.2f, tp - bhh * 0.02f, l + bw * 0.8f, tp + bhh * 0.28f, bw * 0.08f, bw * 0.08f, paint) }
                if (bs.armor >= 1) {
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = bw * 0.012f; paint.color = k(0xFF90A4AE)
                    c.drawLine(l + bw * 0.3f, tp + bhh * 0.55f, l + bw * 0.5f, tp + bhh * 0.75f, paint); c.drawLine(l + bw * 0.5f, tp + bhh * 0.75f, l + bw * 0.45f, tp + bhh * 0.92f, paint)
                    paint.style = Paint.Style.FILL
                }
            }
            3 -> {
                val wing = sin(time * 10f) * bhh * (if (bs.fly) 0.45f else 0.1f)
                val bl = if (fd > 0f) l else l + bw * 0.2f
                paint.color = k(0xFF8E0000)
                path.reset(); path.moveTo(bl + bw * 0.4f, tp + bhh * 0.3f); path.lineTo(bl + bw * 0.15f, tp - bhh * 0.9f + wing); path.lineTo(bl + bw * 0.7f, tp + bhh * 0.2f); path.close(); c.drawPath(path, paint)
                paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND; paint.strokeWidth = bhh * 0.18f; paint.color = col
                c.drawLine(if (fd > 0f) bl + bw * 0.1f else bl + bw * 0.7f, tp + bhh * 0.65f, if (fd > 0f) bl - bw * 0.2f else bl + bw * 1.0f, tp + bhh * 0.45f, paint)
                paint.style = Paint.Style.FILL; paint.strokeCap = Paint.Cap.BUTT
                blob(c, bl, tp + bhh * 0.2f, bl + bw * 0.8f, tp + bhh, bw * 0.2f, col)
                val hx = if (fd > 0f) bl + bw * 0.7f else bl - bw * 0.1f
                blob(c, hx, tp, hx + bw * 0.4f, tp + bhh * 0.6f, bw * 0.12f, col)
                paint.color = k(0xFFFFD740); c.drawCircle(hx + bw * (if (fd > 0f) 0.28f else 0.12f), tp + bhh * 0.22f, bw * 0.04f, paint)
                if (bs.state == 0 && bs.t2 < 0.35f) glowAt(c, hx + bw * (if (fd > 0f) 0.45f else -0.05f), tp + bhh * 0.45f, bw * 0.45f, k(0xFFFF6D00), 0.8f)
            }
            4 -> {
                blob(c, l + bw * 0.1f, tp + bhh * 0.45f, l + bw * 0.9f, tp + bhh, bw * 0.2f, col)
                for (i in -1..1) {
                    val hx = l + bw / 2 + i * bw * 0.32f; val hy = tp + bhh * 0.05f + sin(time * 3f + i) * bhh * 0.05f
                    paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND; paint.strokeWidth = bw * 0.1f; paint.color = col
                    c.drawLine(l + bw / 2 + i * bw * 0.12f, tp + bhh * 0.55f, hx, hy + bhh * 0.15f, paint)
                    paint.style = Paint.Style.FILL; paint.strokeCap = Paint.Cap.BUTT
                    blob(c, hx - bw * 0.12f, hy, hx + bw * 0.12f, hy + bhh * 0.28f, bw * 0.07f, col)
                    paint.color = k(0xFFEEFF41); c.drawCircle(hx - bw * 0.04f, hy + bhh * 0.1f, bw * 0.025f, paint); c.drawCircle(hx + bw * 0.04f, hy + bhh * 0.1f, bw * 0.025f, paint)
                    if (bs.state == 0 && bs.t2 < 0.4f) glowAt(c, hx, hy + bhh * 0.2f, bw * 0.35f, k(0xFF76FF03), 0.7f)
                }
            }
            else -> {
                val hue = Color.HSVToColor(floatArrayOf((time * 60f) % 360f, 0.6f, 1f))
                val cxx = l + bw / 2; val cyy = tp + bhh / 2
                glowAt(c, cxx, cyy, bw * 2.2f, hue, 0.5f)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = bw * 0.06f
                for (i in 0..2) {
                    paint.color = ca(hue, 0.8f - i * 0.2f)
                    rf.set(cxx - bw * (0.75f + i * 0.2f), cyy - bw * (0.75f + i * 0.2f), cxx + bw * (0.75f + i * 0.2f), cyy + bw * (0.75f + i * 0.2f))
                    c.drawArc(rf, time * (80f + i * 50f) * (if (i % 2 == 0) 1f else -1f), 200f, false, paint)
                }
                paint.style = Paint.Style.FILL
                paint.color = if (flashB) Color.WHITE else if (warnB) k(0xFFFF1744) else k(0xFF1A1A40); c.drawCircle(cxx, cyy, bw * 0.45f, paint)
                paint.color = col; c.drawCircle(cxx, cyy, bw * 0.38f, paint)
                paint.color = Color.WHITE; c.drawCircle(cxx + fd * bw * 0.06f, cyy, bw * 0.2f, paint)
                paint.color = Color.BLACK; c.drawCircle(cxx + fd * bw * 0.1f, cyy, bw * 0.1f, paint)
            }
        }
        if (bossVuln(bs)) for (i in 0..2) {
            val a = time * 4f + i * 2.09f
            star(c, l + bw / 2 + cos(a) * bw * 0.3f, tp - sc * 0.3f + sin(a) * sc * 0.1f, sc * 0.14f, k(0xFFFFD54F))
        }
    }

    private fun render(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (scr == 5) renderPlay(c, w, h) else renderMenu(c, w, h)
        for ((i, b) in btns.withIndex()) {
            if (scr == 2 && i < 6) drawLevelCard(c, b.r, wPage * 6 + i)
            else if (scr == 3 && i < (if (shopTab == 0) 6 else 3)) drawShopCard(c, b.r, i)
            else drawBtn(c, b)
        }
        if (scr in 1..4 || scr == 6) {
            val s = "$coins"; val ph = h * 0.075f
            paint.textSize = ph * 0.55f; paint.textAlign = Paint.Align.CENTER
            val tw = paint.measureText(s)
            rf.set(w - h * 0.04f - tw - ph * 1.4f, h * 0.035f, w - h * 0.04f, h * 0.035f + ph)
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(0x99000000); c.drawRoundRect(rf, ph / 2, ph / 2, paint)
            coinIcon(c, rf.left + ph * 0.5f, rf.centerY(), ph * 0.3f)
            txt(c, s, rf.right - ph * 0.3f, rf.centerY() + ph * 0.2f, ph * 0.55f, 0xFFFFE066, Paint.Align.RIGHT)
        }
        if (msgT > 0f && scr != 0 && msg.isNotEmpty()) {
            paint.textSize = h * 0.042f; paint.textAlign = Paint.Align.CENTER
            val tw = paint.measureText(msg); val ph = h * 0.065f
            rf.set(w / 2 - tw / 2 - ph * 0.7f, h * 0.96f - ph / 2, w / 2 + tw / 2 + ph * 0.7f, h * 0.96f + ph / 2)
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = ca(k(0xFF111827), min(1f, msgT * 2f) * 0.9f); c.drawRoundRect(rf, ph / 2, ph / 2, paint)
            txt(c, msg, w / 2, h * 0.96f + ph * 0.18f, h * 0.042f, 0xFFFFFFFF)
        }
        if (rT > 0f) {
            paint.style = Paint.Style.STROKE; paint.shader = null; paint.strokeWidth = 4f; paint.color = ca(Color.WHITE, rT * 0.6f)
            c.drawCircle(rx, ry, (1f - rT) * h * 0.12f + 10f, paint); paint.style = Paint.Style.FILL
        }
        if (fade > 0f) { paint.style = Paint.Style.FILL; paint.shader = null; paint.color = ca(Color.BLACK, fade * 0.85f); c.drawRect(0f, 0f, w, h, paint) }
    }

    private fun renderMenu(c: Canvas, w: Float, h: Float) {
        prepare(w, h, 0)
        val sc = h / H; val cam = time * 4f; val gy = 7.6f * sc
        renderWorld(c, w, h, 0, cam, sc)
        val x0 = floor(cam).toInt()
        for (i in 0..(w / sc).toInt() + 1) {
            val l = (x0 + i - cam) * sc
            rf.set(l, gy, l + sc + 1f, gy + sc + 1f); tiles[1]?.let { c.drawBitmap(it, null, rf, null) }
            for (j in 1..4) { rf.set(l, gy + j * sc, l + sc + 1f, gy + (j + 1) * sc + 1f); tiles[0]?.let { c.drawBitmap(it, null, rf, null) } }
        }
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(if (scr == 0) 0x1A000000 else 0x77000000); c.drawRect(0f, 0f, w, h, paint)
        when (scr) {
            0 -> {
                title(c, "NEON DASH", w / 2, h * 0.36f, h * 0.2f)
                val hs = sc * 2f
                glowAt(c, w / 2, gy - hs / 2, hs * 1.3f, k(SK_A[skin]), 0.35f)
                drawHero(c, w / 2 - hs / 2, gy - hs, hs, hs, 1, skin, true, false)
                txt(c, "TOCA PARA EMPEZAR", w / 2, h * 0.9f, h * 0.06f * (1f + 0.04f * sin(time * 4f)), 0xFFFFFFFF)
            }
            1 -> {
                title(c, "NEON DASH", w / 2, h * 0.2f, h * 0.13f)
                val hs = sc * 1.8f
                glowAt(c, w * 0.13f + hs / 2, gy - hs / 2, hs * 1.3f, k(SK_A[skin]), 0.35f)
                drawHero(c, w * 0.13f, gy - hs, hs, hs, 1, skin, true, false)
            }
            2 -> {
                title(c, WN[wPage], w / 2, h * 0.15f, h * 0.09f)
                chip(c, w / 2, h * 0.22f, h * 0.05f, k(TH[wPage][10]), "MUNDO ${wPage + 1} DE 6")
            }
            3 -> title(c, if (shopTab == 0) "SKINS" else "MEJORAS", w / 2, h * 0.11f, h * 0.09f)
            4 -> title(c, "AJUSTES", w / 2, h * 0.12f, h * 0.09f)
            6 -> {
                title(c, "REGALO DIARIO", w / 2, h * 0.15f, h * 0.09f)
                val cw = h * 0.19f; val gp2 = h * 0.025f; val x0d = w / 2 - (7 * cw + 6 * gp2) / 2; val cur = nextDay()
                for (d in 0..6) {
                    val lx = x0d + d * (cw + gp2)
                    pr.set(lx, h * 0.28f, lx + cw, h * 0.58f)
                    val got = d < cur || (d == cur && giftState != 0); val now = d == cur && giftState == 0
                    glass(c, pr, k(0xFFFFD54F), now || d == 6)
                    if (now) glowAt(c, pr.centerX(), pr.centerY(), cw * 0.9f, k(0xFFFFD54F), 0.5f)
                    txt(c, if (now) "HOY" else "DÍA ${d + 1}", pr.centerX(), pr.top + h * 0.06f, h * 0.04f, if (now) 0xFFFFE066 else 0xFFFFFFFF)
                    if (d == 6) gem(c, pr.centerX(), pr.top + h * 0.14f, h * 0.045f, 1f) else coinIcon(c, pr.centerX(), pr.top + h * 0.14f, h * 0.045f)
                    txt(c, "${DAILY[d]}", pr.centerX(), pr.top + h * 0.25f, h * 0.05f, 0xFFFFE066)
                    if (got) {
                        paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(0xCC000000); c.drawRoundRect(pr, h * 0.04f, h * 0.04f, paint)
                        paint.style = Paint.Style.STROKE; paint.strokeWidth = h * 0.012f; paint.color = k(0xFF00E676)
                        val q = h * 0.04f; val cx = pr.centerX(); val cy = pr.centerY()
                        path.reset(); path.moveTo(cx - q, cy); path.lineTo(cx - q * 0.3f, cy + q * 0.7f); path.lineTo(cx + q, cy - q * 0.7f); c.drawPath(path, paint)
                        paint.style = Paint.Style.FILL
                    }
                }
                txt(c, "¡Entra cada día para ganar más! Racha: ${(if (giftState != 0) streak else if (cur == 0) 0 else cur) + (if (giftState != 0) 1 else 0)} día(s)", w / 2, h * 0.67f, h * 0.04f, 0xFFB0BEC5)
            }
        }
        paint.shader = vigSh; c.drawRect(0f, 0f, w, h, paint); paint.shader = null
    }

    private fun renderPlay(c: Canvas, w: Float, h: Float) {
        val th = lv / 6; val T = TH[th]; val sc = h / H; val vw = w / sc; val cam = camX
        prepare(w, h, th)
        renderWorld(c, w, h, th, cam, sc)
        paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(AMB[th])
        for (i in 0 until 30) {
            val fx = ((i * 7919) % 1000) / 1000f; val fy = ((i * 104729) % 1000) / 1000f
            val spd = (0.05f + (i % 4) * 0.03f) * (if (th == 1 || th == 3) -1f else 1f)
            val ay = ((((fy + time * spd) % 1f) + 1f) % 1f) * h
            val ax = (((fx * w - cam * sc * (0.2f + (i % 3) * 0.15f)) % w) + w) % w
            c.drawCircle(ax, ay, h * (0.004f + (i % 3) * 0.002f), paint)
        }
        c.save()
        val zs = 1f + max(0f, zoom); c.scale(zs, zs, w * 0.4f, h * 0.65f)
        c.translate(0f, -2.4f * sc)
        if (shake > 0f) { val am = h * 0.05f * min(1f, shake * 3f); c.translate((rnd.nextFloat() - 0.5f) * am, (rnd.nextFloat() - 0.5f) * am) }
        val x0 = floor(cam).toInt(); val x1 = min(W - 1, ceil(cam + vw).toInt())
        for (tx in x0..x1) if (map[10][tx] == '.' && map[11][tx] == '.') {
            val lx = (tx - cam) * sc
            paint.style = Paint.Style.FILL; paint.shader = null
            paint.color = k(HZ[th]); c.drawRect(lx, (11.4f + 0.1f * sin(time * 3f + tx)) * sc, lx + sc + 1f, 15f * sc, paint)
            glowAt(c, lx + sc / 2, 11.4f * sc, sc * 1.1f, ca(k(HZ[th]), 1f), 0.45f)
        }
        for (tx in x0..x1) if (map[10][tx] == '#' && map[9][tx] == '.' && map[8][tx] == '.' && (tx * 31 + 7) % 11 == 0) prop(c, th, (tx - cam) * sc + sc / 2, 10f * sc, sc, tx)
        for (ty in 0 until H) for (tx in x0..x1) {
            val t = map[ty][tx]
            if (t == '.') continue
            val l = (tx - cam) * sc; val tp = ty * sc
            paint.style = Paint.Style.FILL; paint.shader = null
            when (t) {
                'x' -> { paint.color = ca(k(T[9]), 0.22f); c.drawRect(l + sc * 0.1f, tp + sc * 0.94f, l + sc * 0.9f, tp + sc, paint) }
                'y' -> {
                    glowAt(c, l + sc / 2, tp + sc * 0.8f, sc * 0.9f, k(0xFFFF1744), 0.6f)
                    for (i in 0..1) { val bx = l + i * 0.5f * sc; path.reset(); path.moveTo(bx, tp + sc); path.lineTo(bx + 0.25f * sc, tp + sc * 0.72f); path.lineTo(bx + 0.5f * sc, tp + sc); path.close(); paint.color = k(0xFFCFD8DC); c.drawPath(path, paint) }
                }
                '#' -> { rf.set(l, tp, l + sc + 1f, tp + sc + 1f); tiles[if (ty == 0 || map[ty - 1][tx] != '#') 1 else 0]?.let { c.drawBitmap(it, null, rf, null) } }
                'P' -> { rf.set(l, tp, l + sc + 1f, tp + sc * 0.42f); tiles[2]?.let { c.drawBitmap(it, null, rf, null) } }
                '^' -> for (i in 0..1) {
                    val bx = l + i * 0.5f * sc
                    path.reset(); path.moveTo(bx, tp + sc); path.lineTo(bx + 0.25f * sc, tp + sc * 0.42f); path.lineTo(bx + 0.25f * sc, tp + sc); path.close()
                    paint.color = k(0xFFCFD8DC); c.drawPath(path, paint)
                    path.reset(); path.moveTo(bx + 0.25f * sc, tp + sc); path.lineTo(bx + 0.25f * sc, tp + sc * 0.42f); path.lineTo(bx + 0.5f * sc, tp + sc); path.close()
                    paint.color = k(0xFF78909C); c.drawPath(path, paint)
                }
                'o' -> {
                    val cy = tp + sc / 2 + sin(time * 3f + tx) * 0.05f * sc
                    glowAt(c, l + sc / 2, cy, sc * 0.8f, k(0xFF4DF3FF), 0.55f)
                    gem(c, l + sc / 2, cy, sc * 0.3f * (0.9f + 0.1f * sin(time * 5f + tx)), 0.45f + 0.55f * abs(cos(time * 3f + tx)))
                }
                'C' -> {
                    val act = cpX == tx.toFloat(); val fc = k(if (act) 0xFF69F0AE else 0xFFFF5252)
                    paint.color = k(0xFFB0BEC5); c.drawRect(l + sc * 0.46f, tp - sc * 0.2f, l + sc * 0.54f, tp + sc + 1f, paint)
                    val wv = sin(time * 6f) * sc * 0.06f
                    path.reset(); path.moveTo(l + sc * 0.54f, tp - sc * 0.15f); path.lineTo(l + sc * 1.15f, tp + sc * 0.1f + wv); path.lineTo(l + sc * 0.54f, tp + sc * 0.4f); path.close()
                    paint.color = fc; c.drawPath(path, paint)
                    glowAt(c, l + sc * 0.8f, tp + sc * 0.12f, sc * 0.8f, fc, 0.45f)
                }
                'G' -> if (ty == 6) {
                    val cx = l + sc / 2; val cy = tp + sc * 2f
                    val pc = if (boss != null) k(0xFF9E9E9E) else k(T[10])
                    glowAt(c, cx, cy, sc * 3f, pc, 0.5f)
                    paint.color = ca(pc, 0.18f); c.drawOval(cx - sc * 0.7f, cy - sc * 1.9f, cx + sc * 0.7f, cy + sc * 1.9f, paint)
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.1f
                    for (i in 0..2) {
                        paint.color = ca(pc, 0.9f - i * 0.25f)
                        rf.set(cx - sc * (0.8f - i * 0.18f), cy - sc * (2f - i * 0.4f), cx + sc * (0.8f - i * 0.18f), cy + sc * (2f - i * 0.4f))
                        c.drawArc(rf, time * (120f + i * 70f) * (if (i % 2 == 0) 1f else -1f), 250f, false, paint)
                    }
                    paint.style = Paint.Style.FILL
                }
                '=' -> {
                    paint.color = k(0xFF455A64); c.drawRoundRect(l + sc * 0.1f, tp + sc * 0.82f, l + sc * 0.9f, tp + sc, sc * 0.06f, sc * 0.06f, paint)
                    paint.color = k(0xFFB0BEC5); for (i in 0..2) c.drawRect(l + sc * (0.22f + i * 0.22f), tp + sc * 0.55f, l + sc * (0.3f + i * 0.22f), tp + sc * 0.82f, paint)
                    paint.color = k(0xFFFFC107); c.drawRoundRect(l + sc * 0.05f, tp + sc * 0.46f, l + sc * 0.95f, tp + sc * 0.58f, sc * 0.06f, sc * 0.06f, paint)
                }
                'S' -> {
                    val cy = tp + sc / 2 + sin(time * 4f + tx) * 0.05f * sc
                    glowAt(c, l + sc / 2, cy, sc * 0.9f, k(0xFF4DF3FF), 0.6f)
                    paint.color = k(0x554DF3FF); c.drawCircle(l + sc / 2, cy, sc * 0.32f, paint)
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.06f; paint.color = k(0xFF4DF3FF); c.drawCircle(l + sc / 2, cy, sc * 0.32f, paint)
                    paint.style = Paint.Style.FILL; paint.color = Color.WHITE; c.drawCircle(l + sc / 2, cy, sc * 0.1f, paint)
                }
                'H' -> {
                    val cy = tp + sc / 2 + sin(time * 4f + tx) * 0.06f * sc
                    glowAt(c, l + sc / 2, cy, sc * 0.9f, k(0xFFFF4D6D), 0.6f)
                    heart(c, l + sc / 2, cy, sc * 0.28f, k(0xFFFF4D6D))
                }
            }
        }
        paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(T[8])
        for (tx in x0..x1) if (map[11][tx] == '#') c.drawRect((tx - cam) * sc, 12f * sc, (tx - cam) * sc + sc + 1f, 15f * sc, paint)
        for (q in plats) {
            val px2 = (q.x - cam) * sc
            if (px2 > w + sc * 4 || px2 + q.w * sc < -sc * 4) continue
            val py2 = q.y * sc
            val a = if (q.kind == 3) (if (q.solid) (if (q.warn) 0.5f + 0.5f * sin(time * 30f) else 1f) else 0.18f) else 1f
            val n = max(1, floor(q.w + 0.5f).toInt())
            paint.style = Paint.Style.FILL; paint.shader = null
            if (q.solid) { paint.color = k(0x33000000); c.drawRoundRect(px2, py2 + sc * 0.36f, px2 + q.w * sc, py2 + sc * 0.52f, sc * 0.1f, sc * 0.1f, paint) }
            val shk = if (q.kind == 2 && q.stepped && q.t < 0.45f) sin(time * 60f) * sc * 0.03f else 0f
            gp.colorFilter = null; gp.alpha = (a * 255).toInt()
            for (i in 0 until n) { rf.set(px2 + i * q.w * sc / n + shk, py2, px2 + (i + 1) * q.w * sc / n + 1f + shk, py2 + sc * 0.42f); tiles[2]?.let { c.drawBitmap(it, null, rf, gp) } }
            val ac = k(when (q.kind) { 0 -> 0xFF4DF3FF; 1 -> 0xFF69F0AE; 2 -> 0xFFFFB74D; 3 -> 0xFFFF2BD6; else -> 0xFFB388FF })
            paint.color = ca(ac, 0.9f * a); c.drawRect(px2, py2 + sc * 0.36f, px2 + q.w * sc, py2 + sc * 0.42f, paint)
            if (q.solid) glowAt(c, px2 + q.w * sc / 2, py2 + sc * 0.45f, q.w * sc * 0.7f, ac, 0.25f * a)
            if (q.kind == 4 && q.warn) {
                val nx = if (floor(time / q.per + q.ph).toInt() % 2 == 0) q.x0 + q.amp else q.x0
                paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.06f; paint.color = ca(ac, 0.5f + 0.5f * sin(time * 20f))
                c.drawRoundRect((nx - cam) * sc, py2, (nx - cam) * sc + q.w * sc, py2 + sc * 0.42f, sc * 0.1f, sc * 0.1f, paint)
                paint.style = Paint.Style.FILL
            }
        }
        for (lz in lasers) {
            val lx = (lz[0] + 0.5f - cam) * sc
            if (lx < -sc || lx > w + sc) continue
            val ph = (time / lz[1] + lz[2]) % 1f
            paint.style = Paint.Style.FILL; paint.shader = null
            paint.color = k(0xFF37474F); c.drawRoundRect(lx - sc * 0.25f, 2f * sc - sc * 0.2f, lx + sc * 0.25f, 2f * sc + sc * 0.3f, sc * 0.08f, sc * 0.08f, paint)
            c.drawRoundRect(lx - sc * 0.25f, 10f * sc - sc * 0.3f, lx + sc * 0.25f, 10f * sc, sc * 0.08f, sc * 0.08f, paint)
            if (ph > 0.6f) {
                paint.color = ca(k(0xFFFF1744), 0.9f); c.drawRect(lx - sc * 0.12f, 2f * sc + sc * 0.3f, lx + sc * 0.12f, 10f * sc - sc * 0.3f, paint)
                paint.color = ca(Color.WHITE, 0.8f); c.drawRect(lx - sc * 0.04f, 2f * sc + sc * 0.3f, lx + sc * 0.04f, 10f * sc - sc * 0.3f, paint)
                glowAt(c, lx, 6f * sc, sc * 3f, k(0xFFFF1744), 0.35f)
            } else if (ph > 0.4f) {
                paint.color = ca(k(0xFFFF1744), 0.25f + 0.25f * sin(time * 25f)); c.drawRect(lx - sc * 0.02f, 2f * sc + sc * 0.3f, lx + sc * 0.02f, 10f * sc - sc * 0.3f, paint)
            }
        }
        for (g in ghosts) {
            glowAt(c, (g[0] - cam + p.w / 2) * sc, (g[1] + p.h / 2) * sc, sc * 1.1f, k(acc()), g[2] * 2f)
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = ca(k(acc()), g[2] * 2f)
            c.drawRoundRect((g[0] - cam) * sc, g[1] * sc, (g[0] - cam) * sc + p.w * sc, g[1] * sc + p.h * sc, sc * 0.25f, sc * 0.25f, paint)
        }
        for (e in enemies) {
            val l = (e.x - cam) * sc
            if (e.dead || l < -sc * 2 || l > w + sc) continue
            drawEnemy(c, e, l, e.y * sc, sc)
        }
        for (bl in bullets) {
            val bx = (bl.x - cam) * sc; val by = bl.y * sc
            paint.style = Paint.Style.FILL; paint.shader = null
            when (bl.kind) {
                3 -> {
                    if (bl.tm > 0f) {
                        paint.color = ca(k(0xFFFF1744), 0.5f + 0.5f * sin(time * 20f))
                        path.reset(); path.moveTo(bx + bl.w * sc / 2, 2.6f * sc); path.lineTo(bx - sc * 0.15f, 2f * sc); path.lineTo(bx + bl.w * sc + sc * 0.15f, 2f * sc); path.close(); c.drawPath(path, paint)
                        paint.color = ca(k(0xFFFF1744), 0.12f); c.drawRect(bx, 2.6f * sc, bx + bl.w * sc, 10f * sc, paint)
                    } else {
                        glowAt(c, bx + bl.w * sc / 2, by + bl.h * sc / 2, sc * 1.1f, k(0xFF9BE7FF), 0.6f)
                        path.reset(); path.moveTo(bx + bl.w * sc / 2, by + bl.h * sc); path.lineTo(bx, by); path.lineTo(bx + bl.w * sc, by); path.close()
                        paint.color = k(0xFFE3F2FD); c.drawPath(path, paint)
                    }
                }
                5 -> {
                    val lx = bx + bl.w * sc / 2
                    if (bl.tm > 0f) { paint.color = ca(k(0xFFFF1744), 0.2f + 0.3f * sin(time * 25f)); c.drawRect(lx - sc * 0.03f, 2f * sc, lx + sc * 0.03f, 10f * sc, paint) }
                    else {
                        paint.color = ca(k(0xFFFF2BD6), 0.9f); c.drawRect(lx - sc * 0.22f, 2f * sc, lx + sc * 0.22f, 10f * sc, paint)
                        paint.color = ca(Color.WHITE, 0.9f); c.drawRect(lx - sc * 0.08f, 2f * sc, lx + sc * 0.08f, 10f * sc, paint)
                        glowAt(c, lx, 6f * sc, sc * 3.5f, k(0xFFFF2BD6), 0.4f)
                    }
                }
                2 -> {
                    val sandy = lv / 6 == 1
                    glowAt(c, bx + bl.w * sc / 2, by + bl.h * sc / 2, sc * 1.2f, k(if (sandy) 0xFFFFB74D else 0xFF9BE7FF), 0.5f)
                    paint.color = ca(k(if (sandy) 0xFFFFCC80 else 0xFFE3F2FD), 0.9f)
                    path.reset(); path.moveTo(bx, by + bl.h * sc); path.quadTo(bx + bl.w * sc * 0.5f, by - sc * 0.2f, bx + bl.w * sc, by + bl.h * sc); path.close(); c.drawPath(path, paint)
                }
                1 -> {
                    glowAt(c, bx + sc * 0.3f, by + sc * 0.3f, sc * 1.2f, k(0xFFFF6D00), 0.8f)
                    paint.color = k(0xFFFFEB3B); c.drawCircle(bx + sc * 0.3f, by + sc * 0.3f, sc * 0.26f, paint)
                    paint.color = k(0xFFFF5722); c.drawCircle(bx + sc * 0.3f, by + sc * 0.3f, sc * 0.16f, paint)
                }
                4 -> {
                    glowAt(c, bx + sc * 0.25f, by + sc * 0.25f, sc * 1f, k(0xFF76FF03), 0.7f)
                    paint.color = k(0xFF1B5E20); c.drawCircle(bx + sc * 0.25f, by + sc * 0.25f, sc * 0.24f, paint)
                    paint.color = k(0xFFB2FF59); c.drawCircle(bx + sc * 0.25f, by + sc * 0.25f, sc * 0.13f, paint)
                }
                else -> {
                    glowAt(c, bx + sc * 0.22f, by + sc * 0.15f, sc * 0.75f, k(0xFFFF9100), 0.75f)
                    paint.color = k(0xFFFFF176); c.drawOval(bx, by, bx + 0.45f * sc, by + 0.3f * sc, paint)
                }
            }
        }
        boss?.let { bs -> drawBoss(c, bs, (bs.x - cam) * sc, bs.y * sc, sc, cam) }
        paint.style = Paint.Style.FILL; paint.shader = null
        for (q in parts) {
            val a = min(1f, q.life * 2.5f)
            glowAt(c, (q.x - cam) * sc, q.y * sc, sc * 0.28f * (0.5f + q.life), ca(q.col, 1f), a * 0.8f)
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = ca(Color.WHITE, a)
            c.drawCircle((q.x - cam) * sc, q.y * sc, sc * 0.035f, paint)
        }
        for (rg in rings) {
            val tt = 1f - rg.life / 0.4f
            paint.style = Paint.Style.STROKE; paint.shader = null; paint.strokeWidth = sc * 0.07f * (1f - tt)
            paint.color = ca(rg.col, rg.life / 0.4f)
            c.drawCircle((rg.x - cam) * sc, rg.y * sc, sc * (0.2f + tt * 1.1f), paint)
        }
        paint.style = Paint.Style.FILL; paint.shader = null; paint.textAlign = Paint.Align.CENTER; paint.textSize = sc * 0.45f
        for (tp in pops) { paint.color = ca(tp.col, min(1f, tp.life * 2f)); c.drawText(tp.s, (tp.x - cam) * sc, tp.y * sc, paint) }
        run {
            val gx2 = floor(p.x + p.w / 2).toInt().coerceIn(0, W - 1)
            var gyy = 12f
            for (ty in max(0, floor(p.y + p.h - 0.05f).toInt())..11) { val ch = map[ty][gx2]; if (ch == '#' || ch == 'P') { gyy = ty.toFloat(); break } }
            for (q in plats) if (q.solid && p.x + p.w > q.x && p.x < q.x + q.w && q.y >= p.y + p.h - 0.2f && q.y < gyy) gyy = q.y
            val dist = max(0f, gyy - (p.y + p.h))
            if (gyy < 12f) { paint.style = Paint.Style.FILL; paint.shader = null; paint.color = ca(Color.BLACK, 0.35f * max(0f, 1f - dist / 6f)); c.drawOval((p.x - cam - 0.1f) * sc, gyy * sc - sc * 0.05f, (p.x - cam + p.w + 0.1f) * sc, gyy * sc + sc * 0.12f, paint) }
        }
        if (inv <= 0f || (time * 20f).toInt() % 2 == 0) {
            val st = min(abs(p.vy) / 40f, 0.25f)
            val sq = max(0f, squashT) / 0.14f
            val pw = p.w * sc * 1.2f * (1f - st * 0.5f + sq * 0.25f)
            val ph = p.h * sc * (1f + st - sq * 0.2f)
            glowAt(c, (p.x - cam + p.w / 2) * sc, (p.y + p.h / 2) * sc, sc * 1.6f, k(SK_A[skin]), 0.28f)
            drawHero(c, (p.x - cam) * sc + (p.w * sc - pw) / 2, p.y * sc + p.h * sc - ph, pw, ph, face, skin, p.ground && abs(p.vx) > 0.5f, !p.ground)
        }
        if (dashT > 0f) {
            paint.style = Paint.Style.STROKE; paint.shader = null; paint.strokeWidth = sc * 0.05f; paint.color = ca(k(acc()), 0.6f)
            for (i in 0..5) { val yy = (p.y + 0.1f + i * 0.16f) * sc; val xx = (p.x - cam + (if (face > 0) -0.2f else p.w + 0.2f)) * sc; c.drawLine(xx, yy, xx - face * sc * (1.2f + (i % 3) * 0.5f), yy, paint) }
            paint.style = Paint.Style.FILL
        }
        if (shield) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.08f; paint.color = k(0xCC4DF3FF)
            c.drawCircle((p.x - cam + p.w / 2) * sc, (p.y + p.h / 2) * sc, p.h * sc * 0.85f, paint)
            paint.style = Paint.Style.FILL
        }
        c.restore()
        paint.style = Paint.Style.FILL
        paint.shader = vigSh; c.drawRect(0f, 0f, w, h, paint); paint.shader = null

        for (i in 0 until 5) glowAt(c, (((i * 0.37f * w - cam * sc * (1.2f + i * 0.2f)) % (w * 1.4f)) + w * 1.4f) % (w * 1.4f) - w * 0.2f, h * (0.15f + (i % 3) * 0.28f), h * 0.22f, k(T[10]), 0.07f)
        if (flash > 0f) { paint.style = Paint.Style.FILL; paint.shader = null; paint.color = ca(k(0xFFFF1744), flash * 0.55f); c.drawRect(0f, 0f, w, h, paint) }
        // HUD
        val hp0 = maxHp(); val pillH = h * 0.085f
        rf.set(h * 0.03f, h * 0.03f, h * 0.03f + pillH * 0.6f + hp0 * h * 0.062f + h * 0.34f, h * 0.03f + pillH)
        paint.color = k(0x88000000); c.drawRoundRect(rf, pillH / 2, pillH / 2, paint)
        for (i in 0 until hp0) heart(c, h * 0.03f + pillH * 0.6f + i * h * 0.062f, rf.centerY(), h * 0.022f, if (i < hp) k(0xFFFF4D6D) else k(0x55FFFFFF))
        val gx = h * 0.03f + pillH * 0.5f + hp0 * h * 0.062f + h * 0.04f
        gem(c, gx, rf.centerY(), h * 0.028f, 1f)
        txt(c, "$gems/$gemTotal", gx + h * 0.045f, rf.centerY() + h * 0.02f, h * 0.05f, 0xFFFFFFFF, Paint.Align.LEFT)
        boss?.let { bs ->
            if (p.x > W - 40f) {
                val bw2 = h * 1.2f; val bx = w / 2 - bw2 / 2
                rf.set(bx, h * 0.12f, bx + bw2, h * 0.16f); paint.color = k(0x99000000); c.drawRoundRect(rf, h * 0.02f, h * 0.02f, paint)
                rf.set(bx, h * 0.12f, bx + bw2 * bs.hp / bossMax, h * 0.16f)
                paint.shader = LinearGradient(0f, h * 0.12f, 0f, h * 0.16f, k(0xFFFF8A80), k(0xFFD50000), Shader.TileMode.CLAMP)
                c.drawRoundRect(rf, h * 0.02f, h * 0.02f, paint); paint.shader = null
                txt(c, BOSS_N[bs.type], w / 2, h * 0.105f, h * 0.04f, 0xFFFFFFFF)
            }
        }
        if (intro > 0f) {
            txt(c, "NIVEL ${lv + 1} - ${WN[th]}", w / 2, h * 0.3f, h * 0.08f, 0xFFFFFFFF)
            if (lv % 6 == 5) { txt(c, "¡JEFE: ${BOSS_N[lv / 6]}!", w / 2, h * 0.38f, h * 0.055f, 0xFFFF8A80); txt(c, BOSS_HINT[lv / 6], w / 2, h * 0.45f, h * 0.035f, 0xFFB0BEC5) }
        }
        if (res == 0 && !paused) { padBtn(c, bL, "<", goL); padBtn(c, bR, ">", goR); padBtn(c, bJ, "SALTO", goJ); padBtn(c, bD, "DASH", goD) }
        if (paused || res != 0) {
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(0xAA060312); c.drawRect(0f, 0f, w, h, paint)
            pr.set(w / 2 - h * 0.72f, h * 0.05f, w / 2 + h * 0.72f, h * 0.97f)
            glass(c, pr, k(0xFF7DF9FF), false)
        }
        if (paused) title(c, "PAUSA", w / 2, h * 0.27f, h * 0.13f)
        if (res == 1) {
            title(c, "¡COMPLETADO!", w / 2, h * 0.17f, h * 0.1f)
            for (i in 0..2) star(c, w / 2 + (i - 1) * h * 0.2f, h * 0.27f, h * (if (i == 1) 0.075f else 0.06f) * (1f + 0.05f * sin(time * 4f + i)), if (i < lastStars) k(0xFFFFD54F) else k(0x55FFFFFF))
            txt(c, "Gemas $gems/$gemTotal   Monedas: $lvCoins", w / 2, h * 0.38f, h * 0.045f, 0xFFFFFFFF)
        }
        if (res == 2) title(c, "¡HAS CAÍDO!", w / 2, h * 0.3f, h * 0.11f)
    }
}
