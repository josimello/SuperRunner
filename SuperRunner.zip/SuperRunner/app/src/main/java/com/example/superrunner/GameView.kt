package com.example.superrunner

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.util.Random
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.*

private open class Body(var x: Float, var y: Float, val w: Float, val h: Float) {
    var vx = 0f; var vy = 0f
    var ground = false; var wall = false
}
/** kind: 0 caminante, 1 pinchudo, 2 murciélago volador, 3 torreta */
private class Enemy(x: Float, y: Float, val kind: Int) : Body(x, y, 0.8f, 0.8f) {
    var dead = false; var t = 0f; var cd = 1.5f; val y0 = y
    val spiky: Boolean get() = kind == 1
    init { vx = when (kind) { 1 -> -2.2f; 2 -> -1.8f; 3 -> 0f; else -> -1.5f } }
}
private class Boss(x: Float, y: Float, var hp: Int) : Body(x, y, 1.8f, 1.8f) { var state = 0; var tm = 2f; var inv = 0f; var dir = -1 }
private class Bullet(var x: Float, var y: Float, val vx: Float) { var life = 4f }
private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val col: Int)
private class Btn(val r: RectF, val label: String, val sub: String, val act: () -> Unit)

/** NEON DASH. Pantallas: 0 título, 1 menú, 2 niveles, 3 tienda, 4 ajustes, 5 juego. */
class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {
    private val H = 12
    private var W = 100
    private var map = Array(H) { CharArray(W) { '.' } }
    private val enemies = ArrayList<Enemy>()
    private val parts = ArrayList<Part>()
    private val btns = ArrayList<Btn>()
    private val taps = ConcurrentLinkedQueue<PointF>()
    private val p = Body(2f, 8f, 0.8f, 0.95f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rnd = Random()
    private var bL = RectF(); private var bR = RectF(); private var bJ = RectF(); private var bD = RectF()
    @Volatile private var goL = false
    @Volatile private var goR = false
    @Volatile private var goJ = false
    @Volatile private var goD = false
    @Volatile private var running = false
    private var thread: Thread? = null

    private var scr = 0; private var paused = false; private var res = 0
    private var lv = 0; private var hp = 3; private var gems = 0; private var gemTotal = 0; private var lastStars = 0
    private var cpX = 2f; private var cpY = 8f
    private var jumps = 0; private var jPrev = false; private var dPrev = false; private var spr = false
    private var dashT = 0f; private var dashCd = 0f; private var inv = 0f; private var shake = 0f; private var intro = 0f
    private var face = 1; private var time = 0f
    private var confirm = false; private var msg = ""; private var msgT = 0f

    private val sp = ctx.getSharedPreferences("neondash", Context.MODE_PRIVATE)
    private var coins = sp.getInt("coins", 0)
    private var unlocked = sp.getInt("unl", 1)
    private var owned = sp.getInt("own", 1)
    private var skin = sp.getInt("skin", 0)
    private var snd = sp.getBoolean("snd", true)
    private var hap = sp.getBoolean("hap", true)
    private var ctl = sp.getInt("ctl", 1)
    private var dif = sp.getInt("dif", 1)
    private val stars = IntArray(12) { sp.getInt("s$it", 0) }
    private var upHp = sp.getInt("uhp", 0)
    private var upDash = sp.getInt("uda", 0)
    private var upMag = sp.getInt("umg", 0)
    private var lastDay = sp.getLong("day", 0L)
    private var streak = sp.getInt("streak", 0)
    private var lastGift = sp.getInt("glast", 25)
    private var giftState = if (sp.getLong("day", 0L) == System.currentTimeMillis() / 86400000L) sp.getInt("gst", 1) else 0
    private var shopTab = 0
    private var shield = false
    private var wasGround = false
    private var bossMax = 1
    private var boss: Boss? = null
    private val bullets = ArrayList<Bullet>()
    private val HZ = longArrayOf(0xAAFF2BD6, 0xFFFF5722, 0xAA4FC3F7)
    private val AMB = longArrayOf(0x66FF2BD6, 0x99FFD27A, 0xCCFFFFFF)

    private val SK_N = arrayOf("CIAN", "FUEGO", "BOSQUE", "ORO", "FANTASMA", "ARCOÍRIS")
    private val SK_P = intArrayOf(0, 60, 120, 220, 350, 500)
    private val SK_C = longArrayOf(0xFF00BCD4, 0xFFFF5722, 0xFF43A047, 0xFFFFC107, 0xB3E0E0FF, 0xFFFFFFFF)
    private val SK_V = longArrayOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFFCCFF90, 0xFF212121, 0xFF7C4DFF, 0xFF111111)
    private val WN = arrayOf("NEÓN", "DESIERTO", "HIELO")
    private val TH = arrayOf(
        longArrayOf(0xFF12082E, 0xFF2A1458, 0xFF241447, 0xFF00E5FF, 0xFFFF2BD6),
        longArrayOf(0xFFFF9A5A, 0xFFC9603A, 0xFF8C4A2A, 0xFFFFD27A, 0xFF3A1D0F),
        longArrayOf(0xFF0B2A4A, 0xFF1D5C8A, 0xFF2B6C9A, 0xFFBFF3FF, 0xFF9BE7FF)
    )
    private var tg: ToneGenerator? = null

    // ---------- Anuncios recompensados (AdMob). ID de PRUEBA: cámbialo por el tuyo para cobrar ----------
    private val AD_UNIT = "ca-app-pub-3940256099942544/5224354917"
    @Volatile private var rewarded: RewardedAd? = null
    @Volatile private var adLoading = false
    @Volatile private var adReward = false
    @Volatile private var adDone = false
    private var adMode = 0; private var adT = 0f
    private var lvCoins = 0; private var doubled = false
    private var safeX = 2f; private var safeY = 8f

    init {
        holder.addCallback(this)
        paint.typeface = Typeface.DEFAULT_BOLD
        MobileAds.initialize(ctx) { }
    }

    private fun k(v: Long) = v.toInt()
    private fun maxHp() = (when (dif) { 0 -> 5; 1 -> 3; else -> 1 }) + upHp
    private fun upLevel(j: Int) = when (j) { 0 -> upHp; 1 -> upDash; else -> upMag }
    private fun stars3(n: Int) = "★".repeat(n) + "☆".repeat(3 - n)
    private fun skinCol(i: Int): Int =
        if (i == 5) Color.HSVToColor(floatArrayOf((time * 120f) % 360f, 0.8f, 1f)) else k(SK_C[i])

    private fun save() {
        val e = sp.edit()
        e.putInt("coins", coins).putInt("unl", unlocked).putInt("own", owned).putInt("skin", skin)
        e.putBoolean("snd", snd).putBoolean("hap", hap).putInt("ctl", ctl).putInt("dif", dif)
        e.putInt("uhp", upHp).putInt("uda", upDash).putInt("umg", upMag).putLong("day", lastDay).putInt("streak", streak).putInt("gst", giftState).putInt("glast", lastGift)
        for (i in 0 until 12) e.putInt("s$i", stars[i])
        e.apply()
    }

    private fun beep(t: Int) {
        if (!snd) return
        try {
            if (tg == null) tg = ToneGenerator(AudioManager.STREAM_MUSIC, 50)
            tg?.startTone(t, 60)
        } catch (e: Exception) { }
    }

    private fun earn(n: Int) { coins += n; lvCoins += n }

    private fun loadAd() {
        if (rewarded != null || adLoading) return
        adLoading = true
        post {
            RewardedAd.load(context, AD_UNIT, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewarded = ad; adLoading = false }
                override fun onAdFailedToLoad(error: LoadAdError) { rewarded = null; adLoading = false }
            })
        }
    }

    /** mode 1 = revivir en el sitio, mode 2 = duplicar monedas del nivel */
    private fun showAd(mode: Int) {
        val ad = rewarded
        if (ad == null) { msg = "Anuncio no disponible aún, prueba en unos segundos"; msgT = 2.5f; adT = 0f; return }
        adMode = mode; adReward = false; adDone = false
        rewarded = null
        post {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() { adDone = true }
                override fun onAdFailedToShowFullScreenContent(error: AdError) { adReward = false; adDone = true }
            }
            ad.show(context as Activity) { adReward = true }
        }
    }

    private fun grant(mode: Int) {
        if (mode == 1 && res == 2) {
            res = 0; hp = maxHp(); p.x = safeX; p.y = safeY - 0.05f; p.vx = 0f; p.vy = 0f; inv = 3f
            beep(ToneGenerator.TONE_PROP_ACK)
        } else if (mode == 3 && giftState == 1) {
            coins += lastGift; giftState = 2; msg = "¡+$lastGift monedas extra!"; msgT = 2.5f
            beep(ToneGenerator.TONE_PROP_ACK); save()
        } else if (mode == 2 && res == 1 && !doubled) {
            doubled = true; coins += lvCoins; msg = "¡+$lvCoins monedas!"; msgT = 2f
            beep(ToneGenerator.TONE_PROP_ACK); save()
        }
    }

    private fun buzz() { if (hap) post { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) } }

    private fun burst(x: Float, y: Float, col: Long, n: Int) {
        repeat(n) { parts.add(Part(x, y, (rnd.nextFloat() - 0.5f) * 6f, (rnd.nextFloat() - 0.8f) * 5f, 0.5f, k(col))) }
    }

    // ---------- Niveles (generados por semilla, cada uno distinto y más difícil) ----------
    private fun put(c: Char, x1: Int, x2: Int, y1: Int, y2: Int) {
        for (y in y1..y2) for (x in x1..x2) if (x in 0 until W && y in 0 until H) map[y][x] = c
    }

    private fun load(l: Int) {
        lv = l
        val r = Random(l * 7919L + 13L)
        val isBoss = l % 4 == 3
        W = if (isBoss) 90 else 110 + l * 12
        map = Array(H) { CharArray(W) { '.' } }
        enemies.clear(); parts.clear(); bullets.clear(); boss = null
        put('#', 0, W - 1, 10, 11)
        var x = 8
        val lim = if (isBoss) W - 36 else W - 16
        val step = lim / 3
        var nextCp = step
        while (x < lim) {
            if (x >= nextCp) { map[9][x] = 'C'; nextCp += step; x += 4; continue }
            when (r.nextInt(10)) {
                0 -> { val g = 2 + r.nextInt(1 + min(2, l / 3)); put('.', x, x + g - 1, 10, 11); put('o', x - 1, x + g, 7, 7); x += g + 4 }
                1 -> { put('P', x + 2, x + 4, 7, 7); put('o', x + 2, x + 4, 6, 6); x += 8 }
                2 -> { val n = 1 + r.nextInt(2); put('^', x, x + n - 1, 9, 9); put('o', x, x + n - 1, 7, 7); x += n + 4 }
                3 -> { enemies.add(Enemy(x.toFloat(), 9.2f, if (l >= 2 && r.nextInt(3) == 0) 1 else 0)); x += 6 }
                4 -> { val hh = 2 + r.nextInt(2); put('#', x, x + 1, 10 - hh, 9); x += 5 }
                5 -> { map[9][x] = '='; put('P', x + 3, x + 6, 4, 4); put('o', x + 3, x + 6, 3, 3); x += 9 }
                6 -> { put('o', x, x + 3, 8, 8); x += 5 }
                7 -> { enemies.add(if (l >= 1) Enemy(x.toFloat(), 7f, 2) else Enemy(x.toFloat(), 9.2f, 0)); x += 7 }
                8 -> { if (l >= 2) enemies.add(Enemy(x.toFloat(), 9.2f, 3)) else put('o', x, x + 3, 8, 8); x += 7 }
                else -> { put('P', x, x + 3, 7, 7); put('o', x + 1, x + 2, 6, 6); x += 6 }
            }
            if (r.nextInt(12) == 0) map[8][x] = if (r.nextBoolean()) 'S' else 'H'
        }
        if (isBoss) {
            put('#', lim + 4, W - 1, 10, 11); put('.', lim + 4, W - 4, 0, 9)
            map[9][lim + 6] = 'C'
            put('#', W - 3, W - 1, 2, 9)
            bossMax = 4 + l / 4
            boss = Boss(W - 16f, 8.2f, bossMax)
        }
        put('G', W - 6, W - 6, 6, 9)
        var n = 0
        for (row in map) for (ch in row) if (ch == 'o') n++
        gemTotal = n
        cpX = 2f; cpY = 8f
    }

    private fun startLevel(i: Int) {
        load(i)
        hp = maxHp(); gems = 0; lvCoins = 0; doubled = false; shield = false; wasGround = false; dashCd = 0f; res = 0; paused = false; intro = 2.2f; dashT = 0f; scr = 5
        respawn(); inv = 0f
    }

    private fun respawn() { p.x = cpX; p.y = cpY; p.vx = 0f; p.vy = 0f; inv = 1.5f; safeX = cpX; safeY = cpY }

    private fun hurt() {
        if (inv > 0f || res != 0) return
        if (shield) { shield = false; inv = 1.2f; shake = 0.2f; burst(p.x + 0.4f, p.y + 0.5f, 0xFF4DF3FF, 14); beep(ToneGenerator.TONE_PROP_NACK); return }
        hp--; inv = 1.4f; shake = 0.3f; buzz(); beep(ToneGenerator.TONE_PROP_NACK)
        burst(p.x + 0.4f, p.y + 0.5f, 0xFFFF3D00, 12)
        if (hp <= 0) { res = 2; save() } else { p.vy = -9f; p.vx = -face * 5f }
    }

    private fun win() {
        if (res != 0) return
        res = 1
        val st = if (gems >= gemTotal) 3 else if (gems * 10 >= gemTotal * 6) 2 else 1
        if (st > stars[lv]) stars[lv] = st
        lastStars = st
        earn(st * 5)
        unlocked = max(unlocked, min(12, lv + 2))
        beep(ToneGenerator.TONE_PROP_ACK); save()
    }

    private fun collectGem(tx: Int, ty: Int) {
        map[ty][tx] = '.'; gems++; earn(1)
        burst(tx + 0.5f, ty + 0.5f, 0xFF4DF3FF, 6); beep(ToneGenerator.TONE_PROP_BEEP)
    }

    private fun upgrade(j: Int) {
        val lvl = upLevel(j)
        val cost = 150 * (lvl + 1)
        if (lvl >= 3) { msg = "Mejora al máximo"; msgT = 2f }
        else if (coins >= cost) {
            coins -= cost
            when (j) { 0 -> upHp++; 1 -> upDash++; else -> upMag++ }
            beep(ToneGenerator.TONE_PROP_ACK)
        } else { beep(ToneGenerator.TONE_PROP_NACK); msg = "Te faltan ${cost - coins} monedas"; msgT = 2f }
        save()
    }

    private fun gift() {
        val today = System.currentTimeMillis() / 86400000L
        if (giftState == 0) {
            streak = if (lastDay == today - 1) min(streak + 1, 6) else 0
            lastGift = 25 + 15 * streak
            coins += lastGift; lastDay = today; giftState = 1
            msg = "¡+$lastGift monedas! Racha: ${streak + 1} día(s)"; msgT = 2.5f
            beep(ToneGenerator.TONE_PROP_ACK); save()
        } else if (giftState == 1) showAd(3)
    }

    private fun buy(j: Int) {
        if ((owned and (1 shl j)) != 0) { skin = j; beep(ToneGenerator.TONE_PROP_BEEP) }
        else if (coins >= SK_P[j]) { coins -= SK_P[j]; owned = owned or (1 shl j); skin = j; beep(ToneGenerator.TONE_PROP_ACK) }
        else { beep(ToneGenerator.TONE_PROP_NACK); msg = "Te faltan ${SK_P[j] - coins} monedas"; msgT = 2f }
        save()
    }

    // ---------- Física ----------
    private fun hit(b: Body): Boolean {
        for (ty in floor(b.y).toInt()..floor(b.y + b.h - 0.0001f).toInt())
            for (tx in floor(b.x).toInt()..floor(b.x + b.w - 0.0001f).toInt()) {
                if (tx < 0 || tx >= W) return true
                if (ty in 0 until H && map[ty][tx] == '#') return true
            }
        return false
    }

    private fun move(b: Body, dt: Float) {
        b.vy = min(b.vy + 40f * dt, 20f)
        b.x += b.vx * dt
        b.wall = false
        if (hit(b)) { b.wall = true; b.x = if (b.vx > 0) floor(b.x + b.w - 0.0001f) - b.w else floor(b.x) + 1f }
        val before = b.y + b.h
        b.y += b.vy * dt
        b.ground = false
        if (hit(b)) {
            if (b.vy > 0) { b.y = floor(b.y + b.h - 0.0001f) - b.h; b.ground = true } else b.y = floor(b.y) + 1f
            b.vy = 0f
        } else if (b.vy > 0f) {
            val ty = floor(b.y + b.h).toInt()
            if (ty in 0 until H && before <= ty + 0.05f) {
                for (tx in floor(b.x).toInt()..floor(b.x + b.w - 0.0001f).toInt())
                    if (tx in 0 until W && map[ty][tx] == 'P') { b.y = ty - b.h; b.ground = true; b.vy = 0f; break }
            }
        }
    }

    private fun overlap(a: Body, b: Body) = a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y

    private fun update(dt: Float) {
        time += dt
        while (true) { val t = taps.poll() ?: break; tap(t.x, t.y) }
        layout()
        if (adDone) { adDone = false; if (adReward) grant(adMode); adMode = 0; adReward = false }
        adT -= dt
        if (adT <= 0f) { adT = 15f; loadAd() }
        for (q in parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 12f * dt; q.life -= dt }
        parts.removeAll { it.life <= 0f }
        if (shake > 0f) shake -= dt
        if (msgT > 0f) msgT -= dt
        if (scr != 5 || paused || res != 0) return

        intro -= dt; inv -= dt; dashCd -= dt
        val dir = (if (goR) 1 else 0) - (if (goL) 1 else 0)
        if (dir != 0) face = dir
        if (dashT > 0f) {
            dashT -= dt; p.vx = face * 14f; p.vy = 0f
            burst(p.x + p.w / 2, p.y + p.h / 2, 0xFF4DF3FF, 1)
        } else p.vx += (dir * 6.2f - p.vx) * min(1f, 12f * dt)
        if (goJ && !jPrev) {
            if (p.ground) { p.vy = -16f; jumps = 1; beep(ToneGenerator.TONE_DTMF_1) }
            else if (jumps < 2) { p.vy = -14f; jumps = 2; beep(ToneGenerator.TONE_DTMF_3); burst(p.x + p.w / 2, p.y + p.h, 0xFFFFFFFF, 6) }
        }
        jPrev = goJ
        if (p.vy >= 0f) spr = false
        if (!goJ && !spr && p.vy < -5f && dashT <= 0f) p.vy = -5f
        if (goD && !dPrev && dashCd <= 0f && dashT <= 0f) { dashT = 0.18f; dashCd = 0.9f - 0.15f * upDash; beep(ToneGenerator.TONE_DTMF_9); buzz() }
        dPrev = goD
        move(p, dt)
        if (p.ground) { jumps = 0; safeX = p.x; safeY = p.y }
        if (p.ground && !wasGround) burst(p.x + 0.4f, p.y + p.h, 0x88FFFFFF, 4)
        wasGround = p.ground
        if (upMag > 0) {
            val rr = 1.2f + upMag
            for (ty in max(0, floor(p.y - rr).toInt())..min(H - 1, floor(p.y + rr).toInt()))
                for (tx in max(0, floor(p.x - rr).toInt())..min(W - 1, floor(p.x + rr).toInt()))
                    if (map[ty][tx] == 'o' && hypot(tx + 0.5f - p.x - 0.4f, ty + 0.5f - p.y - 0.5f) < rr) collectGem(tx, ty)
        }

        for (ty in floor(p.y).toInt()..floor(p.y + p.h - 0.0001f).toInt())
            for (tx in floor(p.x).toInt()..floor(p.x + p.w - 0.0001f).toInt()) {
                if (tx !in 0 until W || ty !in 0 until H) continue
                when (map[ty][tx]) {
                    'o' -> collectGem(tx, ty)
                    'S' -> { map[ty][tx] = '.'; shield = true; burst(tx + 0.5f, ty + 0.5f, 0xFF4DF3FF, 10); beep(ToneGenerator.TONE_PROP_ACK) }
                    'H' -> if (hp < maxHp()) { map[ty][tx] = '.'; hp++; burst(tx + 0.5f, ty + 0.5f, 0xFFFF5252, 10); beep(ToneGenerator.TONE_PROP_ACK) }
                    'C' -> if (cpX != tx.toFloat()) { cpX = tx.toFloat(); cpY = 8f; beep(ToneGenerator.TONE_PROP_ACK) }
                    'G' -> if (boss == null) win() else { msg = "¡Derrota al jefe primero!"; msgT = 1.5f }
                    '=' -> if (p.vy >= 0f) { p.vy = -23f; jumps = 1; spr = true; beep(ToneGenerator.TONE_DTMF_5) }
                    '^' -> if (p.y + p.h > ty + 0.5f) hurt()
                }
            }

        for (e in enemies) {
            if (e.dead) { e.t += dt; continue }
            if (abs(e.x - p.x) > 18f) continue
            when (e.kind) {
                2 -> {
                    if (abs(e.x - p.x) < 10f) e.vx = sign(p.x - e.x) * 1.8f
                    e.x += e.vx * dt; e.y = e.y0 + sin(time * 3f + e.x) * 1.2f
                }
                3 -> {
                    e.cd -= dt
                    if (e.cd <= 0f && e.x > p.x && e.x - p.x < 14f) { e.cd = 2.2f; bullets.add(Bullet(e.x, e.y + 0.25f, -6f)); beep(ToneGenerator.TONE_DTMF_7) }
                }
                else -> { move(e, dt); if (e.wall) e.vx = -e.vx }
            }
            if (e.y > 14f) { e.dead = true; e.t = 9f; continue }
            if (res == 0 && overlap(p, e)) {
                if (dashT > 0f || (p.vy > 0f && !e.spiky && p.y + p.h < e.y + 0.6f)) {
                    e.dead = true; earn(2)
                    burst(e.x + 0.4f, e.y + 0.4f, 0xFFFF5C8A, 10); beep(ToneGenerator.TONE_PROP_NACK)
                    if (dashT <= 0f) { p.vy = -10f; jumps = 1; spr = true }
                } else hurt()
            }
        }
        enemies.removeAll { it.dead && it.t > 0.4f }
        for (b in bullets) {
            b.x += b.vx * dt; b.life -= dt
            val bx = floor(b.x).toInt(); val by = floor(b.y).toInt()
            if (bx < 0 || bx >= W || (by in 0 until H && map[by][bx] == '#')) b.life = 0f
            else if (res == 0 && b.x < p.x + p.w && b.x + 0.45f > p.x && b.y < p.y + p.h && b.y + 0.3f > p.y) {
                b.life = 0f
                if (dashT <= 0f) hurt() else burst(b.x, b.y, 0xFFFFAB40, 6)
            }
        }
        bullets.removeAll { it.life <= 0f }
        boss?.let { bs ->
            bs.inv -= dt; bs.tm -= dt
            when (bs.state) {
                0 -> { bs.vx = sign(p.x - bs.x) * 2f; if (bs.tm <= 0f) { bs.state = 1; bs.tm = 0.8f; bs.vx = 0f } }
                1 -> { bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 2; bs.tm = 1.1f; bs.dir = if (p.x < bs.x) -1 else 1; bs.vy = -13f } }
                2 -> { bs.vx = bs.dir * 9f; if (bs.tm <= 0f || bs.wall) { bs.state = 3; bs.tm = 1.6f; bs.vx = 0f; shake = 0.25f } }
                else -> { bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 0; bs.tm = 2.5f } }
            }
            move(bs, dt)
            bs.x = bs.x.coerceIn(W - 30f, W - 6.8f)
            if (res == 0 && overlap(p, bs)) {
                val stomp = p.vy > 0f && p.y + p.h < bs.y + 0.7f
                if ((stomp || dashT > 0f) && bs.inv <= 0f) {
                    bs.hp--; bs.inv = 1.2f; bs.state = 3; bs.tm = 1.6f; bs.vx = 0f
                    p.vy = -12f; jumps = 1; spr = true; shake = 0.3f; buzz()
                    burst(bs.x + 0.9f, bs.y + 0.9f, 0xFFFFD740, 16); beep(ToneGenerator.TONE_PROP_NACK)
                    if (bs.hp <= 0) { boss = null; earn(25); burst(bs.x + 0.9f, bs.y + 0.9f, 0xFFFF5C8A, 30); beep(ToneGenerator.TONE_PROP_ACK) }
                } else if (bs.state != 3) hurt()
            }
        }
        if (res == 0 && p.y > 13f) {
            hp--; buzz()
            if (hp <= 0) { res = 2; save() } else respawn()
        }
    }

    // ---------- Interfaz ----------
    private fun addBtn(cx: Float, cy: Float, w: Float, h: Float, label: String, sub: String = "", act: () -> Unit) {
        btns.add(Btn(RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), label, sub, act))
    }

    private fun controls() {
        val w = width.toFloat(); val h = height.toFloat()
        val s = h * (0.2f + 0.04f * ctl); val m = h * 0.04f
        bL = RectF(m, h - m - s, m + s, h - m)
        bR = RectF(m * 2 + s, h - m - s, m * 2 + s * 2, h - m)
        bJ = RectF(w - m - s * 1.2f, h - m - s * 1.2f, w - m, h - m)
        bD = RectF(w - m * 2 - s * 2.1f, h - m - s * 0.9f, w - m * 2 - s * 1.2f, h - m)
    }

    private fun layout() {
        btns.clear()
        val w = width.toFloat(); val h = height.toFloat()
        val bw = h * 1.1f; val bh = h * 0.12f
        val back = { addBtn(w * 0.14f, h * 0.9f, h * 0.45f, h * 0.11f, "ATRÁS") { scr = 1; confirm = false } }
        when (scr) {
            1 -> {
                val b2 = h * 0.1f
                addBtn(w / 2, h * 0.32f, bw, h * 0.115f, "REGALO DIARIO", when (giftState) { 0 -> "¡RECLAMAR!"; 1 -> "DUPLICAR: VER ANUNCIO"; else -> "VUELVE MAÑANA" }) { gift() }
                addBtn(w / 2, h * 0.46f, bw, b2, "JUGAR") { scr = 2 }
                addBtn(w / 2, h * 0.59f, bw, b2, "TIENDA") { scr = 3 }
                addBtn(w / 2, h * 0.72f, bw, b2, "AJUSTES") { scr = 4 }
                addBtn(w / 2, h * 0.85f, bw, b2, "SALIR") { post { (context as Activity).finish() } }
            }
            2 -> {
                for (i in 0 until 12) {
                    val cx = w * 0.36f + (i % 4) * h * 0.28f
                    val cy = h * 0.30f + (i / 4) * h * 0.22f
                    addBtn(cx, cy, h * 0.25f, h * 0.19f, "${i + 1}", if (i < unlocked) stars3(stars[i]) else "BLOQ.") { if (i < unlocked) startLevel(i) }
                }
                back()
            }
            3 -> {
                val gap = min(h * 0.7f, w * 0.31f); val cw = min(h * 0.66f, w * 0.29f)
                if (shopTab == 0) for (j in 0 until 6) {
                    val cx = w / 2 + (j % 3 - 1) * gap
                    val cy = h * 0.30f + (j / 3) * h * 0.36f
                    addBtn(cx, cy, cw, h * 0.33f, "") { buy(j) }
                } else for (j in 0 until 3) addBtn(w / 2 + (j - 1) * gap, h * 0.5f, cw, h * 0.5f, "") { upgrade(j) }
                back()
                addBtn(w * 0.84f, h * 0.9f, h * 0.55f, h * 0.11f, if (shopTab == 0) "MEJORAS" else "SKINS") { shopTab = 1 - shopTab }
            }
            4 -> {
                val sw = h * 1.5f; val sh = h * 0.1f
                addBtn(w / 2, h * 0.26f, sw, sh, "SONIDO: " + (if (snd) "SÍ" else "NO")) { snd = !snd; save() }
                addBtn(w / 2, h * 0.39f, sw, sh, "VIBRACIÓN: " + (if (hap) "SÍ" else "NO")) { hap = !hap; save() }
                addBtn(w / 2, h * 0.52f, sw, sh, "CONTROLES: " + arrayOf("PEQUEÑOS", "MEDIANOS", "GRANDES")[ctl]) { ctl = (ctl + 1) % 3; save(); controls() }
                addBtn(w / 2, h * 0.65f, sw, sh, "DIFICULTAD: " + arrayOf("FÁCIL", "NORMAL", "DIFÍCIL")[dif]) { dif = (dif + 1) % 3; save() }
                addBtn(w / 2, h * 0.78f, sw, sh, if (confirm) "¿SEGURO? TOCA OTRA VEZ" else "BORRAR PROGRESO") {
                    if (confirm) { coins = 0; unlocked = 1; owned = 1; skin = 0; stars.fill(0); upHp = 0; upDash = 0; upMag = 0; confirm = false; save() } else confirm = true
                }
                back()
            }
            5 -> {
                if (res == 0 && !paused) addBtn(w - h * 0.08f, h * 0.09f, h * 0.1f, h * 0.1f, "II") { paused = true }
                else if (res == 0) {
                    addBtn(w / 2, h * 0.45f, bw, bh, "CONTINUAR") { paused = false }
                    addBtn(w / 2, h * 0.60f, bw, bh, "REINICIAR") { startLevel(lv) }
                    addBtn(w / 2, h * 0.75f, bw, bh, "NIVELES") { scr = 2; save() }
                } else if (res == 1) {
                    if (!doubled) addBtn(w / 2, h * 0.47f, bw, h * 0.14f, "DUPLICAR MONEDAS", "VER ANUNCIO  (+$lvCoins)") { showAd(2) }
                    var y = 0.61f
                    if (lv < 11) { addBtn(w / 2, h * y, bw, bh, "SIGUIENTE") { startLevel(lv + 1) }; y += 0.14f }
                    addBtn(w / 2, h * y, bw, bh, "REINTENTAR") { startLevel(lv) }
                    addBtn(w / 2, h * (y + 0.14f), bw, bh, "NIVELES") { scr = 2 }
                } else {
                    addBtn(w / 2, h * 0.50f, bw, h * 0.15f, "REVIVIR AQUÍ", "VER ANUNCIO") { showAd(1) }
                    addBtn(w / 2, h * 0.68f, bw, bh, "REINTENTAR") { startLevel(lv) }
                    addBtn(w / 2, h * 0.83f, bw, bh, "NIVELES") { scr = 2 }
                }
            }
        }
    }

    private fun tap(x: Float, y: Float) {
        if (scr == 0) { scr = 1; beep(ToneGenerator.TONE_PROP_BEEP); return }
        for (b in btns) if (b.r.contains(x, y)) { b.act(); buzz(); return }
    }

    // ---------- Bucle y ciclo de vida ----------
    override fun surfaceCreated(sh: SurfaceHolder) { running = true; thread = Thread(this).also { it.start() } }
    override fun surfaceChanged(sh: SurfaceHolder, f: Int, w: Int, h: Int) {}
    override fun surfaceDestroyed(sh: SurfaceHolder) {
        running = false; thread?.join(); thread = null
        if (scr == 5 && res == 0) paused = true
        save()
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min((now - last) / 1e9f, 0.033f)
            last = now
            update(dt)
            val c = holder.lockCanvas() ?: continue
            try { render(c) } finally { holder.unlockCanvasAndPost(c) }
            val spent = (System.nanoTime() - now) / 1_000_000
            if (spent < 16) Thread.sleep(16 - spent)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); controls() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) taps.add(PointF(e.getX(e.actionIndex), e.getY(e.actionIndex)))
        goL = false; goR = false; goJ = false; goD = false
        if (a == MotionEvent.ACTION_CANCEL) return true
        val up = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP
        for (i in 0 until e.pointerCount) {
            if (up && i == e.actionIndex) continue
            val x = e.getX(i); val y = e.getY(i)
            if (bL.contains(x, y)) goL = true
            if (bR.contains(x, y)) goR = true
            if (bJ.contains(x, y)) goJ = true
            if (bD.contains(x, y)) goD = true
        }
        return true
    }

    // ---------- Dibujo ----------
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Long, al: Paint.Align = Paint.Align.CENTER) {
        paint.style = Paint.Style.FILL; paint.textSize = size; paint.textAlign = al; paint.color = k(col)
        c.drawText(s, x, y, paint)
    }

    private fun box(c: Canvas, l: Float, t: Float, s: Float, fill: Long, line: Long) {
        paint.style = Paint.Style.FILL
        paint.color = k(line); c.drawRect(l, t, l + s + 1f, t + s + 1f, paint)
        paint.color = k(fill); c.drawRect(l + s * 0.04f, t + s * 0.04f, l + s * 0.96f + 1f, t + s * 0.96f + 1f, paint)
    }

    private fun drawBtn(c: Canvas, b: Btn) {
        val r = b.r; val rad = r.height() * 0.25f
        paint.style = Paint.Style.FILL; paint.color = k(0xDD1A1033); c.drawRoundRect(r, rad, rad, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = r.height() * 0.05f; paint.color = k(0xFF00E5FF)
        c.drawRoundRect(r, rad, rad, paint)
        if (b.sub.isEmpty()) txt(c, b.label, r.centerX(), r.centerY() + r.height() * 0.14f, r.height() * 0.4f, 0xFFFFFFFF)
        else {
            txt(c, b.label, r.centerX(), r.centerY() - r.height() * 0.05f, r.height() * 0.3f, 0xFFFFFFFF)
            txt(c, b.sub, r.centerX(), r.centerY() + r.height() * 0.3f, r.height() * 0.24f, 0xFFFFE066)
        }
    }

    private fun padBtn(c: Canvas, r: RectF, label: String, on: Boolean, size: Float) {
        paint.style = Paint.Style.FILL; paint.color = k(if (on) 0x88FFFFFF else 0x44000000)
        c.drawRoundRect(r, r.height() * 0.3f, r.height() * 0.3f, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = k(0x99FFFFFF)
        c.drawRoundRect(r, r.height() * 0.3f, r.height() * 0.3f, paint)
        if (label == "<" || label == ">") {
            val d = if (label == "<") -1f else 1f
            val q = r.height() * 0.22f
            path.reset()
            path.moveTo(r.centerX() + d * q, r.centerY()); path.lineTo(r.centerX() - d * q, r.centerY() - q)
            path.lineTo(r.centerX() - d * q, r.centerY() + q); path.close()
            paint.style = Paint.Style.FILL; paint.color = Color.WHITE; c.drawPath(path, paint)
        } else txt(c, label, r.centerX(), r.centerY() + size * 0.35f, size, 0xFFFFFFFF)
    }

    private fun drawHero(c: Canvas, l: Float, t: Float, w: Float, h: Float, fc: Int, sk: Int, run: Boolean) {
        val body = skinCol(sk)
        val s = if (run) sin(time * 20f) * 0.12f else 0f
        paint.style = Paint.Style.FILL
        paint.color = k(0xFF263238)
        c.drawRect(l + (0.15f + s) * w, t + 0.78f * h, l + (0.42f + s) * w, t + h, paint)
        c.drawRect(l + (0.58f - s) * w, t + 0.78f * h, l + (0.85f - s) * w, t + h, paint)
        paint.color = body
        c.drawRoundRect(l + 0.05f * w, t + 0.2f * h, l + 0.95f * w, t + 0.85f * h, 0.2f * w, 0.2f * w, paint)
        paint.color = k(SK_V[sk])
        if (fc > 0) c.drawRoundRect(l + 0.45f * w, t + 0.32f * h, l + 0.92f * w, t + 0.52f * h, 0.08f * w, 0.08f * w, paint)
        else c.drawRoundRect(l + 0.08f * w, t + 0.32f * h, l + 0.55f * w, t + 0.52f * h, 0.08f * w, 0.08f * w, paint)
        paint.color = body; paint.strokeWidth = 0.06f * w
        c.drawLine(l + 0.5f * w, t + 0.2f * h, l + 0.5f * w, t + 0.04f * h, paint)
        paint.color = k(0xFFFF2BD6)
        c.drawCircle(l + 0.5f * w, t + 0.04f * h, 0.07f * w, paint)
    }

    private fun render(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (scr == 5) renderPlay(c, w, h) else renderMenu(c, w, h)
        for (b in btns) drawBtn(c, b)
        if (scr == 3 && shopTab == 0) for (j in 0 until 6) {
            val r = btns[j].r
            drawHero(c, r.centerX() - r.height() * 0.17f, r.top + r.height() * 0.1f, r.height() * 0.34f, r.height() * 0.4f, 1, j, false)
            txt(c, SK_N[j], r.centerX(), r.top + r.height() * 0.68f, r.height() * 0.13f, 0xFFFFFFFF)
            val own = (owned and (1 shl j)) != 0
            txt(c, if (own) (if (skin == j) "EQUIPADO" else "EQUIPAR") else "${SK_P[j]} monedas", r.centerX(), r.top + r.height() * 0.9f, r.height() * 0.11f,
                if (skin == j && own) 0xFF69F0AE else 0xFFFFE066)
        }
        if (scr == 3 && shopTab == 1) for (j in 0 until 3) {
            val r = btns[j].r
            val lvl = upLevel(j)
            txt(c, arrayOf("CORAZÓN EXTRA", "DASH RÁPIDO", "IMÁN DE GEMAS")[j], r.centerX(), r.top + r.height() * 0.2f, r.height() * 0.09f, 0xFFFFFFFF)
            txt(c, arrayOf("+1 vida máxima", "Recarga más corta", "Atrae las gemas")[j], r.centerX(), r.top + r.height() * 0.34f, r.height() * 0.07f, 0xFF9FA8DA)
            for (i in 0 until 3) {
                paint.style = Paint.Style.FILL; paint.color = k(if (i < lvl) 0xFF4DF3FF else 0x44FFFFFF)
                c.drawRect(r.left + r.width() * (0.2f + i * 0.22f), r.top + r.height() * 0.5f, r.left + r.width() * (0.38f + i * 0.22f), r.top + r.height() * 0.6f, paint)
            }
            txt(c, if (lvl >= 3) "MÁXIMO" else "${150 * (lvl + 1)} monedas", r.centerX(), r.top + r.height() * 0.85f, r.height() * 0.09f, if (lvl >= 3) 0xFF69F0AE else 0xFFFFE066)
        }
        if (scr in 1..4) txt(c, "MONEDAS: $coins", w - h * 0.04f, h * 0.08f, h * 0.05f, 0xFFFFE066, Paint.Align.RIGHT)
        if (scr != 0 && msgT > 0f) txt(c, msg, w / 2, h * (if (scr == 5) 0.985f else 0.96f), h * 0.04f, 0xFFFF8A80)
    }

    private fun renderMenu(c: Canvas, w: Float, h: Float) {
        c.drawColor(k(0xFF0B0620))
        paint.style = Paint.Style.FILL
        for (i in 0 until 40) {
            paint.color = Color.WHITE
            paint.alpha = (60 + 120 * (0.5f + 0.5f * sin(time * 2f + i))).toInt()
            c.drawCircle(((i * 7919) % 1000) / 1000f * w, ((i * 104729) % 1000) / 1000f * h * 0.6f, h * 0.004f + (i % 3) * 1.2f, paint)
        }
        paint.color = k(0x55FF2BD6); c.drawCircle(w / 2, h * 0.62f, h * 0.3f, paint)
        paint.color = k(0xFF0B0620); c.drawRect(0f, h * 0.62f, w, h, paint)
        paint.color = k(0x66FF2BD6); paint.strokeWidth = 3f
        for (i in 0..7) { val yy = h * 0.62f + ((i + time * 0.6f) % 8f).pow(2) * h * 0.006f; c.drawLine(0f, yy, w, yy, paint) }
        for (i in -8..8) c.drawLine(w / 2 + i * h * 0.02f, h * 0.62f, w / 2 + i * w * 0.12f, h, paint)
        when (scr) {
            0 -> {
                txt(c, "NEON DASH", w / 2 + h * 0.01f, h * 0.36f + h * 0.01f, h * 0.2f, 0xFFFF2BD6)
                txt(c, "NEON DASH", w / 2, h * 0.36f, h * 0.2f, 0xFFFFFFFF)
                drawHero(c, w / 2 - h * 0.1f, h * 0.45f, h * 0.2f, h * 0.24f, 1, skin, true)
                if ((time * 2f).toInt() % 2 == 0) txt(c, "TOCA PARA EMPEZAR", w / 2, h * 0.9f, h * 0.06f, 0xFF4DF3FF)
            }
            1 -> {
                txt(c, "NEON DASH", w / 2, h * 0.2f, h * 0.13f, 0xFFFFFFFF)
                drawHero(c, w * 0.14f, h * 0.4f - abs(sin(time * 3f)) * h * 0.08f, h * 0.24f, h * 0.3f, 1, skin, false)
            }
            2 -> {
                txt(c, "NIVELES", w / 2, h * 0.11f, h * 0.08f, 0xFFFFFFFF)
                for (r in 0..2) txt(c, WN[r], w * 0.14f, h * (0.30f + r * 0.22f) + h * 0.02f, h * 0.05f, TH[r][4].let { if (r == 1) 0xFFFFB74D else it })
            }
            3 -> txt(c, if (shopTab == 0) "TIENDA - SKINS" else "TIENDA - MEJORAS", w / 2, h * 0.1f, h * 0.08f, 0xFFFFFFFF)
            4 -> txt(c, "AJUSTES", w / 2, h * 0.12f, h * 0.08f, 0xFFFFFFFF)
        }
    }

    private fun renderPlay(c: Canvas, w: Float, h: Float) {
        val T = TH[lv / 4]
        val sc = h / H
        val vw = w / sc
        val cam = (p.x - vw * 0.4f).coerceIn(0f, W - vw)
        c.drawColor(k(T[0]))
        paint.style = Paint.Style.FILL
        paint.color = (k(T[4]) and 0x00FFFFFF) or 0x44000000
        c.drawCircle(w * 0.78f, h * 0.25f, h * 0.14f, paint)
        paint.style = Paint.Style.FILL
        paint.color = k(AMB[lv / 4])
        for (i in 0 until 36) {
            val fx = ((i * 7919) % 1000) / 1000f
            val fy = ((i * 104729) % 1000) / 1000f
            val spd = (0.05f + (i % 4) * 0.03f) * (if (lv / 4 == 1) -1f else 1f)
            val ay = ((((fy + time * spd) % 1f) + 1f) % 1f) * h
            val ax = (((fx * w - cam * sc * (0.2f + (i % 3) * 0.15f)) % w) + w) % w
            c.drawCircle(ax, ay, h * (0.004f + (i % 3) * 0.002f), paint)
        }
        c.save()
        c.translate(0f, -2.4f * sc)
        val par = cam * 0.35f
        val k0 = floor(par / 2f).toInt()
        paint.color = k(T[1])
        for (i in k0..k0 + (vw / 2f).toInt() + 3) {
            val bh = 2f + ((i * 37) % 5) * 0.8f
            val bx = (i * 2f - par) * sc
            c.drawRect(bx, (10f - bh) * sc, bx + 1.7f * sc, 10f * sc, paint)
        }
        if (shake > 0f) c.translate((rnd.nextFloat() - 0.5f) * h * 0.03f, (rnd.nextFloat() - 0.5f) * h * 0.03f)
        val x0 = floor(cam).toInt(); val x1 = min(W - 1, ceil(cam + vw).toInt())
        for (tx in x0..x1) if (map[10][tx] == '.' && map[11][tx] == '.') {
            paint.color = k(HZ[lv / 4])
            c.drawRect((tx - cam) * sc, (11.4f + 0.1f * sin(time * 3f + tx)) * sc, (tx - cam) * sc + sc + 1f, 15f * sc, paint)
        }
        for (ty in 0 until H) for (tx in x0..x1) {
            val t = map[ty][tx]
            if (t == '.') continue
            val l = (tx - cam) * sc; val tp = ty * sc
            when (t) {
                'S' -> {
                    paint.color = k(0x884DF3FF); c.drawCircle(l + sc / 2, tp + sc / 2, sc * (0.32f + 0.05f * sin(time * 5f)), paint)
                    paint.color = k(0xFF4DF3FF); c.drawCircle(l + sc / 2, tp + sc / 2, sc * 0.14f, paint)
                }
                'H' -> txt(c, "♥", l + sc / 2, tp + sc * (0.8f + 0.05f * sin(time * 5f)), sc * 0.9f, 0xFFFF5252)
                '#' -> {
                    box(c, l, tp, sc, T[2], 0x55000000)
                    if (ty == 0 || map[ty - 1][tx] != '#') { paint.color = k(T[3]); c.drawRect(l, tp, l + sc + 1f, tp + sc * 0.2f, paint) }
                }
                'P' -> {
                    paint.color = k(T[2]); c.drawRect(l, tp, l + sc + 1f, tp + sc * 0.4f, paint)
                    paint.color = k(T[4]); c.drawRect(l, tp, l + sc + 1f, tp + sc * 0.15f, paint)
                }
                '^' -> {
                    paint.color = k(0xFFE0E0E0)
                    for (i in 0..1) {
                        path.reset()
                        path.moveTo(l + i * 0.5f * sc, tp + sc); path.lineTo(l + (i * 0.5f + 0.25f) * sc, tp + sc * 0.45f); path.lineTo(l + (i * 0.5f + 0.5f) * sc, tp + sc)
                        path.close(); c.drawPath(path, paint)
                    }
                }
                'o' -> {
                    val ww = (0.1f + 0.2f * abs(cos(time * 4f + tx))) * sc
                    path.reset()
                    path.moveTo(l + sc / 2, tp + sc * 0.2f); path.lineTo(l + sc / 2 + ww, tp + sc / 2)
                    path.lineTo(l + sc / 2, tp + sc * 0.8f); path.lineTo(l + sc / 2 - ww, tp + sc / 2); path.close()
                    paint.color = k(0xFF4DF3FF); c.drawPath(path, paint)
                }
                'C' -> {
                    paint.color = Color.LTGRAY; c.drawRect(l + sc * 0.45f, tp, l + sc * 0.55f, tp + sc + 1f, paint)
                    paint.color = k(if (cpX == tx.toFloat()) 0xFF69F0AE else 0xFFFF5252)
                    c.drawRect(l + sc * 0.55f, tp, l + sc * 1.2f, tp + sc * 0.4f, paint)
                }
                'G' -> {
                    paint.color = (k(T[4]) and 0x00FFFFFF) or ((140 + (90 * sin(time * 4f)).toInt()) shl 24)
                    c.drawRect(l + sc * 0.1f, tp, l + sc * 0.9f, tp + sc + 1f, paint)
                }
                '=' -> {
                    paint.color = k(0xFFFFEB3B); c.drawRect(l + sc * 0.1f, tp + sc * 0.7f, l + sc * 0.9f, tp + sc, paint)
                    paint.color = k(0xFFFF6D00); c.drawRect(l + sc * 0.2f, tp + sc * 0.85f, l + sc * 0.8f, tp + sc, paint)
                }
            }
        }
        paint.color = k(T[2])
        for (tx in x0..x1) if (map[11][tx] == '#') c.drawRect((tx - cam) * sc, 12f * sc, (tx - cam) * sc + sc + 1f, 15f * sc, paint)
        for (e in enemies) {
            val l = (e.x - cam) * sc; val tp = e.y * sc
            if (e.dead || l < -sc || l > w) continue
            when (e.kind) {
                2 -> {
                    paint.color = k(0xFFB388FF)
                    val fl = sin(time * 14f) * 0.25f * sc
                    path.reset(); path.moveTo(l + 0.4f * sc, tp + 0.4f * sc); path.lineTo(l - 0.35f * sc, tp + 0.1f * sc + fl); path.lineTo(l + 0.1f * sc, tp + 0.6f * sc); path.close(); c.drawPath(path, paint)
                    path.reset(); path.moveTo(l + 0.4f * sc, tp + 0.4f * sc); path.lineTo(l + 1.15f * sc, tp + 0.1f * sc + fl); path.lineTo(l + 0.7f * sc, tp + 0.6f * sc); path.close(); c.drawPath(path, paint)
                    c.drawCircle(l + 0.4f * sc, tp + 0.4f * sc, 0.32f * sc, paint)
                }
                3 -> {
                    paint.color = k(0xFF607D8B); c.drawRoundRect(l, tp + 0.2f * sc, l + 0.8f * sc, tp + 0.8f * sc, 0.15f * sc, 0.15f * sc, paint)
                    paint.color = k(0xFF37474F); c.drawRect(l - 0.35f * sc, tp + 0.35f * sc, l + 0.2f * sc, tp + 0.55f * sc, paint)
                }
                else -> {
                    paint.color = k(if (e.spiky) 0xFFE53935 else 0xFFFF9100)
                    c.drawRoundRect(l, tp + 0.1f * sc, l + 0.8f * sc, tp + 0.8f * sc, 0.25f * sc, 0.25f * sc, paint)
                    if (e.spiky) for (i in 0..2) {
                        path.reset()
                        path.moveTo(l + (0.05f + i * 0.25f) * sc, tp + 0.15f * sc); path.lineTo(l + (0.175f + i * 0.25f) * sc, tp - 0.1f * sc)
                        path.lineTo(l + (0.3f + i * 0.25f) * sc, tp + 0.15f * sc); path.close(); c.drawPath(path, paint)
                    }
                }
            }
            paint.color = Color.WHITE; c.drawCircle(l + 0.4f * sc, tp + 0.42f * sc, 0.2f * sc, paint)
            paint.color = Color.BLACK; c.drawCircle(l + 0.4f * sc + sign(e.vx) * 0.06f * sc, tp + 0.42f * sc, 0.09f * sc, paint)
        }
        paint.color = k(0xFFFFAB40)
        for (bl in bullets) c.drawOval((bl.x - cam) * sc, bl.y * sc, (bl.x - cam) * sc + 0.45f * sc, bl.y * sc + 0.3f * sc, paint)
        boss?.let { bs ->
            val l = (bs.x - cam) * sc; val tp = bs.y * sc; val bw = bs.w * sc; val bhh = bs.h * sc
            val flash = bs.inv > 0f && (time * 20f).toInt() % 2 == 0
            paint.color = if (flash) Color.WHITE else if (bs.state == 1 && (time * 16f).toInt() % 2 == 0) k(0xFFFF1744) else k(0xFF6A1B9A)
            c.drawRoundRect(l, tp, l + bw, tp + bhh, bw * 0.2f, bw * 0.2f, paint)
            paint.color = k(0xFFFFD740)
            for (i in 0..3) {
                path.reset()
                path.moveTo(l + (0.1f + i * 0.22f) * bw, tp + 0.02f * bhh); path.lineTo(l + (0.21f + i * 0.22f) * bw, tp - 0.2f * bhh)
                path.lineTo(l + (0.32f + i * 0.22f) * bw, tp + 0.02f * bhh); path.close(); c.drawPath(path, paint)
            }
            paint.color = Color.WHITE
            c.drawCircle(l + 0.3f * bw, tp + 0.38f * bhh, 0.13f * bw, paint); c.drawCircle(l + 0.7f * bw, tp + 0.38f * bhh, 0.13f * bw, paint)
            paint.color = if (bs.state == 3) k(0xFF9E9E9E) else Color.BLACK
            c.drawCircle(l + 0.3f * bw + bs.dir * 0.03f * bw, tp + 0.4f * bhh, 0.06f * bw, paint); c.drawCircle(l + 0.7f * bw + bs.dir * 0.03f * bw, tp + 0.4f * bhh, 0.06f * bw, paint)
            paint.color = Color.BLACK; c.drawRect(l + 0.25f * bw, tp + 0.68f * bhh, l + 0.75f * bw, tp + 0.78f * bhh, paint)
        }
        for (q in parts) {
            paint.color = q.col; paint.alpha = (min(1f, q.life * 2.5f) * 255).toInt()
            c.drawRect((q.x - cam) * sc, q.y * sc, (q.x - cam) * sc + 0.14f * sc, q.y * sc + 0.14f * sc, paint)
        }
        if (inv <= 0f || (time * 20f).toInt() % 2 == 0) {
            val st = min(abs(p.vy) / 40f, 0.25f)
            val pw = p.w * sc * 1.2f * (1f - st * 0.5f)
            val ph = p.h * sc * (1f + st)
            drawHero(c, (p.x - cam) * sc + (p.w * sc - pw) / 2, p.y * sc + p.h * sc - ph, pw, ph, face, skin, p.ground && abs(p.vx) > 0.5f)
        }
        if (shield) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.08f; paint.color = k(0xCC4DF3FF)
            c.drawCircle((p.x - cam + p.w / 2) * sc, (p.y + p.h / 2) * sc, p.h * sc * 0.85f, paint)
            paint.style = Paint.Style.FILL
        }
        c.restore()

        boss?.let { bs ->
            if (p.x > W - 40f) {
                val bw2 = h * 1.2f; val bx = w / 2 - bw2 / 2
                paint.style = Paint.Style.FILL; paint.color = k(0x88000000); c.drawRect(bx, h * 0.13f, bx + bw2, h * 0.17f, paint)
                paint.color = k(0xFFFF1744); c.drawRect(bx, h * 0.13f, bx + bw2 * bs.hp / bossMax, h * 0.17f, paint)
                txt(c, "JEFE", w / 2, h * 0.115f, h * 0.04f, 0xFFFFFFFF)
            }
        }
        for (i in 0 until maxHp()) txt(c, "♥", h * 0.04f + i * h * 0.06f, h * 0.09f, h * 0.07f, if (i < hp) 0xFFFF5252 else 0x55FFFFFF, Paint.Align.LEFT)
        txt(c, "GEMAS $gems/$gemTotal", h * 0.05f + maxHp() * h * 0.06f, h * 0.085f, h * 0.05f, 0xFF4DF3FF, Paint.Align.LEFT)
        if (intro > 0f) txt(c, "NIVEL ${lv + 1} - ${WN[lv / 4]}" + (if (lv % 4 == 3) "  ¡JEFE!" else ""), w / 2, h * 0.3f, h * 0.09f, 0xFFFFFFFF)
        if (res == 0 && !paused) {
            padBtn(c, bL, "<", goL, h * 0.1f); padBtn(c, bR, ">", goR, h * 0.1f)
            padBtn(c, bJ, "SALTO", goJ, h * 0.06f); padBtn(c, bD, "DASH", goD, h * 0.05f)
        }
        if (paused || res != 0) { paint.style = Paint.Style.FILL; paint.color = k(0xAA000000); c.drawRect(0f, 0f, w, h, paint) }
        if (paused) txt(c, "PAUSA", w / 2, h * 0.3f, h * 0.14f, 0xFFFFFFFF)
        if (res == 1) {
            txt(c, "¡NIVEL COMPLETADO!", w / 2, h * 0.15f, h * 0.09f, 0xFF4DF3FF)
            txt(c, stars3(lastStars), w / 2, h * 0.28f, h * 0.12f, 0xFFFFE066)
            txt(c, "Gemas $gems/$gemTotal   Monedas del nivel: $lvCoins", w / 2, h * 0.37f, h * 0.045f, 0xFFFFFFFF)
        }
        if (res == 2) txt(c, "¡HAS CAÍDO!", w / 2, h * 0.3f, h * 0.13f, 0xFFFF5252)
    }
}
