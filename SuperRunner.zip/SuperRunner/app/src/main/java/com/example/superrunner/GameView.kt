package com.example.superrunner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

private open class Body(var x: Float, var y: Float, val w: Float, val h: Float) {
    var vx = 0f
    var vy = 0f
    var ground = false
    var wall = false
    var head = false
}

private class Enemy(x: Float, y: Float) : Body(x, y, 0.8f, 0.8f) {
    var dead = false
    var t = 0f
    init { vx = -1.5f }
}

private class Pop(val x: Float, val y: Float) { var t = 0f }

/** Motor del juego: 1 tile = 1.0 unidad de mundo. Estados: 0 jugando, 1 muriendo, 2 game over, 3 victoria. */
class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {
    private val W = 120
    private val H = 12
    private val map = Array(H) { CharArray(W) { '.' } }
    private val enemies = ArrayList<Enemy>()
    private val pops = ArrayList<Pop>()
    private val p = Body(2f, 8f, 0.8f, 0.95f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var btnL = RectF()
    private var btnR = RectF()
    private var btnJ = RectF()
    @Volatile private var goL = false
    @Volatile private var goR = false
    @Volatile private var goJ = false
    @Volatile private var wantReset = false
    @Volatile private var running = false
    @Volatile private var state = 0
    private var thread: Thread? = null
    private var lives = 3
    private var coins = 0
    private var score = 0
    private var face = 1
    private var time = 0f
    private var deadT = 0f

    init {
        holder.addCallback(this)
        newGame()
    }

    private fun k(v: Long) = v.toInt()

    // ---------- Nivel ----------
    private fun put(c: Char, x1: Int, x2: Int, y1: Int, y2: Int) {
        for (y in y1..y2) for (x in x1..x2) map[y][x] = c
    }

    private fun newGame() {
        for (r in map) r.fill('.')
        enemies.clear(); pops.clear()
        put('#', 0, W - 1, 10, 11)
        for ((a, b) in listOf(28 to 30, 55 to 57, 82 to 84)) put('.', a, b, 10, 11)
        for ((x, h) in listOf(18 to 2, 36 to 3, 45 to 2, 66 to 3, 90 to 2)) put('|', x, x + 1, 10 - h, 9)
        put('B', 10, 12, 6, 6); map[6][10] = '?'; map[6][12] = '?'
        put('B', 22, 26, 6, 6); map[6][24] = '?'
        put('B', 60, 64, 6, 6); map[6][62] = '?'
        put('B', 75, 77, 6, 6); map[6][76] = '?'
        put('o', 28, 30, 7, 7); put('o', 40, 43, 8, 8); put('o', 55, 57, 7, 7); put('o', 82, 84, 7, 7)
        for (i in 0..4) put('#', 96 + i, 96 + i, 9 - i, 9)
        put('F', 107, 107, 2, 9)
        for (x in listOf(14, 21, 33, 40, 48, 52, 62, 70, 74, 88, 93)) enemies.add(Enemy(x.toFloat(), 9.2f))
        lives = 3; coins = 0; score = 0
        respawn()
    }

    private fun respawn() { p.x = 2f; p.y = 8f; p.vx = 0f; p.vy = 0f; state = 0 }

    private fun die() { state = 1; deadT = 0f; lives--; p.vy = -12f; p.vx = 0f }

    // ---------- Física ----------
    private fun solid(tx: Int, ty: Int): Boolean {
        if (tx < 0 || tx >= W) return true
        if (ty < 0 || ty >= H) return false
        return map[ty][tx] in "#B?U|"
    }

    private fun hit(b: Body): Boolean {
        for (ty in floor(b.y).toInt()..floor(b.y + b.h - 0.0001f).toInt())
            for (tx in floor(b.x).toInt()..floor(b.x + b.w - 0.0001f).toInt())
                if (solid(tx, ty)) return true
        return false
    }

    private fun move(b: Body, dt: Float) {
        b.vy = min(b.vy + 40f * dt, 20f)
        b.x += b.vx * dt
        b.wall = false
        if (hit(b)) {
            b.wall = true
            b.x = if (b.vx > 0) floor(b.x + b.w - 0.0001f) - b.w else floor(b.x) + 1f
        }
        b.y += b.vy * dt
        b.ground = false; b.head = false
        if (hit(b)) {
            if (b.vy > 0) { b.y = floor(b.y + b.h - 0.0001f) - b.h; b.ground = true }
            else { b.y = floor(b.y) + 1f; b.head = true }
            b.vy = 0f
        }
    }

    private fun overlap(a: Body, b: Body) =
        a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y

    private fun bump() {
        val ty = floor(p.y).toInt() - 1
        val c = floor(p.x + p.w / 2).toInt()
        for (tx in listOf(c, floor(p.x).toInt(), floor(p.x + p.w - 0.0001f).toInt())) {
            if (tx in 0 until W && ty in 0 until H) {
                when (map[ty][tx]) {
                    '?' -> { map[ty][tx] = 'U'; coins++; score += 200; pops.add(Pop(tx + 0.5f, ty.toFloat())); return }
                    'B' -> { map[ty][tx] = '.'; score += 50; return }
                }
            }
        }
    }

    private fun update(dt: Float) {
        time += dt
        for (o in pops) o.t += dt
        pops.removeAll { it.t > 0.6f }
        if (state == 1) {
            p.vy += 40f * dt; p.y += p.vy * dt; deadT += dt
            if (deadT > 1.8f) { if (lives > 0) respawn() else state = 2 }
            return
        }
        if (state != 0) return

        val dir = (if (goR) 1 else 0) - (if (goL) 1 else 0)
        if (dir != 0) face = dir
        p.vx += (dir * 6f - p.vx) * min(1f, 12f * dt)
        if (goJ && p.ground) p.vy = -16f
        if (!goJ && p.vy < -5f) p.vy = -5f
        move(p, dt)
        if (p.head) bump()

        for (ty in floor(p.y).toInt()..floor(p.y + p.h - 0.0001f).toInt())
            for (tx in floor(p.x).toInt()..floor(p.x + p.w - 0.0001f).toInt()) {
                if (tx !in 0 until W || ty !in 0 until H) continue
                when (map[ty][tx]) {
                    'o' -> { map[ty][tx] = '.'; coins++; score += 100 }
                    'F' -> { state = 3; score += 1000 }
                }
            }

        for (e in enemies) {
            if (e.dead) { e.t += dt; continue }
            if (abs(e.x - p.x) > 16f) continue
            move(e, dt)
            if (e.wall) e.vx = -e.vx
            if (e.y > 14f) { e.dead = true; e.t = 9f; continue }
            if (state == 0 && overlap(p, e)) {
                if (p.vy > 0 && p.y + p.h < e.y + 0.6f) {
                    e.dead = true; e.vx = 0f; p.vy = -9f; score += 100
                } else die()
            }
        }
        enemies.removeAll { it.dead && it.t > 0.5f }
        if (state == 0 && p.y > 13f) die()
    }

    // ---------- Bucle y ciclo de vida ----------
    override fun surfaceCreated(sh: SurfaceHolder) {
        running = true
        thread = Thread(this).also { it.start() }
    }

    override fun surfaceChanged(sh: SurfaceHolder, f: Int, w: Int, h: Int) {}

    override fun surfaceDestroyed(sh: SurfaceHolder) {
        running = false
        thread?.join()
        thread = null
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min((now - last) / 1e9f, 0.033f)
            last = now
            if (wantReset) { wantReset = false; newGame() }
            update(dt)
            val c = holder.lockCanvas() ?: continue
            try { render(c) } finally { holder.unlockCanvasAndPost(c) }
            val spent = (System.nanoTime() - now) / 1_000_000
            if (spent < 16) Thread.sleep(16 - spent)
        }
    }

    // ---------- Controles táctiles ----------
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val s = h * 0.24f
        val m = h * 0.05f
        btnL = RectF(m, h - m - s, m + s, h - m)
        btnR = RectF(m * 2 + s, h - m - s, m * 2 + s * 2, h - m)
        btnJ = RectF(w - m - s * 1.3f, h - m - s, w - m.toFloat(), h - m)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && (state == 2 || state == 3)) {
            wantReset = true
            return true
        }
        goL = false; goR = false; goJ = false
        if (e.actionMasked == MotionEvent.ACTION_CANCEL) return true
        val up = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_POINTER_UP
        for (i in 0 until e.pointerCount) {
            if (up && i == e.actionIndex) continue
            val x = e.getX(i)
            val y = e.getY(i)
            if (btnL.contains(x, y)) goL = true
            if (btnR.contains(x, y)) goR = true
            if (btnJ.contains(x, y)) goJ = true
        }
        return true
    }

    // ---------- Dibujo ----------
    private fun box(c: Canvas, l: Float, t: Float, s: Float, fill: Long, line: Long) {
        paint.color = k(line); c.drawRect(l, t, l + s + 1f, t + s + 1f, paint)
        paint.color = k(fill); c.drawRect(l + s * 0.04f, t + s * 0.04f, l + s * 0.96f + 1f, t + s * 0.96f + 1f, paint)
    }

    private fun drawPlayer(c: Canvas, l: Float, t: Float, w: Float, h: Float) {
        val s = if (p.ground && abs(p.vx) > 0.5f) sin(time * 20f) * 0.12f else 0f
        fun r(x1: Float, y1: Float, x2: Float, y2: Float, col: Long) {
            paint.color = k(col)
            c.drawRect(l + x1 * w, t + y1 * h, l + x2 * w, t + y2 * h, paint)
        }
        r(0.1f + s, 0.85f, 0.45f + s, 1f, 0xFF5D4037)
        r(0.55f - s, 0.85f, 0.9f - s, 1f, 0xFF5D4037)
        r(0.15f, 0.5f, 0.85f, 0.87f, 0xFF1E4FE0)
        r(0f, 0.42f, 1f, 0.6f, 0xFFE52521)
        r(0.2f, 0.2f, 0.8f, 0.5f, 0xFFFFCC99)
        r(0.1f, 0f, 0.9f, 0.24f, 0xFFE52521)
        if (face > 0) r(0.55f, 0.14f, 1.1f, 0.26f, 0xFFE52521) else r(-0.1f, 0.14f, 0.45f, 0.26f, 0xFFE52521)
        if (face > 0) r(0.6f, 0.3f, 0.7f, 0.4f, 0xFF000000) else r(0.3f, 0.3f, 0.4f, 0.4f, 0xFF000000)
    }

    private fun render(c: Canvas) {
        val sc = height / H.toFloat()
        val vw = width / sc
        val cam = (p.x - vw * 0.4f).coerceIn(0f, W - vw)
        c.drawColor(k(0xFF5C94FC))
        paint.textAlign = Paint.Align.LEFT
        paint.color = Color.WHITE
        for (i in 0..8) {
            val cx = (i * 14f + 3f - cam * 0.5f) * sc
            val cy = (1.2f + i % 3) * sc
            c.drawOval(cx, cy, cx + 2.4f * sc, cy + 0.9f * sc, paint)
            c.drawOval(cx + 0.5f * sc, cy - 0.4f * sc, cx + 1.8f * sc, cy + 0.6f * sc, paint)
        }

        val x0 = floor(cam).toInt()
        val x1 = min(W - 1, ceil(cam + vw).toInt())
        for (ty in 0 until H) for (tx in x0..x1) {
            val t = map[ty][tx]
            if (t == '.') continue
            val l = (tx - cam) * sc
            val tp = ty * sc
            when (t) {
                '#' -> {
                    box(c, l, tp, sc, 0xFFC84C0C, 0xFF7A2E00)
                    if (ty == 0 || map[ty - 1][tx] != '#') {
                        paint.color = k(0xFF43B047); c.drawRect(l, tp, l + sc + 1f, tp + sc * 0.22f, paint)
                    }
                }
                'B' -> {
                    box(c, l, tp, sc, 0xFFD2691E, 0xFF5A2A00)
                    paint.color = k(0xFF5A2A00); c.drawRect(l, tp + sc * 0.48f, l + sc, tp + sc * 0.52f, paint)
                }
                '?' -> {
                    box(c, l, tp, sc, 0xFFFFB300, 0xFF7A4B00)
                    paint.color = Color.WHITE; paint.textAlign = Paint.Align.CENTER; paint.textSize = sc * 0.75f
                    c.drawText("?", l + sc / 2, tp + sc * 0.75f, paint)
                    paint.textAlign = Paint.Align.LEFT
                }
                'U' -> box(c, l, tp, sc, 0xFF8D6E63, 0xFF4E342E)
                '|' -> {
                    box(c, l, tp, sc, 0xFF2EAA3A, 0xFF0B5E14)
                    paint.color = k(0x55FFFFFF); c.drawRect(l + sc * 0.15f, tp, l + sc * 0.3f, tp + sc, paint)
                }
                'o' -> {
                    val ww = (0.12f + 0.28f * abs(cos(time * 5f + tx))) * sc
                    paint.color = k(0xFFFFD600)
                    c.drawOval(l + sc / 2 - ww, tp + sc * 0.2f, l + sc / 2 + ww, tp + sc * 0.8f, paint)
                }
                'F' -> {
                    paint.color = Color.LTGRAY; c.drawRect(l + sc * 0.45f, tp, l + sc * 0.55f, tp + sc + 1f, paint)
                    if (ty == 2) {
                        paint.color = k(0xFF2EAA3A)
                        c.drawRect(l + sc * 0.55f, tp + sc * 0.1f, l + sc * 1.4f, tp + sc * 0.6f, paint)
                    }
                }
            }
        }

        for (e in enemies) {
            val l = (e.x - cam) * sc
            val tp = e.y * sc
            if (e.dead) {
                paint.color = k(0xFF8B4513)
                c.drawRect(l, tp + e.h * sc * 0.7f, l + e.w * sc, tp + e.h * sc, paint)
            } else {
                val s = sin(time * 10f) * 0.08f * sc
                paint.color = k(0xFF3E2723)
                c.drawRect(l + 0.05f * sc + s, tp + 0.6f * sc, l + 0.35f * sc + s, tp + 0.8f * sc, paint)
                c.drawRect(l + 0.45f * sc - s, tp + 0.6f * sc, l + 0.75f * sc - s, tp + 0.8f * sc, paint)
                paint.color = k(0xFF8B4513)
                c.drawOval(l, tp, l + e.w * sc, tp + 0.68f * sc, paint)
                paint.color = Color.WHITE
                c.drawRect(l + 0.15f * sc, tp + 0.2f * sc, l + 0.33f * sc, tp + 0.4f * sc, paint)
                c.drawRect(l + 0.47f * sc, tp + 0.2f * sc, l + 0.65f * sc, tp + 0.4f * sc, paint)
                paint.color = Color.BLACK
                c.drawRect(l + 0.22f * sc, tp + 0.28f * sc, l + 0.3f * sc, tp + 0.4f * sc, paint)
                c.drawRect(l + 0.5f * sc, tp + 0.28f * sc, l + 0.58f * sc, tp + 0.4f * sc, paint)
            }
        }

        paint.color = k(0xFFFFD600)
        for (o in pops) {
            val cx = (o.x - cam) * sc
            val cy = (o.y - o.t * 2.5f) * sc
            c.drawOval(cx - 0.2f * sc, cy - 0.3f * sc, cx + 0.2f * sc, cy + 0.3f * sc, paint)
        }

        drawPlayer(c, (p.x - cam) * sc, p.y * sc, p.w * sc, p.h * sc)

        // HUD
        paint.textSize = sc * 0.55f
        paint.color = Color.WHITE
        c.drawText("MONEDAS $coins     PUNTOS $score     VIDAS $lives", sc * 0.4f, sc * 0.8f, paint)

        // Botones
        paint.textSize = sc * 0.9f
        paint.textAlign = Paint.Align.CENTER
        for ((b, label, on) in listOf(Triple(btnL, "<", goL), Triple(btnR, ">", goR), Triple(btnJ, "SALTAR", goJ))) {
            paint.color = if (on) k(0x88FFFFFF) else k(0x44000000)
            c.drawRoundRect(b, sc * 0.3f, sc * 0.3f, paint)
            paint.color = Color.WHITE
            paint.textSize = if (label == "SALTAR") sc * 0.55f else sc * 0.9f
            c.drawText(label, b.centerX(), b.centerY() + paint.textSize * 0.35f, paint)
        }

        if (state == 2 || state == 3) {
            paint.color = k(0x99000000); c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            paint.color = Color.WHITE
            paint.textSize = sc * 1.1f
            c.drawText(if (state == 2) "GAME OVER" else "¡NIVEL COMPLETADO!", width / 2f, height * 0.42f, paint)
            paint.textSize = sc * 0.5f
            c.drawText("Puntos: $score   -   Toca para jugar de nuevo", width / 2f, height * 0.58f, paint)
        }
        paint.textAlign = Paint.Align.LEFT
    }
}
