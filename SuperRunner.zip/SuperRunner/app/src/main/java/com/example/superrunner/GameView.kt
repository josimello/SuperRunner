package com.example.superrunner

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.os.Build
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.util.Random
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.*

private open class Body(var x: Float, var y: Float, val w: Float, val h: Float) {
    var vx = 0f; var vy = 0f
    var ground = false; var wall = false
}
/** kind: 0 caminante, 1 pinchudo, 2 murciélago volador, 3 torreta */
private class Enemy(x: Float, y: Float, val kind: Int) : Body(x, y, 0.8f, 0.8f) {
    var dead = false; var t = 0f; var cd = 1.5f; val y0 = y
    val spiky: Boolean get() = kind == 1
    init { vx = when (kind) { 1 -> -2.2f; 2 -> -1.8f; 3 -> 0f; else -> -1.5f } }
}
private class Boss(x: Float, y: Float, var hp: Int) : Body(x, y, 1.8f, 1.8f) { var state = 0; var tm = 2f; var inv = 0f; var dir = -1 }
private class Bullet(var x: Float, var y: Float, val vx: Float) { var life = 4f }
private class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val col: Int)
private class Btn(val r: RectF, val label: String, val sub: String, val act: () -> Unit)

/** NEON DASH. Pantallas: 0 título, 1 menú, 2 niveles, 3 tienda, 4 ajustes, 5 juego. */
class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {
    private val H = 12
    private var W = 100
    private var map = Array(H) { CharArray(W) { '.' } }
    private val enemies = ArrayList<Enemy>()
    private val parts = ArrayList<Part>()
    private val btns = ArrayList<Btn>()
    private val taps = ConcurrentLinkedQueue<PointF>()
    private val p = Body(2f, 8f, 0.8f, 0.95f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rnd = Random()
    private var bL = RectF(); private var bR = RectF(); private var bJ = RectF(); private var bD = RectF()
    @Volatile private var goL = false
    @Volatile private var goR = false
    @Volatile private var goJ = false
    @Volatile private var goD = false
    @Volatile private var running = false
    private var thread: Thread? = null

    private var scr = 0; private var paused = false; private var res = 0
    private var lv = 0; private var hp = 3; private var gems = 0; private var gemTotal = 0; private var lastStars = 0
    private var cpX = 2f; private var cpY = 8f
    private var jumps = 0; private var jPrev = false; private var dPrev = false; private var spr = false
    private var dashT = 0f; private var dashCd = 0f; private var inv = 0f; private var shake = 0f; private var intro = 0f
    private var face = 1; private var time = 0f
    private var confirm = false; private var msg = ""; private var msgT = 0f

    private val sp = ctx.getSharedPreferences("neondash", Context.MODE_PRIVATE)
    private var coins = sp.getInt("coins", 0)
    private var unlocked = sp.getInt("unl", 1)
    private var owned = sp.getInt("own", 1)
    private var skin = sp.getInt("skin", 0)
    private var snd = sp.getBoolean("snd", true)
    private var hap = sp.getBoolean("hap", true)
    private var ctl = sp.getInt("ctl", 1)
    private var dif = sp.getInt("dif", 1)
    private val stars = IntArray(12) { sp.getInt("s$it", 0) }
    private var upHp = sp.getInt("uhp", 0)
    private var upDash = sp.getInt("uda", 0)
    private var upMag = sp.getInt("umg", 0)
    private var lastDay = sp.getLong("day", 0L)
    private var streak = sp.getInt("streak", 0)
    private var lastGift = sp.getInt("glast", 25)
    private var giftState = if (sp.getLong("day", 0L) == System.currentTimeMillis() / 86400000L) sp.getInt("gst", 1) else 0
    private var shopTab = 0
    private var shield = false
    private var wasGround = false
    private var bossMax = 1
    private var boss: Boss? = null
    private val bullets = ArrayList<Bullet>()
    private val HZ = longArrayOf(0xAAFF2BD6, 0xFFFF5722, 0xAA4FC3F7)
    private val AMB = longArrayOf(0x66FF2BD6, 0x99FFD27A, 0xCCFFFFFF)
    private val audio = Audio()
    private var mus = sp.getBoolean("mus", true)
    private var camX = 0f; private var fade = 0f; private var lastScr = 0; private var lastStep = 0f
    private var rx = 0f; private var ry = 0f; private var rT = 0f
    private val ghosts = ArrayList<FloatArray>()
    private val rf = RectF(); private val pr = RectF()
    private val gp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val filters = HashMap<Int, ColorFilter>()
    private var glow: Bitmap? = null
    private val tiles = arrayOfNulls<Bitmap>(3)
    private var tileKey = -1; private var skyKey = -1
    private var skySh: Shader? = null; private var sunGlowSh: Shader? = null; private var sunSh: Shader? = null
    private var vigSh: Shader? = null; private var fogSh: Shader? = null
    private val layerSh = arrayOfNulls<Shader>(3)
    private val PRIMARY = setOf("JUGAR", "CONTINUAR", "SIGUIENTE", "¡RECLAMAR!")

    private val SK_N = arrayOf("CIAN", "FUEGO", "BOSQUE", "ORO", "FANTASMA", "ARCOÍRIS")
    private val SK_P = intArrayOf(0, 60, 120, 220, 350, 500)
    private val SK_C = longArrayOf(0xFF00BCD4, 0xFFFF5722, 0xFF43A047, 0xFFFFC107, 0xB3E0E0FF, 0xFFFFFFFF)
    private val SK_V = longArrayOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFFCCFF90, 0xFF212121, 0xFF7C4DFF, 0xFF111111)
    private val WN = arrayOf("NEÓN", "DESIERTO", "HIELO")
    private val TH = arrayOf(
        longArrayOf(0xFF0B0426, 0xFF3A0F6E, 0xFFFF5BA7, 0xFFFFE08A, 0xFF1E0F4A, 0xFF2B1466, 0xFF3C1B80, 0xFF2A1A52, 0xFF150B30, 0xFF00F0FF, 0xFFFF2BD6),
        longArrayOf(0xFF2B1055, 0xFFE0577F, 0xFFFFB347, 0xFFFFF1B5, 0xFF8E3B5A, 0xFFB5503F, 0xFF7A3328, 0xFFC97B3C, 0xFF8A4A22, 0xFFFFE29A, 0xFFFF7043),
        longArrayOf(0xFF04112B, 0xFF0B3C5D, 0xFF2EC4B6, 0xFFE6FBFF, 0xFF1B4F72, 0xFF2A7FA8, 0xFF8EC5E8, 0xFF5BA3D0, 0xFF2D6A9A, 0xFFEFFBFF, 0xFF7DF9FF)
    )
    private var tg: ToneGenerator? = null

    // ---------- Anuncios recompensados (AdMob). ID de PRUEBA: cámbialo por el tuyo para cobrar ----------
    private val AD_UNIT = "ca-app-pub-3940256099942544/5224354917"
    @Volatile private var rewarded: RewardedAd? = null
    @Volatile private var adLoading = false
    @Volatile private var adReward = false
    @Volatile private var adDone = false
    private var adMode = 0; private var adT = 0f
    private var lvCoins = 0; private var doubled = false
    private var safeX = 2f; private var safeY = 8f

    init {
        holder.addCallback(this)
        paint.typeface = Typeface.DEFAULT_BOLD
        MobileAds.initialize(ctx) { }
        audio.sfxOn = snd; audio.musicOn = mus
    }

    private fun k(v: Long) = v.toInt()
    private fun maxHp() = (when (dif) { 0 -> 5; 1 -> 3; else -> 1 }) + upHp
    private fun upLevel(j: Int) = when (j) { 0 -> upHp; 1 -> upDash; else -> upMag }
    private fun stars3(n: Int) = "★".repeat(n) + "☆".repeat(3 - n)
    private fun skinCol(i: Int): Int =
        if (i == 5) Color.HSVToColor(floatArrayOf((time * 120f) % 360f, 0.8f, 1f)) else k(SK_C[i])

    private fun save() {
        val e = sp.edit()
        e.putInt("coins", coins).putInt("unl", unlocked).putInt("own", owned).putInt("skin", skin)
        e.putBoolean("snd", snd).putBoolean("hap", hap).putInt("ctl", ctl).putInt("dif", dif)
        e.putInt("uhp", upHp).putInt("uda", upDash).putInt("umg", upMag).putLong("day", lastDay).putInt("streak", streak).putInt("gst", giftState).putInt("glast", lastGift).putBoolean("mus", mus)
        for (i in 0 until 12) e.putInt("s$i", stars[i])
        e.apply()
    }

    private fun sfx(id: Int) { audio.play(id) }

    private fun beep(t: Int) {
        sfx(when (t) {
            ToneGenerator.TONE_DTMF_1 -> 0
            ToneGenerator.TONE_DTMF_3 -> 1
            ToneGenerator.TONE_DTMF_9 -> 2
            ToneGenerator.TONE_PROP_BEEP -> 3
            ToneGenerator.TONE_PROP_NACK -> 4
            ToneGenerator.TONE_DTMF_5 -> 6
            ToneGenerator.TONE_DTMF_7 -> 7
            ToneGenerator.TONE_PROP_ACK -> 8
            else -> 9
        })
    }

    private fun earn(n: Int) { coins += n; lvCoins += n }

    private fun loadAd() {
        if (rewarded != null || adLoading) return
        adLoading = true
        post {
            RewardedAd.load(context, AD_UNIT, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewarded = ad; adLoading = false }
                override fun onAdFailedToLoad(error: LoadAdError) { rewarded = null; adLoading = false }
            })
        }
    }

    /** mode 1 = revivir en el sitio, mode 2 = duplicar monedas del nivel, mode 3 = duplicar regalo diario */
    private fun showAd(mode: Int) {
        val ad = rewarded
        if (ad == null) { msg = "Anuncio no disponible aún, prueba en unos segundos"; msgT = 2.5f; adT = 0f; return }
        adMode = mode; adReward = false; adDone = false
        rewarded = null
        post {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() { adDone = true }
                override fun onAdFailedToShowFullScreenContent(error: AdError) { adReward = false; adDone = true }
            }
            ad.show(context as Activity) { adReward = true }
        }
    }

    private fun grant(mode: Int) {
        if (mode == 1 && res == 2) {
            res = 0; hp = maxHp(); p.x = safeX; p.y = safeY - 0.05f; p.vx = 0f; p.vy = 0f; inv = 3f
            sfx(8)
        } else if (mode == 3 && giftState == 1) {
            coins += lastGift; giftState = 2; msg = "¡+$lastGift monedas extra!"; msgT = 2.5f
            sfx(8); save()
        } else if (mode == 2 && res == 1 && !doubled) {
            doubled = true; coins += lvCoins; msg = "¡+$lvCoins monedas!"; msgT = 2f
            sfx(8); save()
        }
    }

    private fun buzz() { if (hap) post { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) } }

    private fun burst(x: Float, y: Float, col: Long, n: Int) {
        repeat(n) { parts.add(Part(x, y, (rnd.nextFloat() - 0.5f) * 6f, (rnd.nextFloat() - 0.8f) * 5f, 0.5f, k(col))) }
    }

    // ---------- Niveles (generados por semilla, cada uno distinto y más difícil) ----------
    private fun put(c: Char, x1: Int, x2: Int, y1: Int, y2: Int) {
        for (y in y1..y2) for (x in x1..x2) if (x in 0 until W && y in 0 until H) map[y][x] = c
    }

    private fun load(l: Int) {
        lv = l
        val r = Random(l * 7919L + 13L)
        val isBoss = l % 4 == 3
        W = if (isBoss) 90 else 110 + l * 12
        map = Array(H) { CharArray(W) { '.' } }
        enemies.clear(); parts.clear(); bullets.clear(); boss = null
        put('#', 0, W - 1, 10, 11)
        var x = 8
        val lim = if (isBoss) W - 36 else W - 16
        val step = lim / 3
        var nextCp = step
        while (x < lim) {
            if (x >= nextCp) { map[9][x] = 'C'; nextCp += step; x += 4; continue }
            when (r.nextInt(10)) {
                0 -> { val g = 2 + r.nextInt(1 + min(2, l / 3)); put('.', x, x + g - 1, 10, 11); put('o', x - 1, x + g, 7, 7); x += g + 4 }
                1 -> { put('P', x + 2, x + 4, 7, 7); put('o', x + 2, x + 4, 6, 6); x += 8 }
                2 -> { val n = 1 + r.nextInt(2); put('^', x, x + n - 1, 9, 9); put('o', x, x + n - 1, 7, 7); x += n + 4 }
                3 -> { enemies.add(Enemy(x.toFloat(), 9.2f, if (l >= 2 && r.nextInt(3) == 0) 1 else 0)); x += 6 }
                4 -> { val hh = 2 + r.nextInt(2); put('#', x, x + 1, 10 - hh, 9); x += 5 }
                5 -> { map[9][x] = '='; put('P', x + 3, x + 6, 4, 4); put('o', x + 3, x + 6, 3, 3); x += 9 }
                6 -> { put('o', x, x + 3, 8, 8); x += 5 }
                7 -> { enemies.add(if (l >= 1) Enemy(x.toFloat(), 7f, 2) else Enemy(x.toFloat(), 9.2f, 0)); x += 7 }
                8 -> { if (l >= 2) enemies.add(Enemy(x.toFloat(), 9.2f, 3)) else put('o', x, x + 3, 8, 8); x += 7 }
                else -> { put('P', x, x + 3, 7, 7); put('o', x + 1, x + 2, 6, 6); x += 6 }
            }
            if (r.nextInt(12) == 0) map[8][x] = if (r.nextBoolean()) 'S' else 'H'
        }
        if (isBoss) {
            put('#', lim + 4, W - 1, 10, 11); put('.', lim + 4, W - 4, 0, 9)
            map[9][lim + 6] = 'C'
            put('#', W - 3, W - 1, 2, 9)
            bossMax = 4 + l / 4
            boss = Boss(W - 16f, 8.2f, bossMax)
        }
        put('G', W - 6, W - 6, 6, 9)
        var n = 0
        for (row in map) for (ch in row) if (ch == 'o') n++
        gemTotal = n
        cpX = 2f; cpY = 8f
    }

    private fun startLevel(i: Int) {
        load(i)
        hp = maxHp(); gems = 0; lvCoins = 0; doubled = false; shield = false; wasGround = false; dashCd = 0f; camX = 0f; res = 0; paused = false; intro = 2.2f; dashT = 0f; scr = 5
        respawn(); inv = 0f
    }

    private fun respawn() { p.x = cpX; p.y = cpY; p.vx = 0f; p.vy = 0f; inv = 1.5f; safeX = cpX; safeY = cpY }

    private fun hurt() {
        if (inv > 0f || res != 0) return
        if (shield) { shield = false; inv = 1.2f; shake = 0.2f; burst(p.x + 0.4f, p.y + 0.5f, 0xFF4DF3FF, 14); beep(ToneGenerator.TONE_PROP_NACK); return }
        hp--; inv = 1.4f; shake = 0.3f; buzz(); beep(ToneGenerator.TONE_PROP_NACK)
        burst(p.x + 0.4f, p.y + 0.5f, 0xFFFF3D00, 12)
        if (hp <= 0) { res = 2; sfx(13); save() } else { p.vy = -9f; p.vx = -face * 5f }
    }

    private fun win() {
        if (res != 0) return
        res = 1
        val st = if (gems >= gemTotal) 3 else if (gems * 10 >= gemTotal * 6) 2 else 1
        if (st > stars[lv]) stars[lv] = st
        lastStars = st
        earn(st * 5)
        unlocked = max(unlocked, min(12, lv + 2))
        sfx(12); save()
    }

    private fun collectGem(tx: Int, ty: Int) {
        map[ty][tx] = '.'; gems++; earn(1)
        burst(tx + 0.5f, ty + 0.5f, 0xFF4DF3FF, 6); beep(ToneGenerator.TONE_PROP_BEEP)
    }

    private fun upgrade(j: Int) {
        val lvl = upLevel(j)
        val cost = 150 * (lvl + 1)
        if (lvl >= 3) { msg = "Mejora al máximo"; msgT = 2f }
        else if (coins >= cost) {
            coins -= cost
            when (j) { 0 -> upHp++; 1 -> upDash++; else -> upMag++ }
            sfx(10)
        } else { sfx(11); msg = "Te faltan ${cost - coins} monedas"; msgT = 2f }
        save()
    }

    private fun gift() {
        val today = System.currentTimeMillis() / 86400000L
        if (giftState == 0) {
            streak = if (lastDay == today - 1) min(streak + 1, 6) else 0
            lastGift = 25 + 15 * streak
            coins += lastGift; lastDay = today; giftState = 1
            msg = "¡+$lastGift monedas! Racha: ${streak + 1} día(s)"; msgT = 2.5f
            beep(ToneGenerator.TONE_PROP_ACK); save()
        } else if (giftState == 1) showAd(3)
    }

    private fun buy(j: Int) {
        if ((owned and (1 shl j)) != 0) { skin = j; sfx(9) }
        else if (coins >= SK_P[j]) { coins -= SK_P[j]; owned = owned or (1 shl j); skin = j; sfx(10) }
        else { sfx(11); msg = "Te faltan ${SK_P[j] - coins} monedas"; msgT = 2f }
        save()
    }

    // ---------- Física ----------
    private fun hit(b: Body): Boolean {
        for (ty in floor(b.y).toInt()..floor(b.y + b.h - 0.0001f).toInt())
            for (tx in floor(b.x).toInt()..floor(b.x + b.w - 0.0001f).toInt()) {
                if (tx < 0 || tx >= W) return true
                if (ty in 0 until H && map[ty][tx] == '#') return true
            }
        return false
    }

    private fun move(b: Body, dt: Float) {
        b.vy = min(b.vy + 40f * dt, 20f)
        b.x += b.vx * dt
        b.wall = false
        if (hit(b)) { b.wall = true; b.x = if (b.vx > 0) floor(b.x + b.w - 0.0001f) - b.w else floor(b.x) + 1f }
        val before = b.y + b.h
        b.y += b.vy * dt
        b.ground = false
        if (hit(b)) {
            if (b.vy > 0) { b.y = floor(b.y + b.h - 0.0001f) - b.h; b.ground = true } else b.y = floor(b.y) + 1f
            b.vy = 0f
        } else if (b.vy > 0f) {
            val ty = floor(b.y + b.h).toInt()
            if (ty in 0 until H && before <= ty + 0.05f) {
                for (tx in floor(b.x).toInt()..floor(b.x + b.w - 0.0001f).toInt())
                    if (tx in 0 until W && map[ty][tx] == 'P') { b.y = ty - b.h; b.ground = true; b.vy = 0f; break }
            }
        }
    }

    private fun overlap(a: Body, b: Body) = a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y

    private fun update(dt: Float) {
        time += dt
        while (true) { val t = taps.poll() ?: break; tap(t.x, t.y) }
        layout()
        if (adDone) { adDone = false; if (adReward) grant(adMode); adMode = 0; adReward = false }
        adT -= dt
        if (adT <= 0f) { adT = 15f; loadAd() }
        for (q in parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.vy += 12f * dt; q.life -= dt }
        parts.removeAll { it.life <= 0f }
        if (shake > 0f) shake -= dt
        if (msgT > 0f) msgT -= dt
        if (scr != lastScr) { fade = 1f; lastScr = scr }
        if (fade > 0f) fade -= dt * 3f
        if (rT > 0f) rT -= dt * 2.5f
        for (g in ghosts) g[2] -= dt
        ghosts.removeAll { it[2] <= 0f }
        audio.music(if (scr != 5) 0 else if (boss != null && p.x > W - 40f) 4 else 1 + lv / 4)
        audio.setVol(if (scr == 5 && !paused && res == 0) 1f else 0.45f)
        if (scr != 5 || paused || res != 0) return

        intro -= dt; inv -= dt; dashCd -= dt
        val vw = width / (height / H.toFloat())
        camX += ((p.x + face * 1.5f - vw * 0.4f).coerceIn(0f, W - vw) - camX) * min(1f, 6f * dt)
        val dir = (if (goR) 1 else 0) - (if (goL) 1 else 0)
        if (dir != 0) face = dir
        if (dashT > 0f) {
            dashT -= dt; p.vx = face * 14f; p.vy = 0f
            burst(p.x + p.w / 2, p.y + p.h / 2, 0xFF4DF3FF, 1); ghosts.add(floatArrayOf(p.x, p.y, 0.25f))
        } else p.vx += (dir * 6.2f - p.vx) * min(1f, 12f * dt)
        if (goJ && !jPrev) {
            if (p.ground) { p.vy = -16f; jumps = 1; beep(ToneGenerator.TONE_DTMF_1) }
            else if (jumps < 2) { p.vy = -14f; jumps = 2; beep(ToneGenerator.TONE_DTMF_3); burst(p.x + p.w / 2, p.y + p.h, 0xFFFFFFFF, 6) }
        }
        jPrev = goJ
        if (p.vy >= 0f) spr = false
        if (!goJ && !spr && p.vy < -5f && dashT <= 0f) p.vy = -5f
        if (goD && !dPrev && dashCd <= 0f && dashT <= 0f) { dashT = 0.18f; dashCd = 0.9f - 0.15f * upDash; beep(ToneGenerator.TONE_DTMF_9); buzz() }
        dPrev = goD
        move(p, dt)
        if (p.ground) { jumps = 0; safeX = p.x; safeY = p.y }
        if (p.ground && !wasGround) { burst(p.x + 0.4f, p.y + p.h, 0x88FFFFFF, 4); sfx(15) }
        if (p.ground && abs(p.vx) > 3f && time - lastStep > 0.27f) { lastStep = time; sfx(16) }
        wasGround = p.ground
        if (upMag > 0) {
            val rr = 1.2f + upMag
            for (ty in max(0, floor(p.y - rr).toInt())..min(H - 1, floor(p.y + rr).toInt()))
                for (tx in max(0, floor(p.x - rr).toInt())..min(W - 1, floor(p.x + rr).toInt()))
                    if (map[ty][tx] == 'o' && hypot(tx + 0.5f - p.x - 0.4f, ty + 0.5f - p.y - 0.5f) < rr) collectGem(tx, ty)
        }

        for (ty in floor(p.y).toInt()..floor(p.y + p.h - 0.0001f).toInt())
            for (tx in floor(p.x).toInt()..floor(p.x + p.w - 0.0001f).toInt()) {
                if (tx !in 0 until W || ty !in 0 until H) continue
                when (map[ty][tx]) {
                    'o' -> collectGem(tx, ty)
                    'S' -> { map[ty][tx] = '.'; shield = true; burst(tx + 0.5f, ty + 0.5f, 0xFF4DF3FF, 10); beep(ToneGenerator.TONE_PROP_ACK) }
                    'H' -> if (hp < maxHp()) { map[ty][tx] = '.'; hp++; burst(tx + 0.5f, ty + 0.5f, 0xFFFF5252, 10); beep(ToneGenerator.TONE_PROP_ACK) }
                    'C' -> if (cpX != tx.toFloat()) { cpX = tx.toFloat(); cpY = 8f; sfx(14) }
                    'G' -> if (boss == null) win() else { msg = "¡Derrota al jefe primero!"; msgT = 1.5f }
                    '=' -> if (p.vy >= 0f) { p.vy = -23f; jumps = 1; spr = true; beep(ToneGenerator.TONE_DTMF_5) }
                    '^' -> if (p.y + p.h > ty + 0.5f) hurt()
                }
            }

        for (e in enemies) {
            if (e.dead) { e.t += dt; continue }
            if (abs(e.x - p.x) > 18f) continue
            when (e.kind) {
                2 -> {
                    if (abs(e.x - p.x) < 10f) e.vx = sign(p.x - e.x) * 1.8f
                    e.x += e.vx * dt; e.y = e.y0 + sin(time * 3f + e.x) * 1.2f
                }
                3 -> {
                    e.cd -= dt
                    if (e.cd <= 0f && e.x > p.x && e.x - p.x < 14f) { e.cd = 2.2f; bullets.add(Bullet(e.x, e.y + 0.25f, -6f)); beep(ToneGenerator.TONE_DTMF_7) }
                }
                else -> { move(e, dt); if (e.wall) e.vx = -e.vx }
            }
            if (e.y > 14f) { e.dead = true; e.t = 9f; continue }
            if (res == 0 && overlap(p, e)) {
                if (dashT > 0f || (p.vy > 0f && !e.spiky && p.y + p.h < e.y + 0.6f)) {
                    e.dead = true; earn(2)
                    burst(e.x + 0.4f, e.y + 0.4f, 0xFFFF5C8A, 10); sfx(5)
                    if (dashT <= 0f) { p.vy = -10f; jumps = 1; spr = true }
                } else hurt()
            }
        }
        enemies.removeAll { it.dead && it.t > 0.4f }
        for (b in bullets) {
            b.x += b.vx * dt; b.life -= dt
            val bx = floor(b.x).toInt(); val by = floor(b.y).toInt()
            if (bx < 0 || bx >= W || (by in 0 until H && map[by][bx] == '#')) b.life = 0f
            else if (res == 0 && b.x < p.x + p.w && b.x + 0.45f > p.x && b.y < p.y + p.h && b.y + 0.3f > p.y) {
                b.life = 0f
                if (dashT <= 0f) hurt() else burst(b.x, b.y, 0xFFFFAB40, 6)
            }
        }
        bullets.removeAll { it.life <= 0f }
        boss?.let { bs ->
            bs.inv -= dt; bs.tm -= dt
            when (bs.state) {
                0 -> { bs.vx = sign(p.x - bs.x) * 2f; if (bs.tm <= 0f) { bs.state = 1; bs.tm = 0.8f; bs.vx = 0f; sfx(18) } }
                1 -> { bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 2; bs.tm = 1.1f; bs.dir = if (p.x < bs.x) -1 else 1; bs.vy = -13f } }
                2 -> { bs.vx = bs.dir * 9f; if (bs.tm <= 0f || bs.wall) { bs.state = 3; bs.tm = 1.6f; bs.vx = 0f; shake = 0.25f } }
                else -> { bs.vx = 0f; if (bs.tm <= 0f) { bs.state = 0; bs.tm = 2.5f } }
            }
            move(bs, dt)
            bs.x = bs.x.coerceIn(W - 30f, W - 6.8f)
            if (res == 0 && overlap(p, bs)) {
                val stomp = p.vy > 0f && p.y + p.h < bs.y + 0.7f
                if ((stomp || dashT > 0f) && bs.inv <= 0f) {
                    bs.hp--; bs.inv = 1.2f; bs.state = 3; bs.tm = 1.6f; bs.vx = 0f
                    p.vy = -12f; jumps = 1; spr = true; shake = 0.3f; buzz()
                    burst(bs.x + 0.9f, bs.y + 0.9f, 0xFFFFD740, 16); sfx(17)
                    if (bs.hp <= 0) { boss = null; earn(25); burst(bs.x + 0.9f, bs.y + 0.9f, 0xFFFF5C8A, 30); beep(ToneGenerator.TONE_PROP_ACK) }
                } else if (bs.state != 3) hurt()
            }
        }
        if (res == 0 && p.y > 13f) {
            hp--; buzz()
            if (hp <= 0) { res = 2; sfx(13); save() } else respawn()
        }
    }

    // ---------- Interfaz ----------
    private fun addBtn(cx: Float, cy: Float, w: Float, h: Float, label: String, sub: String = "", act: () -> Unit) {
        btns.add(Btn(RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), label, sub, act))
    }

    private fun controls() {
        val w = width.toFloat(); val h = height.toFloat()
        val s = h * (0.2f + 0.04f * ctl); val m = h * 0.04f
        bL = RectF(m, h - m - s, m + s, h - m)
        bR = RectF(m * 2 + s, h - m - s, m * 2 + s * 2, h - m)
        bJ = RectF(w - m - s * 1.2f, h - m - s * 1.2f, w - m, h - m)
        bD = RectF(w - m * 2 - s * 2.1f, h - m - s * 0.9f, w - m * 2 - s * 1.2f, h - m)
    }

    private fun layout() {
        btns.clear()
        val w = width.toFloat(); val h = height.toFloat()
        val bw = h * 1.1f; val bh = h * 0.12f
        val back = { addBtn(w * 0.14f, h * 0.9f, h * 0.45f, h * 0.11f, "ATRÁS") { scr = 1; confirm = false } }
        when (scr) {
            1 -> {
                val b2 = h * 0.1f
                addBtn(w / 2, h * 0.32f, bw, h * 0.115f, "REGALO DIARIO", when (giftState) { 0 -> "¡RECLAMAR!"; 1 -> "DUPLICAR: VER ANUNCIO"; else -> "VUELVE MAÑANA" }) { gift() }
                addBtn(w / 2, h * 0.46f, bw, b2, "JUGAR") { scr = 2 }
                addBtn(w / 2, h * 0.59f, bw, b2, "TIENDA") { scr = 3 }
                addBtn(w / 2, h * 0.72f, bw, b2, "AJUSTES") { scr = 4 }
                addBtn(w / 2, h * 0.85f, bw, b2, "SALIR") { post { (context as Activity).finish() } }
            }
            2 -> {
                for (i in 0 until 12) {
                    val cx = w * 0.36f + (i % 4) * h * 0.28f
                    val cy = h * 0.30f + (i / 4) * h * 0.22f
                    addBtn(cx, cy, h * 0.25f, h * 0.19f, "${i + 1}", if (i < unlocked) stars3(stars[i]) else "BLOQ.") { if (i < unlocked) startLevel(i) }
                }
                back()
            }
            3 -> {
                val gap = min(h * 0.7f, w * 0.31f); val cw = min(h * 0.66f, w * 0.29f)
                if (shopTab == 0) for (j in 0 until 6) {
                    val cx = w / 2 + (j % 3 - 1) * gap
                    val cy = h * 0.30f + (j / 3) * h * 0.36f
                    addBtn(cx, cy, cw, h * 0.33f, "") { buy(j) }
                } else for (j in 0 until 3) addBtn(w / 2 + (j - 1) * gap, h * 0.5f, cw, h * 0.5f, "") { upgrade(j) }
                back()
                addBtn(w * 0.84f, h * 0.9f, h * 0.55f, h * 0.11f, if (shopTab == 0) "MEJORAS" else "SKINS") { shopTab = 1 - shopTab }
            }
            4 -> {
                val sw = h * 1.4f; val sh = h * 0.09f
                addBtn(w / 2, h * 0.2f, sw, sh, "SONIDO: " + (if (snd) "SÍ" else "NO")) { snd = !snd; audio.sfxOn = snd; save() }
                addBtn(w / 2, h * 0.31f, sw, sh, "MÚSICA: " + (if (mus) "SÍ" else "NO")) { mus = !mus; audio.enableMusic(mus); save() }
                addBtn(w / 2, h * 0.42f, sw, sh, "VIBRACIÓN: " + (if (hap) "SÍ" else "NO")) { hap = !hap; save() }
                addBtn(w / 2, h * 0.53f, sw, sh, "CONTROLES: " + arrayOf("PEQUEÑOS", "MEDIANOS", "GRANDES")[ctl]) { ctl = (ctl + 1) % 3; save(); controls() }
                addBtn(w / 2, h * 0.64f, sw, sh, "DIFICULTAD: " + arrayOf("FÁCIL", "NORMAL", "DIFÍCIL")[dif]) { dif = (dif + 1) % 3; save() }
                addBtn(w / 2, h * 0.75f, sw, sh, if (confirm) "¿SEGURO? TOCA OTRA VEZ" else "BORRAR PROGRESO") {
                    if (confirm) { coins = 0; unlocked = 1; owned = 1; skin = 0; stars.fill(0); upHp = 0; upDash = 0; upMag = 0; confirm = false; save() } else confirm = true
                }
                back()
            }
            5 -> {
                if (res == 0 && !paused) addBtn(w - h * 0.08f, h * 0.09f, h * 0.1f, h * 0.1f, "II") { paused = true }
                else if (res == 0) {
                    addBtn(w / 2, h * 0.45f, bw, bh, "CONTINUAR") { paused = false }
                    addBtn(w / 2, h * 0.60f, bw, bh, "REINICIAR") { startLevel(lv) }
                    addBtn(w / 2, h * 0.75f, bw, bh, "NIVELES") { scr = 2; save() }
                } else if (res == 1) {
                    if (!doubled) addBtn(w / 2, h * 0.47f, bw, h * 0.14f, "DUPLICAR MONEDAS", "VER ANUNCIO  (+$lvCoins)") { showAd(2) }
                    var y = 0.61f
                    if (lv < 11) { addBtn(w / 2, h * y, bw, bh, "SIGUIENTE") { startLevel(lv + 1) }; y += 0.14f }
                    addBtn(w / 2, h * y, bw, bh, "REINTENTAR") { startLevel(lv) }
                    addBtn(w / 2, h * (y + 0.14f), bw, bh, "NIVELES") { scr = 2 }
                } else {
                    addBtn(w / 2, h * 0.50f, bw, h * 0.15f, "REVIVIR AQUÍ", "VER ANUNCIO") { showAd(1) }
                    addBtn(w / 2, h * 0.68f, bw, bh, "REINTENTAR") { startLevel(lv) }
                    addBtn(w / 2, h * 0.83f, bw, bh, "NIVELES") { scr = 2 }
                }
            }
        }
    }

    private fun tap(x: Float, y: Float) {
        if (scr == 0) { scr = 1; sfx(9); rx = x; ry = y; rT = 1f; return }
        rx = x; ry = y; rT = 1f
        for (b in btns) if (b.r.contains(x, y)) { sfx(9); b.act(); buzz(); return }
    }

    // ---------- Bucle y ciclo de vida ----------
    override fun surfaceCreated(sh: SurfaceHolder) { running = true; audio.resume(); thread = Thread(this).also { it.start() } }
    override fun surfaceChanged(sh: SurfaceHolder, f: Int, w: Int, h: Int) {}
    override fun surfaceDestroyed(sh: SurfaceHolder) {
        running = false; thread?.join(); thread = null
        audio.pause()
        if (scr == 5 && res == 0) paused = true
        save()
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min((now - last) / 1e9f, 0.033f)
            last = now
            update(dt)
            val c = (try { if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas() } catch (e: Exception) { holder.lockCanvas() }) ?: continue
            try { render(c) } finally { holder.unlockCanvasAndPost(c) }
            val spent = (System.nanoTime() - now) / 1_000_000
            if (spent < 16) Thread.sleep(16 - spent)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); controls() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) taps.add(PointF(e.getX(e.actionIndex), e.getY(e.actionIndex)))
        goL = false; goR = false; goJ = false; goD = false
        if (a == MotionEvent.ACTION_CANCEL) return true
        val up = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP
        for (i in 0 until e.pointerCount) {
            if (up && i == e.actionIndex) continue
            val x = e.getX(i); val y = e.getY(i)
            if (bL.contains(x, y)) goL = true
            if (bR.contains(x, y)) goR = true
            if (bJ.contains(x, y)) goJ = true
            if (bD.contains(x, y)) goD = true
        }
        return true
    }

    // ---------- Dibujo ----------
    private fun ca(col: Int, a: Float) = (col and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24)

    private fun lerpCol(a: Int, b: Int, t: Float): Int = Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * t).toInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Long, al: Paint.Align = Paint.Align.CENTER) {
        paint.style = Paint.Style.FILL; paint.shader = null; paint.textSize = size; paint.textAlign = al
        paint.color = k(0x99000000); c.drawText(s, x + size * 0.04f, y + size * 0.06f, paint)
        paint.color = k(col); c.drawText(s, x, y, paint)
    }

    private fun title(c: Canvas, s: String, x: Float, y: Float, size: Float) {
        glowAt(c, x, y - size * 0.3f, size * 3.2f, k(0xFFFF2BD6), 0.22f)
        paint.style = Paint.Style.FILL; paint.shader = null; paint.textSize = size; paint.textAlign = Paint.Align.CENTER
        paint.color = k(0xFF0B0F1A); c.drawText(s, x + size * 0.06f, y + size * 0.08f, paint)
        paint.color = k(0xFFFF2BD6); c.drawText(s, x + size * 0.03f, y + size * 0.04f, paint)
        paint.shader = LinearGradient(0f, y - size * 0.8f, 0f, y, k(0xFFFFFFFF), k(0xFF7DF9FF), Shader.TileMode.CLAMP)
        c.drawText(s, x, y, paint); paint.shader = null
    }

    private fun glowAt(c: Canvas, cx: Float, cy: Float, r: Float, col: Int, a: Float) {
        val g = glow ?: return
        gp.colorFilter = filters.getOrPut(col) { PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN) }
        gp.alpha = (a * 255f).toInt().coerceIn(0, 255)
        rf.set(cx - r, cy - r, cx + r, cy + r)
        c.drawBitmap(g, null, rf, gp)
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float, col: Int) {
        path.reset()
        path.moveTo(cx, cy + s * 0.9f)
        path.cubicTo(cx - s * 1.3f, cy + s * 0.1f, cx - s * 0.8f, cy - s * 0.9f, cx, cy - s * 0.35f)
        path.cubicTo(cx + s * 0.8f, cy - s * 0.9f, cx + s * 1.3f, cy + s * 0.1f, cx, cy + s * 0.9f)
        path.close()
        paint.style = Paint.Style.FILL; paint.shader = null; paint.color = col; c.drawPath(path, paint)
        paint.color = k(0x55FFFFFF); c.drawCircle(cx - s * 0.4f, cy - s * 0.15f, s * 0.16f, paint)
    }

    private fun star(c: Canvas, cx: Float, cy: Float, r: Float, col: Int) {
        path.reset()
        for (i in 0 until 10) {
            val a = (-90 + i * 36) * 0.0174533f
            val rr = if (i % 2 == 0) r else r * 0.45f
            val px = cx + cos(a) * rr; val py = cy + sin(a) * rr
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close(); paint.style = Paint.Style.FILL; paint.shader = null; paint.color = col; c.drawPath(path, paint)
    }

    private fun gem(c: Canvas, cx: Float, cy: Float, s: Float, ws: Float) {
        val ww = s * 0.8f * ws
        paint.style = Paint.Style.FILL; paint.shader = null
        path.reset(); path.moveTo(cx, cy - s); path.lineTo(cx - ww, cy - s * 0.15f); path.lineTo(cx, cy + s); path.close()
        paint.color = k(0xFF7DF9FF); c.drawPath(path, paint)
        path.reset(); path.moveTo(cx, cy - s); path.lineTo(cx + ww, cy - s * 0.15f); path.lineTo(cx, cy + s); path.close()
        paint.color = k(0xFF00B8D4); c.drawPath(path, paint)
        paint.color = k(0xAAFFFFFF); c.drawCircle(cx - ww * 0.25f, cy - s * 0.35f, s * 0.12f, paint)
    }

    private fun bolt(c: Canvas, cx: Float, cy: Float, q: Float, col: Int) {
        path.reset()
        path.moveTo(cx + q * 0.2f, cy - q * 1.1f); path.lineTo(cx - q * 0.7f, cy + q * 0.15f); path.lineTo(cx - q * 0.05f, cy + q * 0.15f)
        path.lineTo(cx - q * 0.3f, cy + q * 1.1f); path.lineTo(cx + q * 0.7f, cy - q * 0.2f); path.lineTo(cx + q * 0.05f, cy - q * 0.2f)
        path.close(); paint.style = Paint.Style.FILL; paint.shader = null; paint.color = col; c.drawPath(path, paint)
    }

    private fun coinIcon(c: Canvas, cx: Float, cy: Float, r: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(cx, cy - r, cx, cy + r, k(0xFFFFE57F), k(0xFFFFA000), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, paint); paint.shader = null
        paint.color = k(0xFFFFCA28); c.drawCircle(cx, cy, r * 0.68f, paint)
        paint.color = k(0xFFFFE082); c.drawRect(cx - r * 0.12f, cy - r * 0.4f, cx + r * 0.12f, cy + r * 0.4f, paint)
    }

    private fun glass(c: Canvas, r: RectF, accent: Int, hi: Boolean) {
        val rad = r.height() * 0.14f
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(0x66000000); c.drawRoundRect(r.left, r.top + r.height() * 0.04f, r.right, r.bottom + r.height() * 0.04f, rad, rad, paint)
        paint.shader = LinearGradient(0f, r.top, 0f, r.bottom, k(0xDD2A1658), k(0xDD150A33), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, paint); paint.shader = null
        paint.style = Paint.Style.STROKE; paint.strokeWidth = max(2f, r.height() * 0.015f)
        paint.color = if (hi) accent else k(0x44FFFFFF)
        c.drawRoundRect(r, rad, rad, paint); paint.style = Paint.Style.FILL
    }

    private fun chip(c: Canvas, cx: Float, cy: Float, hgt: Float, col: Int, text: String) {
        paint.style = Paint.Style.FILL; paint.shader = null; paint.textSize = hgt * 0.6f; paint.textAlign = Paint.Align.CENTER
        val tw = paint.measureText(text)
        rf.set(cx - tw / 2 - hgt * 0.5f, cy - hgt / 2, cx + tw / 2 + hgt * 0.5f, cy + hgt / 2)
        paint.color = col; c.drawRoundRect(rf, hgt / 2, hgt / 2, paint)
        paint.color = k(0x33FFFFFF); c.drawRoundRect(rf.left, rf.top, rf.right, rf.centerY(), hgt / 2, hgt / 2, paint)
        txt(c, text, cx, cy + hgt * 0.21f, hgt * 0.6f, 0xFFFFFFFF)
    }

    /** Cuerpo redondeado con contorno, sombreado inferior y brillo. */
    private fun blob(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, base: Int) {
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(0xFF0B0F1A); c.drawRoundRect(l - rad * 0.12f, t - rad * 0.12f, r + rad * 0.12f, b + rad * 0.12f, rad, rad, paint)
        paint.color = base; c.drawRoundRect(l, t, r, b, rad, rad, paint)
        c.save(); c.clipRect(l - 2f, t + (b - t) * 0.55f, r + 2f, b + 2f)
        paint.color = k(0x38000000); c.drawRoundRect(l, t, r, b, rad, rad, paint)
        c.restore()
        paint.color = k(0x44FFFFFF); c.drawOval(l + (r - l) * 0.14f, t + (b - t) * 0.1f, l + (r - l) * 0.5f, t + (b - t) * 0.32f, paint)
    }

    private fun prop(c: Canvas, th: Int, x: Float, y: Float, sc: Float, v: Int) {
        paint.style = Paint.Style.FILL; paint.shader = null
        when (th) {
            0 -> {
                paint.color = k(0xFF1A1033); c.drawRect(x - sc * 0.05f, y - sc * 1.7f, x + sc * 0.05f, y, paint)
                c.drawRect(x - sc * 0.05f, y - sc * 1.7f, x + sc * 0.5f, y - sc * 1.6f, paint)
                glowAt(c, x + sc * 0.45f, y - sc * 1.55f, sc * 0.9f, k(if (v % 2 == 0) 0xFFFF2BD6 else 0xFF00F0FF), 0.8f)
                paint.color = Color.WHITE; c.drawCircle(x + sc * 0.45f, y - sc * 1.55f, sc * 0.07f, paint)
            }
            1 -> {
                paint.color = k(0xFF2E7D32)
                c.drawRoundRect(x - sc * 0.14f, y - sc * 1.2f, x + sc * 0.14f, y, sc * 0.14f, sc * 0.14f, paint)
                c.drawRoundRect(x - sc * 0.5f, y - sc * 0.9f, x - sc * 0.22f, y - sc * 0.45f, sc * 0.12f, sc * 0.12f, paint)
                c.drawRoundRect(x + sc * 0.22f, y - sc * 0.8f, x + sc * 0.5f, y - sc * 0.4f, sc * 0.12f, sc * 0.12f, paint)
                c.drawRect(x - sc * 0.5f, y - sc * 0.55f, x + sc * 0.5f, y - sc * 0.4f, paint)
                paint.color = k(0x33FFFFFF); c.drawRect(x - sc * 0.08f, y - sc * 1.15f, x - sc * 0.02f, y - sc * 0.05f, paint)
            }
            else -> {
                paint.color = k(0xFF3E2723); c.drawRect(x - sc * 0.07f, y - sc * 0.35f, x + sc * 0.07f, y, paint)
                for (i in 0..2) {
                    path.reset()
                    path.moveTo(x - sc * (0.55f - i * 0.12f), y - sc * (0.3f + i * 0.45f)); path.lineTo(x, y - sc * (1.0f + i * 0.45f))
                    path.lineTo(x + sc * (0.55f - i * 0.12f), y - sc * (0.3f + i * 0.45f)); path.close()
                    paint.color = k(0xFF1B5E4F); c.drawPath(path, paint)
                    paint.color = k(0xFFEFFBFF); c.drawRect(x - sc * 0.12f, y - sc * (0.95f + i * 0.45f), x + sc * 0.12f, y - sc * (0.8f + i * 0.45f), paint)
                }
            }
        }
    }

    private fun mkTiles(th: Int, s: Int) {
        val T = TH[th]; val fs = s.toFloat(); val rr = Random(th * 31L + 7)
        val p2 = Paint(Paint.ANTI_ALIAS_FLAG)
        for (n in 0..2) {
            val h2 = if (n == 2) max(8, (s * 0.42f).toInt()) else s
            val b = Bitmap.createBitmap(s, h2, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b); val hf = h2.toFloat()
            val rad = if (n == 2) hf * 0.3f else 0f
            p2.shader = LinearGradient(0f, 0f, 0f, hf, k(T[7]), k(T[8]), Shader.TileMode.CLAMP)
            cv.drawRoundRect(0f, 0f, fs, hf, rad, rad, p2)
            p2.shader = null
            if (n != 2) for (i in 0 until s / 4) {
                p2.color = if (rr.nextBoolean()) 0x22FFFFFF else 0x22000000
                cv.drawCircle(rr.nextFloat() * fs, rr.nextFloat() * fs, fs * (0.02f + rr.nextFloat() * 0.04f), p2)
            }
            p2.color = 0x33FFFFFF; cv.drawRect(0f, 0f, fs, hf * 0.05f, p2)
            p2.color = 0x44000000; cv.drawRect(0f, hf * 0.94f, fs, hf, p2); cv.drawRect(fs * 0.96f, 0f, fs, hf, p2)
            if (n >= 1) {
                val cap = if (n == 2) hf * 0.38f else fs * (if (th == 0) 0.1f else 0.2f)
                p2.color = k(T[9]); cv.drawRect(0f, 0f, fs, cap, p2)
                if (th == 0) {
                    p2.shader = LinearGradient(0f, cap, 0f, cap + fs * 0.3f, ca(k(T[9]), 0.45f), ca(k(T[9]), 0f), Shader.TileMode.CLAMP)
                    cv.drawRect(0f, cap, fs, cap + fs * 0.3f, p2); p2.shader = null
                } else for (i in 0..3) { p2.color = k(T[9]); cv.drawCircle(fs * (0.12f + i * 0.25f), cap, fs * (0.08f + 0.04f * (i % 2)), p2) }
            }
            tiles[n] = b
        }
    }

    private fun prepare(w: Float, h: Float, th: Int) {
        if (glow == null) {
            val b = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
            val p2 = Paint(Paint.ANTI_ALIAS_FLAG)
            p2.shader = RadialGradient(32f, 32f, 32f, intArrayOf(Color.WHITE, 0x66FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
            Canvas(b).drawCircle(32f, 32f, 32f, p2)
            glow = b
        }
        val s = max(16, (h / H).toInt())
        if (tileKey != th * 10000 + s) { mkTiles(th, s); tileKey = th * 10000 + s }
        val key = th * 100000 + (w + h).toInt()
        if (skyKey != key) {
            val T = TH[th]
            val gy = (10f - 2.4f) * (h / H)
            skySh = LinearGradient(0f, 0f, 0f, h * 0.8f, intArrayOf(k(T[0]), k(T[1]), k(T[2])), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            sunGlowSh = RadialGradient(w * 0.74f, h * 0.3f, h * 0.55f, intArrayOf(ca(k(T[3]), 0.55f), ca(k(T[3]), 0f)), null, Shader.TileMode.CLAMP)
            sunSh = LinearGradient(0f, h * 0.18f, 0f, h * 0.42f, k(T[3]), k(T[10]), Shader.TileMode.CLAMP)
            vigSh = RadialGradient(w / 2, h / 2, h * 1.15f, intArrayOf(0x00000000, 0x00000000, 0xAA000000.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            fogSh = LinearGradient(0f, gy - h * 0.2f, 0f, gy, ca(k(T[2]), 0f), ca(k(T[2]), 0.55f), Shader.TileMode.CLAMP)
            for (i in 0..2) layerSh[i] = LinearGradient(0f, gy - h * (0.5f - i * 0.12f), 0f, gy, k(T[4 + i]), lerpCol(k(T[4 + i]), k(T[2]), 0.55f), Shader.TileMode.CLAMP)
            skyKey = key
        }
    }

    private fun renderWorld(c: Canvas, w: Float, h: Float, th: Int, cam: Float, sc: Float) {
        paint.style = Paint.Style.FILL
        paint.shader = skySh; c.drawRect(0f, 0f, w, h, paint); paint.shader = null
        if (th != 1) for (i in 0 until 50) {
            val sx = ((i * 7919) % 1000) / 1000f * w; val sy = ((i * 104729) % 1000) / 1000f * h * 0.5f
            paint.color = ca(Color.WHITE, 0.3f + 0.5f * (0.5f + 0.5f * sin(time * 2f + i)))
            c.drawCircle(sx, sy, h * (0.002f + (i % 3) * 0.0015f), paint)
        }
        paint.shader = sunGlowSh; c.drawCircle(w * 0.74f, h * 0.3f, h * 0.55f, paint)
        paint.shader = sunSh; c.drawCircle(w * 0.74f, h * 0.3f, h * 0.12f, paint); paint.shader = null
        if (th == 2) for (b in 0..1) {
            path.reset(); path.moveTo(0f, h * 0.3f)
            var x = 0f
            while (x <= w + 30f) { path.lineTo(x, h * (0.16f + 0.05f * b) + sin(x / 170f + time * 0.5f + b * 2f) * h * 0.05f); x += 30f }
            x = w
            while (x >= -30f) { path.lineTo(x, h * (0.30f + 0.05f * b) + sin(x / 170f + time * 0.5f + b * 2f) * h * 0.05f); x -= 30f }
            path.close()
            paint.color = ca(k(if (b == 0) 0xFF2EC4B6 else 0xFF7C4DFF), 0.22f); c.drawPath(path, paint)
        }
        val gy = (10f - 2.4f) * sc
        for (i in 0..2) {
            val off = cam * sc * (0.12f + i * 0.14f)
            val amp = h * (0.30f - i * 0.07f)
            paint.shader = layerSh[i]
            path.reset(); path.moveTo(0f, gy + sc * 3f)
            var x = 0f
            while (x <= w + 24f) {
                val wx = (x + off) / sc
                val y = when (th) {
                    0 -> { val bwid = 1.8f + i * 0.7f; val bi = floor(wx / bwid).toInt(); gy - amp * (0.3f + 0.12f * ((bi * 37 + i * 11) % 7)) }
                    1 -> gy - amp * 0.45f - amp * 0.3f * sin(wx / (4f + i * 2f) + i * 1.7f) - amp * 0.15f * sin(wx / (1.7f + i) + i)
                    else -> gy - amp * 0.4f - amp * 0.45f * abs(sin(wx / (3.5f + i * 1.5f) + i * 2.1f))
                }
                path.lineTo(x, y); x += if (th == 0) 6f else 18f
            }
            path.lineTo(w, gy + sc * 3f); path.close()
            c.drawPath(path, paint)
        }
        paint.shader = null
        if (th == 0) {
            val i = 2; val bwid = 1.8f + i * 0.7f; val off = cam * sc * (0.12f + i * 0.14f); val amp = h * (0.30f - i * 0.07f)
            val b0 = floor(off / sc / bwid).toInt()
            for (bi in b0..b0 + (w / sc / bwid).toInt() + 2) {
                val bx = bi * bwid * sc - off
                val top = gy - amp * (0.3f + 0.12f * ((bi * 37 + i * 11) % 7))
                for (r in 0..4) for (cc in 0..3) if ((bi * 7 + r * 5 + cc * 3) % 4 == 0) {
                    paint.color = ca(k(if ((bi + r + cc) % 2 == 0) 0xFFFFE08A else 0xFF7DF9FF), 0.75f)
                    val wx = bx + sc * (0.35f + cc * 0.7f); val wy = top + sc * (0.45f + r * 0.6f)
                    if (wy < gy - sc * 0.2f) c.drawRect(wx, wy, wx + sc * 0.26f, wy + sc * 0.34f, paint)
                }
            }
        }
        paint.shader = fogSh; c.drawRect(0f, gy - h * 0.2f, w, gy + 1f, paint); paint.shader = null
    }

    private fun drawHero(c: Canvas, l: Float, t: Float, w: Float, h: Float, fc: Int, sk: Int, run: Boolean, air: Boolean) {
        fun fx(x: Float) = if (fc > 0) l + x * w else l + (1f - x) * w
        fun rr(x1: Float, y1: Float, x2: Float, y2: Float, rad: Float, col: Int) {
            val xa = fx(x1); val xb = fx(x2)
            paint.color = col
            c.drawRoundRect(min(xa, xb), t + y1 * h, max(xa, xb), t + y2 * h, rad * w, rad * w, paint)
        }
        paint.style = Paint.Style.FILL; paint.shader = null
        val body = skinCol(sk)
        val s = if (run) sin(time * 22f) * 0.1f else 0f
        val lift = if (air) 0.12f else 0f
        rr(0.2f + s, 0.78f - lift, 0.42f + s, 1f - lift, 0.1f, k(0xFF1B2433))
        rr(0.58f - s, 0.78f - lift, 0.8f - s, 1f - lift, 0.1f, k(0xFF1B2433))
        rr(0.18f + s, 0.92f - lift, 0.45f + s, 1f - lift, 0.1f, k(0xFFECEFF1))
        rr(0.55f - s, 0.92f - lift, 0.82f - s, 1f - lift, 0.1f, k(0xFFECEFF1))
        rr(0.47f, 0f, 0.53f, 0.17f, 0.02f, k(0xFF0B0F1A))
        rr(0.05f, 0.14f, 0.95f, 0.86f, 0.3f, k(0xFF0B0F1A))
        rr(0.08f, 0.17f, 0.92f, 0.83f, 0.28f, body)
        c.save(); c.clipRect(l - 2f, t + 0.55f * h, l + w + 2f, t + h + 2f)
        rr(0.08f, 0.17f, 0.92f, 0.83f, 0.28f, k(0x40000000))
        c.restore()
        rr(0.14f, 0.21f, 0.5f, 0.33f, 0.06f, k(0x55FFFFFF))
        rr(0.34f, 0.3f, 0.9f, 0.62f, 0.14f, k(0xFF10131F))
        val eh = if ((time % 3.3f) < 0.12f) 0.03f else 0.11f
        rr(0.5f, 0.46f - eh, 0.6f, 0.46f + eh, 0.04f, k(0xFF7DF9FF))
        rr(0.7f, 0.46f - eh, 0.8f, 0.46f + eh, 0.04f, k(0xFF7DF9FF))
        rr(0.38f, 0.33f, 0.88f, 0.37f, 0.02f, k(0x33FFFFFF))
        paint.color = k(0xFFFF2BD6); c.drawCircle(fx(0.5f), t + 0.02f * h, 0.08f * w, paint)
    }

    private fun drawEnemy(c: Canvas, e: Enemy, l: Float, tp: Float, sc: Float) {
        paint.style = Paint.Style.FILL; paint.shader = null
        if (e.kind != 2) { paint.color = k(0x33000000); c.drawOval(l, tp + sc * 0.74f, l + sc * 0.8f, tp + sc * 0.9f, paint) }
        when (e.kind) {
            2 -> {
                val fl = sin(time * 14f) * 0.3f * sc
                glowAt(c, l + sc * 0.4f, tp + sc * 0.4f, sc * 1.2f, k(0xFFB388FF), 0.35f)
                paint.color = k(0xFF4A2C82)
                path.reset(); path.moveTo(l + sc * 0.4f, tp + sc * 0.4f); path.lineTo(l - sc * 0.45f, tp + sc * 0.05f + fl); path.lineTo(l - sc * 0.1f, tp + sc * 0.7f); path.close(); c.drawPath(path, paint)
                path.reset(); path.moveTo(l + sc * 0.4f, tp + sc * 0.4f); path.lineTo(l + sc * 1.25f, tp + sc * 0.05f + fl); path.lineTo(l + sc * 0.9f, tp + sc * 0.7f); path.close(); c.drawPath(path, paint)
                blob(c, l + sc * 0.08f, tp + sc * 0.1f, l + sc * 0.72f, tp + sc * 0.72f, sc * 0.3f, k(0xFF8E5CD9))
                paint.color = k(0xFFFFEB3B); c.drawCircle(l + sc * 0.28f, tp + sc * 0.38f, sc * 0.07f, paint); c.drawCircle(l + sc * 0.52f, tp + sc * 0.38f, sc * 0.07f, paint)
                path.reset()
                path.moveTo(l + sc * 0.12f, tp + sc * 0.18f); path.lineTo(l + sc * 0.2f, tp - sc * 0.08f); path.lineTo(l + sc * 0.3f, tp + sc * 0.14f); path.close()
                path.moveTo(l + sc * 0.5f, tp + sc * 0.14f); path.lineTo(l + sc * 0.6f, tp - sc * 0.08f); path.lineTo(l + sc * 0.68f, tp + sc * 0.18f); path.close()
                paint.color = k(0xFF8E5CD9); c.drawPath(path, paint)
            }
            3 -> {
                if (e.cd < 0.45f) glowAt(c, l, tp + sc * 0.45f, sc * 0.9f, k(0xFFFF1744), 0.8f)
                paint.color = k(0xFF37474F); c.drawRoundRect(l - sc * 0.4f, tp + sc * 0.34f, l + sc * 0.3f, tp + sc * 0.56f, sc * 0.08f, sc * 0.08f, paint)
                blob(c, l, tp + sc * 0.15f, l + sc * 0.8f, tp + sc * 0.8f, sc * 0.18f, k(0xFF78909C))
                paint.color = k(0xFF1B2433); c.drawRect(l + sc * 0.1f, tp + sc * 0.72f, l + sc * 0.7f, tp + sc * 0.8f, paint)
                paint.color = k(0xFFFF1744); c.drawCircle(l + sc * 0.4f, tp + sc * 0.42f, sc * 0.12f, paint)
            }
            else -> {
                val base = k(if (e.spiky) 0xFFE53935 else 0xFFFF9100)
                val s2 = sin(time * 10f + e.x) * 0.08f * sc
                paint.color = k(0xFF0B0F1A)
                c.drawOval(l + sc * 0.05f + s2, tp + sc * 0.68f, l + sc * 0.38f + s2, tp + sc * 0.84f, paint)
                c.drawOval(l + sc * 0.42f - s2, tp + sc * 0.68f, l + sc * 0.75f - s2, tp + sc * 0.84f, paint)
                if (e.spiky) for (i in 0..3) {
                    path.reset()
                    path.moveTo(l + sc * (0.02f + i * 0.2f), tp + sc * 0.2f); path.lineTo(l + sc * (0.12f + i * 0.2f), tp - sc * 0.15f)
                    path.lineTo(l + sc * (0.22f + i * 0.2f), tp + sc * 0.2f); path.close()
                    paint.color = k(0xFFFFD54F); c.drawPath(path, paint)
                }
                blob(c, l, tp + sc * 0.1f, l + sc * 0.8f, tp + sc * 0.74f, sc * 0.3f, base)
                val dx = sign(e.vx) * sc * 0.04f
                paint.color = Color.WHITE; c.drawCircle(l + sc * 0.27f, tp + sc * 0.37f, sc * 0.13f, paint); c.drawCircle(l + sc * 0.53f, tp + sc * 0.37f, sc * 0.13f, paint)
                paint.color = Color.BLACK; c.drawCircle(l + sc * 0.27f + dx, tp + sc * 0.39f, sc * 0.06f, paint); c.drawCircle(l + sc * 0.53f + dx, tp + sc * 0.39f, sc * 0.06f, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.06f; paint.color = k(0xFF0B0F1A)
                c.drawLine(l + sc * 0.14f, tp + sc * 0.2f, l + sc * 0.34f, tp + sc * 0.28f, paint)
                c.drawLine(l + sc * 0.66f, tp + sc * 0.2f, l + sc * 0.46f, tp + sc * 0.28f, paint)
                paint.style = Paint.Style.FILL
            }
        }
    }

    private fun drawBtn(c: Canvas, b: Btn) {
        val r = b.r; val rad = r.height() * 0.42f
        paint.style = Paint.Style.FILL; paint.shader = null
        if (b.label == "II") {
            paint.color = k(0x66000000); c.drawCircle(r.centerX(), r.centerY() + 3f, r.width() / 2, paint)
            paint.color = k(0x55FFFFFF); c.drawCircle(r.centerX(), r.centerY(), r.width() / 2, paint)
            paint.color = Color.WHITE
            c.drawRoundRect(r.centerX() - r.width() * 0.2f, r.centerY() - r.height() * 0.22f, r.centerX() - r.width() * 0.06f, r.centerY() + r.height() * 0.22f, 4f, 4f, paint)
            c.drawRoundRect(r.centerX() + r.width() * 0.06f, r.centerY() - r.height() * 0.22f, r.centerX() + r.width() * 0.2f, r.centerY() + r.height() * 0.22f, 4f, 4f, paint)
            return
        }
        val ad = b.sub.contains("ANUNCIO")
        val prim = b.label in PRIMARY
        val c1 = if (ad) k(0xFFFFE082) else if (prim) k(0xFF4DF3FF) else k(0xEE2E1A5E)
        val c2 = if (ad) k(0xFFFF8F00) else if (prim) k(0xFF2962FF) else k(0xEE180B3A)
        paint.color = k(0x77000000); c.drawRoundRect(r.left, r.top + r.height() * 0.07f, r.right, r.bottom + r.height() * 0.07f, rad, rad, paint)
        paint.shader = LinearGradient(0f, r.top, 0f, r.bottom, c1, c2, Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, paint); paint.shader = null
        paint.color = k(0x26FFFFFF); c.drawRoundRect(r.left + r.height() * 0.06f, r.top + r.height() * 0.05f, r.right - r.height() * 0.06f, r.top + r.height() * 0.5f, rad, rad, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = max(2f, r.height() * 0.03f)
        paint.color = if (ad || prim) k(0x88FFFFFF) else k(0x55A58CFF); c.drawRoundRect(r, rad, rad, paint)
        paint.style = Paint.Style.FILL
        if (scr == 4 && b.label.contains(": ")) {
            val parts = b.label.split(": ")
            txt(c, parts[0], r.left + r.height() * 0.5f, r.centerY() + r.height() * 0.14f, r.height() * 0.38f, 0xFFFFFFFF, Paint.Align.LEFT)
            val v = parts[1]
            if (v == "SÍ" || v == "NO") {
                val on = v == "SÍ"; val pw = r.height() * 1.1f; val ph = r.height() * 0.5f
                rf.set(r.right - r.height() * 0.5f - pw, r.centerY() - ph / 2, r.right - r.height() * 0.5f, r.centerY() + ph / 2)
                paint.color = if (on) k(0xFF00E676) else k(0xFF546E7A); c.drawRoundRect(rf, ph / 2, ph / 2, paint)
                paint.color = Color.WHITE; c.drawCircle(if (on) rf.right - ph / 2 else rf.left + ph / 2, rf.centerY(), ph * 0.38f, paint)
            } else txt(c, v, r.right - r.height() * 0.5f, r.centerY() + r.height() * 0.14f, r.height() * 0.38f, 0xFF7DF9FF, Paint.Align.RIGHT)
            return
        }
        val tc = if (ad) 0xFF3E2723 else 0xFFFFFFFF
        if (ad) {
            val px = r.left + r.height() * 0.55f; val q = r.height() * 0.2f
            path.reset(); path.moveTo(px - q * 0.5f, r.centerY() - q); path.lineTo(px + q, r.centerY()); path.lineTo(px - q * 0.5f, r.centerY() + q); path.close()
            paint.color = k(0xFF3E2723); c.drawPath(path, paint)
        }
        if (b.sub.isEmpty()) txt(c, b.label, r.centerX(), r.centerY() + r.height() * 0.14f, r.height() * 0.4f, tc)
        else {
            txt(c, b.label, r.centerX(), r.centerY() - r.height() * 0.04f, r.height() * 0.3f, tc)
            txt(c, b.sub, r.centerX(), r.centerY() + r.height() * 0.3f, r.height() * 0.2f, if (ad) 0xFF5D4037 else 0xFFFFE066)
        }
    }

    private fun padBtn(c: Canvas, r: RectF, label: String, on: Boolean) {
        val cx = r.centerX(); val cy = r.centerY()
        val rad = min(r.width(), r.height()) / 2 * (if (on) 0.94f else 1f)
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(0x44000000); c.drawCircle(cx, cy + rad * 0.06f, rad, paint)
        paint.color = if (on) k(0x66FFFFFF) else k(0x30FFFFFF); c.drawCircle(cx, cy, rad, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = max(2f, rad * 0.05f); paint.color = k(0x88FFFFFF); c.drawCircle(cx, cy, rad, paint)
        if (label == "DASH" && dashCd > 0f) {
            paint.strokeWidth = rad * 0.1f; paint.color = k(0xCC4DF3FF); rf.set(cx - rad, cy - rad, cx + rad, cy + rad)
            c.drawArc(rf, -90f, 360f * (1f - dashCd / (0.9f - 0.15f * upDash)).coerceIn(0f, 1f), false, paint)
        }
        paint.style = Paint.Style.FILL
        val q = rad * 0.38f
        when (label) {
            "<" -> { path.reset(); path.moveTo(cx - q, cy); path.lineTo(cx + q * 0.7f, cy - q); path.lineTo(cx + q * 0.7f, cy + q); path.close(); paint.color = Color.WHITE; c.drawPath(path, paint) }
            ">" -> { path.reset(); path.moveTo(cx + q, cy); path.lineTo(cx - q * 0.7f, cy - q); path.lineTo(cx - q * 0.7f, cy + q); path.close(); paint.color = Color.WHITE; c.drawPath(path, paint) }
            "SALTO" -> {
                path.reset(); path.moveTo(cx, cy - q * 1.1f); path.lineTo(cx + q, cy + q * 0.1f); path.lineTo(cx - q, cy + q * 0.1f); path.close(); paint.color = Color.WHITE; c.drawPath(path, paint)
                txt(c, "SALTO", cx, cy + rad * 0.68f, rad * 0.2f, 0xCCFFFFFF)
            }
            else -> { bolt(c, cx, cy - rad * 0.08f, q * 0.9f, Color.WHITE); txt(c, "DASH", cx, cy + rad * 0.72f, rad * 0.2f, 0xCCFFFFFF) }
        }
    }

    private fun drawLevelCard(c: Canvas, r: RectF, i: Int) {
        val T = TH[i / 4]; val open = i < unlocked; val hgt = r.height(); val rad = hgt * 0.22f
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(0x66000000); c.drawRoundRect(r.left, r.top + hgt * 0.06f, r.right, r.bottom + hgt * 0.06f, rad, rad, paint)
        paint.shader = LinearGradient(0f, r.top, 0f, r.bottom, if (open) k(T[10]) else k(0xFF37474F),
            if (open) lerpCol(k(T[10]), k(0xFF000000), 0.55f) else k(0xFF1C2630), Shader.TileMode.CLAMP)
        c.drawRoundRect(r, rad, rad, paint); paint.shader = null
        paint.color = k(0x33FFFFFF); c.drawRoundRect(r.left, r.top, r.right, r.top + hgt * 0.45f, rad, rad, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = hgt * 0.03f; paint.color = k(0x66FFFFFF); c.drawRoundRect(r, rad, rad, paint)
        paint.style = Paint.Style.FILL
        if (open) {
            txt(c, "${i + 1}", r.centerX(), r.centerY() - hgt * 0.02f, hgt * 0.38f, 0xFFFFFFFF)
            for (s in 0..2) star(c, r.centerX() + (s - 1) * r.width() * 0.26f, r.bottom - hgt * 0.22f, hgt * 0.13f, if (s < stars[i]) k(0xFFFFD54F) else k(0x66000000))
            if (i % 4 == 3) txt(c, "JEFE", r.centerX(), r.top + hgt * 0.19f, hgt * 0.14f, 0xFFFFE57F)
        } else {
            val cx = r.centerX(); val cy = r.centerY(); val bw = hgt * 0.3f
            paint.color = k(0xFFB0BEC5); c.drawRoundRect(cx - bw / 2, cy, cx + bw / 2, cy + bw * 0.8f, bw * 0.12f, bw * 0.12f, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = bw * 0.14f
            rf.set(cx - bw * 0.3f, cy - bw * 0.6f, cx + bw * 0.3f, cy + bw * 0.2f); c.drawArc(rf, 180f, 180f, false, paint)
            paint.style = Paint.Style.FILL
        }
    }

    private fun drawShopCard(c: Canvas, r: RectF, j: Int) {
        val hgt = r.height()
        if (shopTab == 0) {
            val own = (owned and (1 shl j)) != 0
            glass(c, r, k(0xFF7DF9FF), own && skin == j)
            glowAt(c, r.centerX(), r.top + hgt * 0.34f, hgt * 0.5f, ca(skinCol(j), 1f), 0.4f)
            val hs = hgt * 0.42f
            drawHero(c, r.centerX() - hs / 2, r.top + hgt * 0.1f, hs, hs, 1, j, true, false)
            txt(c, SK_N[j], r.centerX(), r.top + hgt * 0.68f, hgt * 0.11f, 0xFFFFFFFF)
            if (own) chip(c, r.centerX(), r.top + hgt * 0.86f, hgt * 0.14f, if (skin == j) k(0xFF00C853) else k(0xFF2979FF), if (skin == j) "EQUIPADO" else "EQUIPAR")
            else {
                coinIcon(c, r.centerX() - hgt * 0.16f, r.top + hgt * 0.86f, hgt * 0.07f)
                txt(c, "${SK_P[j]}", r.centerX() - hgt * 0.06f, r.top + hgt * 0.9f, hgt * 0.12f, 0xFFFFE066, Paint.Align.LEFT)
            }
        } else {
            val lvl = upLevel(j)
            glass(c, r, k(0xFF7DF9FF), lvl > 0)
            val cx = r.centerX(); val cy = r.top + hgt * 0.2f
            glowAt(c, cx, cy, hgt * 0.3f, k(if (j == 0) 0xFFFF4D6D else if (j == 1) 0xFFFFEB3B else 0xFF4DF3FF), 0.5f)
            when (j) { 0 -> heart(c, cx, cy, hgt * 0.09f, k(0xFFFF4D6D)); 1 -> bolt(c, cx, cy, hgt * 0.07f, k(0xFFFFEB3B)); else -> gem(c, cx, cy, hgt * 0.1f, 1f) }
            txt(c, arrayOf("CORAZÓN EXTRA", "DASH RÁPIDO", "IMÁN DE GEMAS")[j], cx, r.top + hgt * 0.42f, hgt * 0.085f, 0xFFFFFFFF)
            txt(c, arrayOf("+1 vida máxima", "Recarga más corta", "Atrae las gemas")[j], cx, r.top + hgt * 0.53f, hgt * 0.062f, 0xFF9FA8DA)
            for (i in 0 until 3) {
                rf.set(r.left + r.width() * (0.2f + i * 0.22f), r.top + hgt * 0.62f, r.left + r.width() * (0.38f + i * 0.22f), r.top + hgt * 0.68f)
                paint.color = if (i < lvl) k(0xFF4DF3FF) else k(0x44FFFFFF); c.drawRoundRect(rf, 6f, 6f, paint)
            }
            if (lvl >= 3) chip(c, cx, r.top + hgt * 0.86f, hgt * 0.11f, k(0xFF00C853), "MÁXIMO")
            else {
                coinIcon(c, cx - hgt * 0.18f, r.top + hgt * 0.86f, hgt * 0.065f)
                txt(c, "${150 * (lvl + 1)}", cx - hgt * 0.09f, r.top + hgt * 0.9f, hgt * 0.1f, 0xFFFFE066, Paint.Align.LEFT)
            }
        }
    }

    private fun render(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (scr == 5) renderPlay(c, w, h) else renderMenu(c, w, h)
        for ((i, b) in btns.withIndex()) {
            if (scr == 2 && i < 12) drawLevelCard(c, b.r, i)
            else if (scr == 3 && i < (if (shopTab == 0) 6 else 3)) drawShopCard(c, b.r, i)
            else drawBtn(c, b)
        }
        if (scr in 1..4) {
            val s = "$coins"; val ph = h * 0.075f
            paint.textSize = ph * 0.55f; paint.textAlign = Paint.Align.CENTER
            val tw = paint.measureText(s)
            rf.set(w - h * 0.04f - tw - ph * 1.4f, h * 0.035f, w - h * 0.04f, h * 0.035f + ph)
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(0x99000000); c.drawRoundRect(rf, ph / 2, ph / 2, paint)
            coinIcon(c, rf.left + ph * 0.5f, rf.centerY(), ph * 0.3f)
            txt(c, s, rf.right - ph * 0.3f, rf.centerY() + ph * 0.2f, ph * 0.55f, 0xFFFFE066, Paint.Align.RIGHT)
        }
        if (msgT > 0f && scr != 0 && msg.isNotEmpty()) {
            paint.textSize = h * 0.042f; paint.textAlign = Paint.Align.CENTER
            val tw = paint.measureText(msg); val ph = h * 0.065f
            rf.set(w / 2 - tw / 2 - ph * 0.7f, h * 0.96f - ph / 2, w / 2 + tw / 2 + ph * 0.7f, h * 0.96f + ph / 2)
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = ca(k(0xFF111827), min(1f, msgT * 2f) * 0.9f); c.drawRoundRect(rf, ph / 2, ph / 2, paint)
            txt(c, msg, w / 2, h * 0.96f + ph * 0.18f, h * 0.042f, 0xFFFFFFFF)
        }
        if (rT > 0f) {
            paint.style = Paint.Style.STROKE; paint.shader = null; paint.strokeWidth = 4f; paint.color = ca(Color.WHITE, rT * 0.6f)
            c.drawCircle(rx, ry, (1f - rT) * h * 0.12f + 10f, paint); paint.style = Paint.Style.FILL
        }
        if (fade > 0f) { paint.style = Paint.Style.FILL; paint.shader = null; paint.color = ca(Color.BLACK, fade * 0.85f); c.drawRect(0f, 0f, w, h, paint) }
    }

    private fun renderMenu(c: Canvas, w: Float, h: Float) {
        prepare(w, h, 0)
        val sc = h / H; val cam = time * 4f; val gy = 7.6f * sc
        renderWorld(c, w, h, 0, cam, sc)
        val x0 = floor(cam).toInt()
        for (i in 0..(w / sc).toInt() + 1) {
            val l = (x0 + i - cam) * sc
            rf.set(l, gy, l + sc + 1f, gy + sc + 1f); tiles[1]?.let { c.drawBitmap(it, null, rf, null) }
            for (j in 1..4) { rf.set(l, gy + j * sc, l + sc + 1f, gy + (j + 1) * sc + 1f); tiles[0]?.let { c.drawBitmap(it, null, rf, null) } }
        }
        paint.style = Paint.Style.FILL; paint.shader = null
        paint.color = k(if (scr == 0) 0x1A000000 else 0x77000000); c.drawRect(0f, 0f, w, h, paint)
        when (scr) {
            0 -> {
                title(c, "NEON DASH", w / 2, h * 0.36f, h * 0.2f)
                val hs = sc * 2f
                glowAt(c, w / 2, gy - hs / 2, hs * 1.3f, ca(skinCol(skin), 1f), 0.3f)
                drawHero(c, w / 2 - hs / 2, gy - hs, hs, hs, 1, skin, true, false)
                txt(c, "TOCA PARA EMPEZAR", w / 2, h * 0.9f, h * 0.06f * (1f + 0.04f * sin(time * 4f)), 0xFFFFFFFF)
            }
            1 -> {
                title(c, "NEON DASH", w / 2, h * 0.2f, h * 0.13f)
                val hs = sc * 1.8f
                glowAt(c, w * 0.13f + hs / 2, gy - hs / 2, hs * 1.3f, ca(skinCol(skin), 1f), 0.3f)
                drawHero(c, w * 0.13f, gy - hs, hs, hs, 1, skin, true, false)
            }
            2 -> {
                title(c, "NIVELES", w / 2, h * 0.12f, h * 0.09f)
                for (r in 0..2) chip(c, w * 0.17f, h * (0.30f + r * 0.22f), h * 0.07f, k(TH[r][10]), WN[r])
            }
            3 -> title(c, if (shopTab == 0) "SKINS" else "MEJORAS", w / 2, h * 0.11f, h * 0.09f)
            4 -> title(c, "AJUSTES", w / 2, h * 0.12f, h * 0.09f)
        }
        paint.shader = vigSh; c.drawRect(0f, 0f, w, h, paint); paint.shader = null
    }

    private fun renderPlay(c: Canvas, w: Float, h: Float) {
        val th = lv / 4; val T = TH[th]; val sc = h / H; val vw = w / sc; val cam = camX
        prepare(w, h, th)
        renderWorld(c, w, h, th, cam, sc)
        paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(AMB[th])
        for (i in 0 until 30) {
            val fx = ((i * 7919) % 1000) / 1000f; val fy = ((i * 104729) % 1000) / 1000f
            val spd = (0.05f + (i % 4) * 0.03f) * (if (th == 1) -1f else 1f)
            val ay = ((((fy + time * spd) % 1f) + 1f) % 1f) * h
            val ax = (((fx * w - cam * sc * (0.2f + (i % 3) * 0.15f)) % w) + w) % w
            c.drawCircle(ax, ay, h * (0.004f + (i % 3) * 0.002f), paint)
        }
        c.save()
        c.translate(0f, -2.4f * sc)
        if (shake > 0f) c.translate((rnd.nextFloat() - 0.5f) * h * 0.03f, (rnd.nextFloat() - 0.5f) * h * 0.03f)
        val x0 = floor(cam).toInt(); val x1 = min(W - 1, ceil(cam + vw).toInt())
        for (tx in x0..x1) if (map[10][tx] == '.' && map[11][tx] == '.') {
            val lx = (tx - cam) * sc
            paint.style = Paint.Style.FILL; paint.shader = null
            paint.color = k(HZ[th]); c.drawRect(lx, (11.4f + 0.1f * sin(time * 3f + tx)) * sc, lx + sc + 1f, 15f * sc, paint)
            glowAt(c, lx + sc / 2, 11.4f * sc, sc * 1.1f, ca(k(HZ[th]), 1f), 0.45f)
        }
        for (tx in x0..x1) if (map[10][tx] == '#' && map[9][tx] == '.' && map[8][tx] == '.' && (tx * 31 + 7) % 11 == 0) prop(c, th, (tx - cam) * sc + sc / 2, 10f * sc, sc, tx)
        for (ty in 0 until H) for (tx in x0..x1) {
            val t = map[ty][tx]
            if (t == '.') continue
            val l = (tx - cam) * sc; val tp = ty * sc
            paint.style = Paint.Style.FILL; paint.shader = null
            when (t) {
                '#' -> { rf.set(l, tp, l + sc + 1f, tp + sc + 1f); tiles[if (ty == 0 || map[ty - 1][tx] != '#') 1 else 0]?.let { c.drawBitmap(it, null, rf, null) } }
                'P' -> { rf.set(l, tp, l + sc + 1f, tp + sc * 0.42f); tiles[2]?.let { c.drawBitmap(it, null, rf, null) } }
                '^' -> for (i in 0..1) {
                    val bx = l + i * 0.5f * sc
                    path.reset(); path.moveTo(bx, tp + sc); path.lineTo(bx + 0.25f * sc, tp + sc * 0.42f); path.lineTo(bx + 0.25f * sc, tp + sc); path.close()
                    paint.color = k(0xFFCFD8DC); c.drawPath(path, paint)
                    path.reset(); path.moveTo(bx + 0.25f * sc, tp + sc); path.lineTo(bx + 0.25f * sc, tp + sc * 0.42f); path.lineTo(bx + 0.5f * sc, tp + sc); path.close()
                    paint.color = k(0xFF78909C); c.drawPath(path, paint)
                }
                'o' -> {
                    val cy = tp + sc / 2 + sin(time * 3f + tx) * 0.05f * sc
                    glowAt(c, l + sc / 2, cy, sc * 0.8f, k(0xFF4DF3FF), 0.55f)
                    gem(c, l + sc / 2, cy, sc * 0.3f * (0.9f + 0.1f * sin(time * 5f + tx)), 0.45f + 0.55f * abs(cos(time * 3f + tx)))
                }
                'C' -> {
                    val act = cpX == tx.toFloat(); val fc = k(if (act) 0xFF69F0AE else 0xFFFF5252)
                    paint.color = k(0xFFB0BEC5); c.drawRect(l + sc * 0.46f, tp - sc * 0.2f, l + sc * 0.54f, tp + sc + 1f, paint)
                    val wv = sin(time * 6f) * sc * 0.06f
                    path.reset(); path.moveTo(l + sc * 0.54f, tp - sc * 0.15f); path.lineTo(l + sc * 1.15f, tp + sc * 0.1f + wv); path.lineTo(l + sc * 0.54f, tp + sc * 0.4f); path.close()
                    paint.color = fc; c.drawPath(path, paint)
                    glowAt(c, l + sc * 0.8f, tp + sc * 0.12f, sc * 0.8f, fc, 0.45f)
                }
                'G' -> if (ty == 6) {
                    val cx = l + sc / 2; val cy = tp + sc * 2f
                    val pc = if (boss != null) k(0xFF9E9E9E) else k(T[10])
                    glowAt(c, cx, cy, sc * 3f, pc, 0.5f)
                    paint.color = ca(pc, 0.18f); c.drawOval(cx - sc * 0.7f, cy - sc * 1.9f, cx + sc * 0.7f, cy + sc * 1.9f, paint)
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.1f
                    for (i in 0..2) {
                        paint.color = ca(pc, 0.9f - i * 0.25f)
                        rf.set(cx - sc * (0.8f - i * 0.18f), cy - sc * (2f - i * 0.4f), cx + sc * (0.8f - i * 0.18f), cy + sc * (2f - i * 0.4f))
                        c.drawArc(rf, time * (120f + i * 70f) * (if (i % 2 == 0) 1f else -1f), 250f, false, paint)
                    }
                    paint.style = Paint.Style.FILL
                }
                '=' -> {
                    paint.color = k(0xFF455A64); c.drawRoundRect(l + sc * 0.1f, tp + sc * 0.82f, l + sc * 0.9f, tp + sc, sc * 0.06f, sc * 0.06f, paint)
                    paint.color = k(0xFFB0BEC5); for (i in 0..2) c.drawRect(l + sc * (0.22f + i * 0.22f), tp + sc * 0.55f, l + sc * (0.3f + i * 0.22f), tp + sc * 0.82f, paint)
                    paint.color = k(0xFFFFC107); c.drawRoundRect(l + sc * 0.05f, tp + sc * 0.46f, l + sc * 0.95f, tp + sc * 0.58f, sc * 0.06f, sc * 0.06f, paint)
                }
                'S' -> {
                    val cy = tp + sc / 2 + sin(time * 4f + tx) * 0.05f * sc
                    glowAt(c, l + sc / 2, cy, sc * 0.9f, k(0xFF4DF3FF), 0.6f)
                    paint.color = k(0x554DF3FF); c.drawCircle(l + sc / 2, cy, sc * 0.32f, paint)
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.06f; paint.color = k(0xFF4DF3FF); c.drawCircle(l + sc / 2, cy, sc * 0.32f, paint)
                    paint.style = Paint.Style.FILL; paint.color = Color.WHITE; c.drawCircle(l + sc / 2, cy, sc * 0.1f, paint)
                }
                'H' -> {
                    val cy = tp + sc / 2 + sin(time * 4f + tx) * 0.06f * sc
                    glowAt(c, l + sc / 2, cy, sc * 0.9f, k(0xFFFF4D6D), 0.6f)
                    heart(c, l + sc / 2, cy, sc * 0.28f, k(0xFFFF4D6D))
                }
            }
        }
        paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(T[8])
        for (tx in x0..x1) if (map[11][tx] == '#') c.drawRect((tx - cam) * sc, 12f * sc, (tx - cam) * sc + sc + 1f, 15f * sc, paint)
        for (g in ghosts) {
            paint.color = ca(k(0xFF4DF3FF), g[2] * 2f)
            c.drawRoundRect((g[0] - cam) * sc, g[1] * sc, (g[0] - cam) * sc + p.w * sc, g[1] * sc + p.h * sc, sc * 0.25f, sc * 0.25f, paint)
        }
        for (e in enemies) {
            val l = (e.x - cam) * sc
            if (e.dead || l < -sc * 2 || l > w + sc) continue
            drawEnemy(c, e, l, e.y * sc, sc)
        }
        for (bl in bullets) {
            val bx = (bl.x - cam) * sc
            glowAt(c, bx + sc * 0.22f, bl.y * sc + sc * 0.15f, sc * 0.75f, k(0xFFFF9100), 0.75f)
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(0xFFFFF176); c.drawOval(bx, bl.y * sc, bx + 0.45f * sc, bl.y * sc + 0.3f * sc, paint)
        }
        boss?.let { bs ->
            val l = (bs.x - cam) * sc; val tp = bs.y * sc; val bw = bs.w * sc; val bhh = bs.h * sc
            val flash = bs.inv > 0f && (time * 20f).toInt() % 2 == 0
            val col = if (flash) Color.WHITE else if (bs.state == 1 && (time * 16f).toInt() % 2 == 0) k(0xFFFF1744) else if (bs.state == 3) k(0xFF7E57C2) else k(0xFF8E24AA)
            glowAt(c, l + bw / 2, tp + bhh / 2, bw * 1.5f, k(if (bs.state == 1) 0xFFFF1744 else 0xFFAB47BC), 0.4f)
            paint.style = Paint.Style.FILL; paint.shader = null
            paint.color = k(0x33000000); c.drawOval(l, tp + bhh * 0.9f, l + bw, tp + bhh * 1.05f, paint)
            blob(c, l, tp, l + bw, tp + bhh, bw * 0.3f, col)
            paint.color = k(0xFFFFD740)
            for (i in 0..3) {
                path.reset()
                path.moveTo(l + (0.1f + i * 0.22f) * bw, tp + 0.02f * bhh); path.lineTo(l + (0.21f + i * 0.22f) * bw, tp - 0.2f * bhh)
                path.lineTo(l + (0.32f + i * 0.22f) * bw, tp + 0.02f * bhh); path.close(); c.drawPath(path, paint)
            }
            paint.color = Color.WHITE
            c.drawCircle(l + 0.3f * bw, tp + 0.38f * bhh, 0.13f * bw, paint); c.drawCircle(l + 0.7f * bw, tp + 0.38f * bhh, 0.13f * bw, paint)
            paint.color = if (bs.state == 3) k(0xFF9E9E9E) else Color.BLACK
            c.drawCircle(l + 0.3f * bw + bs.dir * 0.03f * bw, tp + 0.4f * bhh, 0.06f * bw, paint); c.drawCircle(l + 0.7f * bw + bs.dir * 0.03f * bw, tp + 0.4f * bhh, 0.06f * bw, paint)
            paint.color = Color.BLACK; c.drawRoundRect(l + 0.25f * bw, tp + 0.68f * bhh, l + 0.75f * bw, tp + 0.78f * bhh, 6f, 6f, paint)
        }
        paint.style = Paint.Style.FILL; paint.shader = null
        for (q in parts) {
            paint.color = ca(q.col, min(1f, q.life * 2.5f))
            c.drawCircle((q.x - cam) * sc, q.y * sc, sc * 0.07f * (0.5f + q.life), paint)
        }
        if (inv <= 0f || (time * 20f).toInt() % 2 == 0) {
            val st = min(abs(p.vy) / 40f, 0.25f)
            val pw = p.w * sc * 1.2f * (1f - st * 0.5f)
            val ph = p.h * sc * (1f + st)
            glowAt(c, (p.x - cam + p.w / 2) * sc, (p.y + p.h / 2) * sc, sc * 1.6f, ca(skinCol(skin), 1f), 0.22f)
            drawHero(c, (p.x - cam) * sc + (p.w * sc - pw) / 2, p.y * sc + p.h * sc - ph, pw, ph, face, skin, p.ground && abs(p.vx) > 0.5f, !p.ground)
        }
        if (shield) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = sc * 0.08f; paint.color = k(0xCC4DF3FF)
            c.drawCircle((p.x - cam + p.w / 2) * sc, (p.y + p.h / 2) * sc, p.h * sc * 0.85f, paint)
            paint.style = Paint.Style.FILL
        }
        c.restore()
        paint.style = Paint.Style.FILL
        paint.shader = vigSh; c.drawRect(0f, 0f, w, h, paint); paint.shader = null

        // HUD
        val hp0 = maxHp(); val pillH = h * 0.085f
        rf.set(h * 0.03f, h * 0.03f, h * 0.03f + pillH * 0.6f + hp0 * h * 0.062f + h * 0.34f, h * 0.03f + pillH)
        paint.color = k(0x88000000); c.drawRoundRect(rf, pillH / 2, pillH / 2, paint)
        for (i in 0 until hp0) heart(c, h * 0.03f + pillH * 0.6f + i * h * 0.062f, rf.centerY(), h * 0.022f, if (i < hp) k(0xFFFF4D6D) else k(0x55FFFFFF))
        val gx = h * 0.03f + pillH * 0.5f + hp0 * h * 0.062f + h * 0.04f
        gem(c, gx, rf.centerY(), h * 0.028f, 1f)
        txt(c, "$gems/$gemTotal", gx + h * 0.045f, rf.centerY() + h * 0.02f, h * 0.05f, 0xFFFFFFFF, Paint.Align.LEFT)
        boss?.let { bs ->
            if (p.x > W - 40f) {
                val bw2 = h * 1.2f; val bx = w / 2 - bw2 / 2
                rf.set(bx, h * 0.12f, bx + bw2, h * 0.16f); paint.color = k(0x99000000); c.drawRoundRect(rf, h * 0.02f, h * 0.02f, paint)
                rf.set(bx, h * 0.12f, bx + bw2 * bs.hp / bossMax, h * 0.16f)
                paint.shader = LinearGradient(0f, h * 0.12f, 0f, h * 0.16f, k(0xFFFF8A80), k(0xFFD50000), Shader.TileMode.CLAMP)
                c.drawRoundRect(rf, h * 0.02f, h * 0.02f, paint); paint.shader = null
                txt(c, "JEFE", w / 2, h * 0.105f, h * 0.04f, 0xFFFFFFFF)
            }
        }
        if (intro > 0f) txt(c, "NIVEL ${lv + 1} - ${WN[th]}" + (if (lv % 4 == 3) "  ¡JEFE!" else ""), w / 2, h * 0.3f, h * 0.08f, 0xFFFFFFFF)
        if (res == 0 && !paused) { padBtn(c, bL, "<", goL); padBtn(c, bR, ">", goR); padBtn(c, bJ, "SALTO", goJ); padBtn(c, bD, "DASH", goD) }
        if (paused || res != 0) {
            paint.style = Paint.Style.FILL; paint.shader = null; paint.color = k(0xAA060312); c.drawRect(0f, 0f, w, h, paint)
            pr.set(w / 2 - h * 0.72f, h * 0.05f, w / 2 + h * 0.72f, h * 0.97f)
            glass(c, pr, k(0xFF7DF9FF), false)
        }
        if (paused) title(c, "PAUSA", w / 2, h * 0.27f, h * 0.13f)
        if (res == 1) {
            title(c, "¡COMPLETADO!", w / 2, h * 0.17f, h * 0.1f)
            for (i in 0..2) star(c, w / 2 + (i - 1) * h * 0.2f, h * 0.27f, h * (if (i == 1) 0.075f else 0.06f) * (1f + 0.05f * sin(time * 4f + i)), if (i < lastStars) k(0xFFFFD54F) else k(0x55FFFFFF))
            txt(c, "Gemas $gems/$gemTotal   Monedas: $lvCoins", w / 2, h * 0.38f, h * 0.045f, 0xFFFFFFFF)
        }
        if (res == 2) title(c, "¡HAS CAÍDO!", w / 2, h * 0.3f, h * 0.11f)
    }
}
